﻿using System;
using System.Reflection;
using System.Windows;
using SchematicA24.ViewModel;

namespace SchematicA24
{
   /// <summary>
   /// Interaction logic for App.xaml
   /// </summary>
   public partial class App : Application
   {
      private MainWindowVM model;

      protected override void OnStartup(StartupEventArgs e)
      {
         base.OnStartup(e);

         var s = Assembly.GetExecutingAssembly().GetManifestResourceNames();
         foreach (var item in s) Console.WriteLine(item);

         model = new MainWindowVM(new MainWindow());
         model.Show();
      }

      protected override void OnExit(ExitEventArgs e)
      {
         model.Close();

         base.OnExit(e);
      }
   }
}