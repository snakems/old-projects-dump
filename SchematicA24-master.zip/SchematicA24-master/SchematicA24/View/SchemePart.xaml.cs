﻿using System.Windows.Controls;
using System.Windows.Data;

namespace SchematicA24.View
{
   /// <summary>
   /// Interaction logic for SchemePart.xaml
   /// </summary>
   public partial class SchemePart : UserControl
   {
      public SchemePart()
      {
         InitializeComponent();

         this.DataContextChanged += (s, e) => { zoomSchemePanel.SnapToView(); zoomPhotoPanel.SnapToView(); };
      }

      private void Image_SourceUpdated(object sender, DataTransferEventArgs e)
      {
         var img = sender as Image;
         if (img.Source != null)
         {
            zoomSchemePanel.ContentWidth = img.Source.Width;
            zoomSchemePanel.ContentHeight = img.Source.Height;
         }
         zoomSchemePanel.SnapToView();
      }

      private void ImagePhoto_SourceUpdated(object sender, DataTransferEventArgs e)
      {
         var img = sender as Image;
         if (img.Source != null)
         {
            zoomPhotoPanel.ContentWidth = img.Source.Width;
            zoomPhotoPanel.ContentHeight = img.Source.Height;
         }
         zoomPhotoPanel.SnapToView();
      }
   }
}