﻿using System.Windows;
using SchematicA24.View;

namespace SchematicA24
{
   /// <summary>
   /// Interaction logic for MainWindow.xaml
   /// </summary>
   public partial class MainWindow : Window, IShellView
   {
      public MainWindow()
      {
         InitializeComponent();
      }

      public bool IsMaximized
      {
         get { return WindowState == WindowState.Maximized; }
         set
         {
            if (value)
            {
               WindowState = WindowState.Maximized;
            }
            else if (WindowState == WindowState.Maximized)
            {
               WindowState = WindowState.Normal;
            }
         }
      }
   }
}