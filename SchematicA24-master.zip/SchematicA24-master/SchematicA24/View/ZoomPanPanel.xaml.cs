﻿using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

namespace SchematicA24.View
{
   /// <summary>
   /// Interaction logic for ZoomPanPanel.xaml
   /// </summary>
   public partial class ZoomPanPanel : UserControl
   {
      private Point? lastCenterPositionOnTarget;
      private Point? lastMousePositionOnTarget;
      private Point? lastDragPoint;

      private int zoomSteps = 5;
      private double maxZoom = 3.0;

      public double MaxZoom
      {
         get { return maxZoom; }
         set { maxZoom = value; }
      }

      public double ContentWidth
      {
         set
         {
            var grid = GetTemplateChild("grid") as Grid;
            grid.Width = value;
         }
      }

      public double ContentHeight
      {
         set
         {
            var grid = GetTemplateChild("grid") as Grid;
            grid.Height = value;
         }
      }

      public ZoomPanPanel()
      {
         InitializeComponent();
      }

      private int clickCount = 0;
      private System.Collections.Generic.List<Point> points = new System.Collections.Generic.List<Point>();

      private void scroll_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
      {
         var scroll = sender as ScrollViewer;
         var grid = scroll.Content as Grid;
         var p = e.GetPosition(grid);
         points.Add(p);
         ++clickCount;
      }

      private void scroll_PreviewKeyDown(object sender, KeyEventArgs e)
      {
         if (e.Key == Key.Escape)
         {
            if (clickCount < 3)
            {
               points.Clear();
               return;
            }

            System.Threading.Thread.CurrentThread.CurrentCulture = System.Globalization.CultureInfo.InvariantCulture;
            var xs = points.Select(p => (int)p.X).ToList();
            var ys = points.Select(p => (int)p.Y).ToList();
            for (int i = 0; i < points.Count; ++i)
            {
               if (Math.Abs(xs[i] - xs[(i + 1) % points.Count]) < 4)
                  xs[(i + 1) % points.Count] = xs[i];
               if (Math.Abs(ys[i] - ys[(i + 1) % points.Count]) < 4)
                  ys[(i + 1) % points.Count] = ys[i];
            }
            var left = xs.Min();
            var top = ys.Min();
            var width = xs.Max() - left;
            var height = ys.Max() - top;

            var str = String.Format("    <Polygon Canvas.Left=\"{0}\" Canvas.Top=\"{1}\"\n", left, top);
            str += "                        Points=\"";
            foreach (var p in xs.Zip(ys, (x, y) => new { X = (double)(x - left) / width, Y = (double)(y - top) / height }))
            {
               str += String.Format("{0:0.###},{1:0.###} ", p.X, p.Y);
            }
            str += String.Format("\"\n                        Width=\"{0}\" Height=\"{1}\">\n", width, height);
            str += "       <Polygon.InputBindings>\n";
            str += "           <MouseBinding Gesture=\"LeftClick\" Command=\"{Binding ShowPart}\" CommandParameter=\"_10\" />\n";
            str += "       </Polygon.InputBindings>\n";
            str += "       <Polygon.ToolTip>\n";
            str += "           <TextBlock Text=\"____\" />\n";
            str += "       </Polygon.ToolTip>\n";
            str += "    </Polygon>";

            Clipboard.SetText(str);

            clickCount = 0;
            points.Clear();
         }
      }

      public void SnapToView()
      {
         var scroll = GetTemplateChild("scroll") as ScrollViewer;
         if (scroll == null) return;

         var grid = scroll.Content as Grid;
         var scale = grid.LayoutTransform as ScaleTransform;

         var s = GetSnapScale();
         scale.ScaleX = s;
         scale.ScaleY = s;
      }

      private double GetSnapScale()
      {
         var scroll = GetTemplateChild("scroll") as ScrollViewer;
         if (scroll == null) return Double.NaN;

         var grid = scroll.Content as Grid;
         var scale = grid.LayoutTransform as ScaleTransform;

         return Math.Min(scroll.ActualWidth / grid.Width, scroll.ActualHeight / grid.Height);
      }

      private void scroll_PreviewMouseRightButtonDown(object sender, MouseButtonEventArgs e)
      {
         var scroll = sender as ScrollViewer;

         var mousePos = e.GetPosition(scroll);
         if (mousePos.X <= scroll.ViewportWidth && mousePos.Y < scroll.ViewportHeight) //make sure we still can use the scrollbars
         {
            scroll.Cursor = Cursors.SizeAll;
            lastDragPoint = mousePos;
            Mouse.Capture(scroll);
         }
      }

      private void scroll_MouseMove(object sender, MouseEventArgs e)
      {
         if (lastDragPoint.HasValue)
         {
            var scroll = sender as ScrollViewer;

            var posNow = e.GetPosition(scroll);

            double dX = posNow.X - lastDragPoint.Value.X;
            double dY = posNow.Y - lastDragPoint.Value.Y;

            lastDragPoint = posNow;

            scroll.ScrollToHorizontalOffset(scroll.HorizontalOffset - dX);
            scroll.ScrollToVerticalOffset(scroll.VerticalOffset - dY);
         }
      }

      private void scroll_MouseRightButtonUp(object sender, MouseButtonEventArgs e)
      {
         var scroll = sender as ScrollViewer;

         scroll.Cursor = Cursors.Arrow;
         scroll.ReleaseMouseCapture();
         lastDragPoint = null;
      }

      private void scroll_ScrollChanged(object sender, ScrollChangedEventArgs e)
      {
         var scroll = sender as ScrollViewer;
         var grid = scroll.Content as Grid;

         if (e.ExtentHeightChange != 0 || e.ExtentWidthChange != 0)
         {
            Point? targetBefore = null;
            Point? targetNow = null;

            if (!lastMousePositionOnTarget.HasValue)
            {
               if (lastCenterPositionOnTarget.HasValue)
               {
                  var centerOfViewport = new Point(scroll.ViewportWidth / 2, scroll.ViewportHeight / 2);
                  var centerOfTargetNow = scroll.TranslatePoint(centerOfViewport, grid);

                  targetBefore = lastCenterPositionOnTarget;
                  targetNow = centerOfTargetNow;
               }
            }
            else
            {
               targetBefore = lastMousePositionOnTarget;
               targetNow = Mouse.GetPosition(grid);

               lastMousePositionOnTarget = null;
            }

            if (targetBefore.HasValue)
            {
               var dXInTargetPixels = targetNow.Value.X - targetBefore.Value.X;
               var dYInTargetPixels = targetNow.Value.Y - targetBefore.Value.Y;

               var multiplicatorX = e.ExtentWidth / grid.Width;
               var multiplicatorY = e.ExtentHeight / grid.Height;

               var newOffsetX = scroll.HorizontalOffset - dXInTargetPixels * multiplicatorX;
               var newOffsetY = scroll.VerticalOffset - dYInTargetPixels * multiplicatorY;

               if (double.IsNaN(newOffsetX) || double.IsNaN(newOffsetY))
               {
                  return;
               }

               scroll.ScrollToHorizontalOffset(newOffsetX);
               scroll.ScrollToVerticalOffset(newOffsetY);
            }
         }
      }

      private void scroll_PreviewMouseWheel(object sender, MouseWheelEventArgs e)
      {
         var scroll = sender as ScrollViewer;
         if (scroll == null) throw new ArgumentNullException("scroll");
         var grid = scroll.Content as Grid;
         if (grid == null) throw new ArgumentNullException("grid");
         var scale = grid.LayoutTransform as ScaleTransform;
         if (scale == null) throw new ArgumentNullException("scale");

         lastMousePositionOnTarget = Mouse.GetPosition(grid);

         var s = GetSnapScale();
         var maxScale = s * MaxZoom;
         var zoomStep = (maxScale - s) / zoomSteps;
         var zoom = e.Delta > 0 ? zoomStep : -zoomStep;

         if (zoom < 0)
         {
            var w = scroll.ActualWidth;
            var h = scroll.ActualHeight;
            if (Math.Abs(w / (scale.ScaleX + zoom)) > grid.Width
             || Math.Abs(h / (scale.ScaleY + zoom)) > grid.Height)
            {
               SnapToView();
            }
            else
            {
               scale.ScaleX += zoom;
               scale.ScaleY += zoom;
            }
         }
         else
         {
            if (scale.ScaleX / s < MaxZoom && scale.ScaleY / s < MaxZoom)
            {
               scale.ScaleX += zoom;
               scale.ScaleY += zoom;
            }

            //if (scale.ScaleX + zoom < MaxZoom && scale.ScaleY + zoom < MaxZoom)
            //{
            //   scale.ScaleX += zoom;
            //   scale.ScaleY += zoom;
            //}
         }

         var centerOfViewport = new Point(scroll.ViewportWidth / 2, scroll.ViewportHeight / 2);
         lastCenterPositionOnTarget = scroll.TranslatePoint(centerOfViewport, grid);

         e.Handled = true;
      }
   }
}