﻿using System.Windows;
using System.Windows.Controls;

namespace SchematicA24.View
{
   /// <summary>
   /// Interaction logic for ConvertEquip.xaml
   /// </summary>
   public partial class ConvertEquip : UserControl
   {
      public ConvertEquip()
      {
         InitializeComponent();

         //this.DataContextChanged += (s, e) => zoomPanel.SnapToView();
      }

      private void Image_Loaded(object sender, RoutedEventArgs e)
      {
         var img = sender as Image;
         if (img.Source != null)
         {
            var width = img.Source.Width;
            var height = img.Source.Height;

            var canvas = zoomPanel.Content as Canvas;
            canvas.Width = width;
            canvas.Height = height;
            zoomPanel.ContentWidth = width;
            zoomPanel.ContentHeight = height;
         }
         zoomPanel.SnapToView();
      }
   }
}