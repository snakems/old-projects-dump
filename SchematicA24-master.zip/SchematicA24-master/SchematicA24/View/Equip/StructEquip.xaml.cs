﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SchematicA24.View
{
   /// <summary>
   /// Interaction logic for TempEquip.xaml
   /// </summary>
   public partial class TempEquip : UserControl
   {
      public TempEquip()
      {
         InitializeComponent();

         //this.DataContextChanged += (s, e) => zoomPanel.SnapToView();
      }

      private void Image_Loaded(object sender, RoutedEventArgs e)
      {
         var img = sender as Image;
         if (img.Source != null)
         {
            var width = img.Source.Width;
            var height = img.Source.Height;

            var canvas = zoomPanel.Content as Canvas;
            canvas.Width = width;
            canvas.Height = height;
            zoomPanel.ContentWidth = width;
            zoomPanel.ContentHeight = height;
         }
         zoomPanel.SnapToView();
      }
   }
}