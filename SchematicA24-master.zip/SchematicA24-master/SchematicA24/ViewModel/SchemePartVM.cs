﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Windows.Input;
using System.Xml.Linq;

namespace SchematicA24.ViewModel
{
   public class SchemePartVM : ViewModelBase
   {
      private static readonly string showPhotoCaption = "Показать фотографию";
      private static readonly string showSchemeCaption = "Показать схему";

      private readonly List<Slide> slides = new List<Slide>();
      private int current;

      public ICommand Show { get; set; }

      private string showBtnCaption;

      public string ShowBtnCaption
      {
         get { return showBtnCaption; }
         set { SetProperty(ref showBtnCaption, value, "ShowBtnCaption", "IsShowingPhoto"); }
      }

      public bool IsShowingPhoto { get; set; }

      public ICommand Previous { get; set; }

      public ICommand Next { get; set; }

      public ICommand Reset { get; set; }

      public string Id { get; set; }

      public string Name { get; set; }

      public string PhotoUri { get; set; }

      private Slide currentSlide;

      public Slide CurrentSlide
      {
         get { return currentSlide; }
         set { SetProperty(ref currentSlide, value, "CurrentSlide"); }
      }

      public SchemePartVM()
      {
         ShowBtnCaption = showPhotoCaption;

         Show = new DelegateCommand(() =>
         {
            IsShowingPhoto = !IsShowingPhoto;
            ShowBtnCaption = IsShowingPhoto ? showSchemeCaption : showPhotoCaption;
         },
         () => PhotoUri != null);

         Reset = new DelegateCommand(() => SetSlide(0), () => !IsShowingPhoto && slides.Count > 1);
         Next = new DelegateCommand(() => SetSlide(current + 1), () => !IsShowingPhoto && current < slides.Count - 1);
         Previous = new DelegateCommand(() => SetSlide(current - 1), () => !IsShowingPhoto && current > 0);
      }

      private void SetSlide(int slide)
      {
         current = slide;
         CurrentSlide = slides[current];
      }

      public override string ToString()
      {
         return Name;
      }

      public static SchemePartVM Create(string folder, string id)
      {
         var model = new SchemePartVM { Id = id };

         var manifest = XElement.Load(
            Assembly.GetExecutingAssembly()
                    .GetManifestResourceStream("SchematicA24.Resources." + folder + "." + id + ".manifest.xml"));

         var xAttribute = manifest.Attribute("name");
         if (xAttribute != null) model.Name = xAttribute.Value;
         var path = "/SchematicA24;component/Resources/" + folder + "/" + manifest.Attribute("id").Value + "/";

         if (manifest.Attribute("photoUri") != null)
            model.PhotoUri = path + manifest.Attribute("photoUri").Value;

         foreach (var node in manifest.Element("slides").Elements("slide"))
         {
            var slide = new Slide
                            {
                               Number = Int32.Parse(node.Attribute("n").Value),
                               ImageUri = path + node.Attribute("uri").Value,
                               Text = node.Value.Split('\n').Aggregate("", (p1, p2) => p1.Trim() + "\n\n" + p2.Trim()),
                            };
            model.slides.Add(slide);
         }
         model.SetSlide(0);
         return model;
      }

      public static SchemePartVM CreateEmpty(string name)
      {
         var model = new SchemePartVM();
         model.Name = name;
         return model;
      }
   }
}