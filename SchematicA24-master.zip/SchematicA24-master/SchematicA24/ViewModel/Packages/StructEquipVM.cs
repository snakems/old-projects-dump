﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Input;

namespace SchematicA24.ViewModel
{
   public class StructEquipVM : ViewModelBase, IPackage
   {
      public ICommand ShowPart { get; private set; }

      public List<SchemePartVM> Parts { get; set; }

      private SchemePartVM currentPart;

      public SchemePartVM CurrentPart
      {
         get { return currentPart; }
         set { SetProperty(ref currentPart, value, "CurrentPart", "IsShowingGeneral"); }
      }

      public bool IsShowingGeneral { get { return CurrentPart == null; } }

      public StructEquipVM()
      {
         Func<string, SchemePartVM> create = id => SchemePartVM.Create("Struct", id);
         Parts = new List<SchemePartVM>
                     {
                        create("_24"),
                        SchemePartVM.CreateEmpty("--------------- Тракт передачи ------------"),
                        create("_14"),
                        create("_12"),
                        create("_15"),
                        create("_13"),
                        create("_11"),
                        create("_20"),
                        SchemePartVM.CreateEmpty("---------------- Тракт приема -------------"),
                        create("_21"),
                        create("_22"),
                        create("_23"),
                        create("_10"),

                        create("_19"),
                        create("_16"),
                        create("_17"),
                        create("_18"),
                     };

         ShowPart = new DelegateCommand<string>(id =>
            CurrentPart = Parts.Find(p => p.Id == id));
      }
   }
}