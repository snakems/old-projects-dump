﻿using System;
using System.Collections.Generic;
using System.Windows.Input;

namespace SchematicA24.ViewModel
{
   public class ConvertEquipVM : ViewModelBase, IPackage
   {
      public ICommand ShowPart { get; private set; }

      public List<SchemePartVM> Parts { get; set; }

      private SchemePartVM currentPart;

      public SchemePartVM CurrentPart
      {
         get { return currentPart; }
         set { SetProperty(ref currentPart, value, "CurrentPart", "IsShowingGeneral"); }
      }

      public bool IsShowingGeneral { get { return CurrentPart == null; } }

      public ConvertEquipVM()
      {
         Func<string, SchemePartVM> create = id => SchemePartVM.Create("Convert", id);

         Parts = new List<SchemePartVM>
                     {
                        create("_10"),
                        create("_11"),
                        create("_100"),
                        SchemePartVM.CreateEmpty("--------------- Тракт передачи ------------"),
                        create("_12"),
                        create("_13"),
                        create("_15"),
                        create("_14"),
                        create("_16"),
                        SchemePartVM.CreateEmpty("--------------- Тракт приема ---  ---------"),
                        create("_22"),
                        create("_23"),
                        create("_25"),
                        create("_24"),
                        create("_26"),
                     };

         ShowPart = new DelegateCommand<string>(id =>
            CurrentPart = Parts.Find(p => p.Id == id));
      }
   }
}