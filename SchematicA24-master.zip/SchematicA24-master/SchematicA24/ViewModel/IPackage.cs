﻿using System.Collections.Generic;
using System.Windows.Input;

namespace SchematicA24.ViewModel
{
   internal interface IPackage
   {
      ICommand ShowPart { get; }

      List<SchemePartVM> Parts { get; set; }

      SchemePartVM CurrentPart { get; set; }

      bool IsShowingGeneral { get; }
   }
}