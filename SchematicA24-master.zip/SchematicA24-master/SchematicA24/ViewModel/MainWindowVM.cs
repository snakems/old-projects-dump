﻿using System.Windows.Input;
using SchematicA24.View;

namespace SchematicA24.ViewModel
{
   internal class MainWindowVM : ViewModelBase<IShellView>
   {
      private readonly ConvertEquipVM convertPackage;
      private readonly StructEquipVM structPackage;

      private IPackage currentPackage;

      public IPackage CurrentPackage
      {
         get { return currentPackage; }
         set { SetProperty(ref currentPackage, value, "CurrentPackage"); }
      }

      public ICommand ShowIndividual { get; set; }

      public ICommand ShowStruct { get; set; }

      public MainWindowVM(IShellView view)
         : base(view)
      {
         convertPackage = new ConvertEquipVM();
         structPackage = new StructEquipVM();

         ShowIndividual = new DelegateCommand(() => SetPackage(convertPackage));
         ShowStruct = new DelegateCommand(() => SetPackage(structPackage));

         SetPackage(convertPackage);

         ViewCore.DataContext = this;
      }

      private void SetPackage(IPackage package)
      {
         CurrentPackage = package;
         if (CurrentPackage != null) CurrentPackage.CurrentPart = null;
      }

      public void Show()
      {
         ViewCore.Show();
      }

      public void Close()
      {
         ViewCore.Close();
      }
   }
}