﻿namespace SchematicA24.ViewModel
{
   public class Slide
   {
      public int Number { get; set; }

      public string Text { get; set; }

      public string ImageUri { get; set; }
   }
}