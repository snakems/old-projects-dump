﻿using System;
using System.Windows;
using System.Windows.Data;

namespace SchematicA24.Converter
{
   internal class BoolToVisibilityConverter : IValueConverter
   {
      #region [ IValueConverter ]

      public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
      {
         if (parameter == null) parameter = false;

         // invert value if parameter specified
         if ((bool)value ^ (bool)parameter)
         {
            return Visibility.Visible;
         }
         return Visibility.Collapsed;
      }

      public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
      {
         throw new NotSupportedException();
      }

      #endregion [ IValueConverter ]
   }
}