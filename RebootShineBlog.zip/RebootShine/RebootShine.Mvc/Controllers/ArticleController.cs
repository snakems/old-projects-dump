﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using RebootShine.Web;

namespace RebootShine.Mvc.Controllers
{
   public class ArticleViewModel
   {
      public Article Article { get; set; }

      public User User { get; set; }
   }

   public class ArticleController : Controller
   {
      //
      // GET: /Article/

      public ActionResult Index()
      {
         return RedirectToAction("Index", "Home");
      }

      //
      // GET: /Article/Details/5

      public ActionResult Details(string id)
      {
         var article = Article.Find(id);
         if (article == null) throw new HttpException(404, "Article not found");

         var model = new ArticleViewModel()
         {
            Article = article.PrepareToRender(),
            User = RebootShine.User.Find(article.UserId),
         };
         return View(model);
      }

      //
      // GET: /Article/Create

      public ActionResult Create()
      {
         return View();
      }

      //
      // POST: /Article/Create

      [HttpPost]
      public ActionResult Create(FormCollection collection)
      {
         try
         {
            // TODO: Add insert logic here

            return RedirectToAction("Index");
         }
         catch
         {
            return View();
         }
      }

      //
      // GET: /Article/Edit/5

      public ActionResult Edit(int id)
      {
         return View();
      }

      //
      // POST: /Article/Edit/5

      [HttpPost]
      public ActionResult Edit(int id, FormCollection collection)
      {
         try
         {
            // TODO: Add update logic here

            return RedirectToAction("Index");
         }
         catch
         {
            return View();
         }
      }

      //
      // GET: /Article/Delete/5

      public ActionResult Delete(int id)
      {
         return View();
      }

      //
      // POST: /Article/Delete/5

      [HttpPost]
      public ActionResult Delete(int id, FormCollection collection)
      {
         try
         {
            // TODO: Add delete logic here

            return RedirectToAction("Index");
         }
         catch
         {
            return View();
         }
      }
   }
}