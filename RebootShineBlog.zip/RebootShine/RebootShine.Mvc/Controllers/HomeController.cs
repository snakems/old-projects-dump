﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using RebootShine.Web;

namespace RebootShine.Mvc.Controllers
{
   public class HomeController : Controller
   {
      //
      // GET: /Home/

      public ActionResult Index()
      {
         var articles = Article.All().OrderByDescending(p => p.PostedTime).Take(10).ToList();
         var model = new IndexViewModel()
         {
            Articles = articles.Select(a => new ArticleViewModel()
            {
               Article = a.PrepareToRender(),
               User = RebootShine.User.Find(a.UserId),
            }),
         };
         return View(model);
      }
   }

   public class IndexViewModel
   {
      public IEnumerable<ArticleViewModel> Articles { get; set; }
   }
}