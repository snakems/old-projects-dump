﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Http;
using System.Web.Mvc;
using System.Web.Routing;
using Ninject;
using Ninject.Web.Common;
using RebootShine.Data;

namespace RebootShine.Mvc
{
   // Note: For instructions on enabling IIS6 or IIS7 classic mode,
   // visit http://go.microsoft.com/?LinkId=9394801
   public class MvcApplication : NinjectHttpApplication
   {
      protected override void OnApplicationStarted()
      {
         base.OnApplicationStarted();

         var connectionString = ConfigurationManager.AppSettings.Get("MONGOLAB_URI")
                             ?? ConfigurationManager.AppSettings.Get("MongoUri");

         var databaseName = ConfigurationManager.AppSettings.Get("DatabaseName");

         Entity.SetContextProvider(type =>
            {
               var contextType = typeof(MongoContext<>).MakeGenericType(type);
               var context = Activator.CreateInstance(contextType, connectionString, databaseName);
               return context;
            });

         // TODO: make non-generic
         //Entity<Article>.SetContextProvider(() => new MongoContext<Article>(connectionString, databaseName));
         //Entity<User>.SetContextProvider(() => new MongoContext<User>(connectionString, databaseName));

         AreaRegistration.RegisterAllAreas();

         WebApiConfig.Register(GlobalConfiguration.Configuration);
         FilterConfig.RegisterGlobalFilters(GlobalFilters.Filters);
         RouteConfig.RegisterRoutes(RouteTable.Routes);
      }

      protected void Application_Error(object sender, EventArgs e)
      {
         if (!HttpContext.Current.IsCustomErrorEnabled)
            return;

         var exception = Server.GetLastError();
         var httpException = new HttpException(null, exception);

         var routeData = new RouteData();
         routeData.Values.Add("controller", "Error");
         routeData.Values.Add("action", "Index");
         routeData.Values.Add("httpException", httpException);

         Server.ClearError();

         var errorController = ControllerBuilder.Current.GetControllerFactory().CreateController(
             new RequestContext(new HttpContextWrapper(Context), routeData), "Error");

         errorController.Execute(new RequestContext(new HttpContextWrapper(Context), routeData));
      }

      protected override IKernel CreateKernel()
      {
         var kernel = new StandardKernel();

         //TODO: bind stuff

         return kernel;
      }
   }
}