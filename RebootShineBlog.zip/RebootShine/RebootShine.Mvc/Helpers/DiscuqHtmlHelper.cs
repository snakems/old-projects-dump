﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;

public static class DisqusHtmlHelper
{
   public static MvcHtmlString DisqusShowComments(this HtmlHelper htmlHelper, object articleId)
   {
      var commentsBuilder = new StringBuilder();
      var id = ConfigurationManager.AppSettings.Get("Disqus_Id"); // get the Disqus id from config file

      commentsBuilder.Append("<div id=\"disqus_thread\"></div>");

      commentsBuilder.Append("<script>");
      commentsBuilder.Append("var disqus_shortname = '" + id + "';");
      commentsBuilder.Append("var disqus_identifier = '" + articleId + "';");

      /* * * DON'T EDIT BELOW THIS LINE * * */
      commentsBuilder.Append("(function () {");
      commentsBuilder.Append("var dsq = document.createElement('script'); dsq.type = 'text/javascript'; dsq.async = true;");
      commentsBuilder.Append("dsq.src = 'http://" + id + ".disqus.com/embed.js';");

      commentsBuilder.Append("(document.getElementsByTagName('head')[0] || document.getElementsByTagName('body')[0]).appendChild(dsq);");
      commentsBuilder.Append("})();");
      commentsBuilder.Append("</script>");

      commentsBuilder.Append("<noscript>");
      commentsBuilder.Append("Please enable JavaScript to view the <a href=\"http://disqus.com/?ref_noscript\">comments");
      commentsBuilder.Append("powered by Disqus.</a>");
      commentsBuilder.Append("</noscript>");
      return MvcHtmlString.Create(commentsBuilder.ToString());
   }

   public static MvcHtmlString DisqusCommentsCounter(this HtmlHelper htmlHelper)
   {
      var commentsBuilder = new StringBuilder();
      var id = ConfigurationManager.AppSettings.Get("Disqus_Id"); // get the Disqus id from config file

      commentsBuilder.Append("<script>");
      commentsBuilder.Append("var disqus_shortname = '" + id + "';");

      /* * * DON'T EDIT BELOW THIS LINE * * */
      commentsBuilder.Append("(function () {");
      commentsBuilder.Append("var dsq = document.createElement('script'); dsq.type = 'text/javascript'; dsq.async = true;");
      commentsBuilder.Append("dsq.src = 'http://" + id + ".disqus.com/count.js';");

      commentsBuilder.Append("(document.getElementsByTagName('head')[0] || document.getElementsByTagName('body')[0]).appendChild(dsq);");
      commentsBuilder.Append("}());");
      commentsBuilder.Append("</script>");

      return MvcHtmlString.Create(commentsBuilder.ToString());
   }
}