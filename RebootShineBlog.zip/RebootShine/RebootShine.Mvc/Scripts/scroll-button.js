﻿$(function () {
   var vel = 5000;
   var min_height = 200;

   var scrolling = false;
   var scrolled_up = false;
   var last_scroll = 0;

   $(window).scroll(function () {
      var button = $('#scroll-button');
      if (!button) {
         console.log("No scroll button was found.");
         return false;
      };

      if (scrolling || scrolled_up || $(document).scrollTop() > min_height) {
         if (button.is(":hidden")) {
            button.show();
            //button.animate({ width: 'toggle' });
         }
      } else {
         button.hide();
         //button.animate({ width: 'toggle' });
      }

      if (scrolled_up && $(document).scrollTop() > min_height) {
         scrolled_up = false;
      }
   });

   $('#scroll-button').on('click', function () {
      if (scrolling) return false;

      var height = scrolled_up ? last_scroll : $(document).scrollTop();
      var scroll_amount = scrolled_up ? last_scroll : 0;
      var time = height / vel * 1000;  // Время за которое должна страница прокрутиться

      if (scrolled_up) scrolled_up = false;
      last_scroll = $(document).scrollTop();

      scrolling = true;
      $('body,html').animate({
         scrollTop: scroll_amount
      }, time, function () {
         scrolling = false;
         scrolled_up = true;
      });

      return false;
   });
});