﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Bson.Serialization.IdGenerators;

namespace RebootShine
{
   public abstract class Entity<T> : Entity where T : Entity
   {
      public static IQueryable<T> All()
      {
         // TODO: dispose context?
         var context = GetContext<T>();
         return context.All();
      }

      public static T Find(string id)
      {
         return All().FirstOrDefault(e => e.Id == id);
      }

      public void Save()
      {
         using (var context = GetContext<T>())
         {
            context.Save((T)(object)this);
         }
      }

      public void Delete()
      {
         using (var context = GetContext<T>())
         {
            context.Delete(this.Id);
         }
      }
   }

   public abstract class Entity : IEquatable<Entity>
   {
      [BsonId(IdGenerator = typeof(StringObjectIdGenerator))]
      public string Id { get; set; }

      #region IEquatable, Equals and GetHashCode

      public bool Equals(Entity other)
      {
         if (other == null) return false;
         return this.Id == other.Id;
      }

      public override bool Equals(object obj)
      {
         if (obj == null) return false;

         var entity = obj as Entity;
         if (entity == null) return false;

         return this.Id == entity.Id;
      }

      public override int GetHashCode()
      {
         return this.Id.GetHashCode();
      }

      #endregion IEquatable, Equals and GetHashCode

      #region Static

      private static Func<Type, object> getContext;

      protected static IBlogContext<T> GetContext<T>() where T : Entity
      {
         return (IBlogContext<T>)GetContext(typeof(T));
      }

      protected static object GetContext(Type type)
      {
         if (getContext == null) throw new InvalidOperationException("Context provider is not set.");

         return getContext(type);
      }

      public static void SetContextProvider(Func<Type, object> provider)
      {
         if (provider == null) throw new ArgumentNullException("provider");

         getContext = provider;
      }

      #endregion Static
   }
}