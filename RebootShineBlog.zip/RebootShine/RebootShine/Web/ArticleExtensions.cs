﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace RebootShine.Web
{
   public static class ArticleExtensions
   {
      private static string[] allowedTags
         = { "b", "i", "u", "s", "video", "img", "url" };

      public static Article PrepareToRender(this Article post)
      {
         post.Title = post.Title;
         post.Contents = ParseString(post.Contents);

         return post;
      }

      private static string ParseString(string toParse)
      {
         var processingText = HttpUtility.HtmlEncode(toParse);

         return processingText.ToHtml(allowedTags);
      }
   }
}