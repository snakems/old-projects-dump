﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace RebootShine.Web
{
   internal static class ToHtmlConverter
   {
      private static Dictionary<string, Func<string, string>> parsers;

      static ToHtmlConverter()
      {
         parsers = new Dictionary<string, Func<string, string>>();

         Func<string, Func<string, string>> createFormatTag = t =>
         {
            return text =>
            {
               var imageRegex = String.Format(@"\[{0}\](?'value'.*?)\[/{0}\]", t);
               var expr = new Regex(imageRegex,
                  RegexOptions.IgnoreCase | RegexOptions.Singleline | RegexOptions.Compiled);
               return expr.Replace(text, m =>
               {
                  var imgUrl = m.Groups["value"].Value;
                  if (String.IsNullOrWhiteSpace(imgUrl)) return String.Empty;

                  return String.Format("<{0}>{1}</{0}>", t, imgUrl);
               });
            };
         };

         parsers.Add(
            "video",
            text =>
            {
               var videoRegex = @"\[video\](?'value'.*?)\[/video\]";
               var expr = new Regex(videoRegex,
                  RegexOptions.IgnoreCase | RegexOptions.Singleline | RegexOptions.Compiled);
               return expr.Replace(text, m =>
               {
                  var videoId = m.Groups["value"].Value;
                  if (String.IsNullOrWhiteSpace(videoId)) return String.Empty;

                  return "<iframe class=\"youtube-player\""
                        + "type=\"text/html\""
                        + "width=\"640\" height=\"385\""
                        + "src=\"http://www.youtube.com/embed/"
                        + videoId + "\""
                        + " frameborder=\"0\"></iframe>";
               });
            });
         parsers.Add(
            "img",
            text =>
            {
               var imageRegex = @"\[img\](?'value'.*?)\[/img\]";
               var expr = new Regex(imageRegex,
                  RegexOptions.IgnoreCase | RegexOptions.Singleline | RegexOptions.Compiled);
               return expr.Replace(text, m =>
               {
                  var imgUrl = m.Groups["value"].Value;
                  if (String.IsNullOrWhiteSpace(imgUrl)) return String.Empty;

                  return String.Format("<a target=\"_blank\" href=\"{0}\"><img src=\"{0}\"></a>", imgUrl);
               });
            });
         parsers.Add(
            "url",
            text =>
            {
               var imageRegex = @"\[url=(?'href'.*?)\](?'value'.*?)\[/url\]";
               var expr = new Regex(imageRegex,
                  RegexOptions.IgnoreCase | RegexOptions.Singleline | RegexOptions.Compiled);
               return expr.Replace(text, m =>
               {
                  var urlHref = m.Groups["href"].Value;
                  var urlName = m.Groups["value"].Value;
                  if (String.IsNullOrWhiteSpace(urlHref)) return String.Empty;
                  if (String.IsNullOrWhiteSpace(urlName)) return String.Empty;

                  return String.Format("<a href=\"{0}\">{1}</a>", urlHref, urlName);
               });
            });
         parsers.Add(
            "b",
            createFormatTag("b"));
         parsers.Add(
            "i",
            createFormatTag("i"));
         parsers.Add(
            "u",
            createFormatTag("u"));
         parsers.Add(
            "s",
            createFormatTag("s"));
      }

      public static string ToHtml(this string text, params string[] allowedTags)
      {
         text = text.Split(new string[] { "\n\n" }, StringSplitOptions.RemoveEmptyEntries)
                    .Select(p => "<p>" + p + "</p>")
                    .Aggregate("", (p1, p2) => p1 + p2);

         foreach (var tag in allowedTags)
         {
            if (parsers.ContainsKey(tag))
               text = parsers[tag](text);
         }
         return text;
      }
   }
}