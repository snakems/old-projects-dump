﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RebootShine
{
   public class Article : Entity<Article>
   {
      public string UserId { get; set; }

      public string Title { get; set; }

      public string Contents { get; set; }

      public DateTime PostedTime { get; set; }

      public IList<string> Tags { get; set; }

      public Article()
      {
         Tags = new List<string>();
      }
   }
}