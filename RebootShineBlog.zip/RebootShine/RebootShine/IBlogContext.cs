﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RebootShine
{
   public interface IBlogContext<T> : IDisposable where T : Entity
   {
      IQueryable<T> All();

      void Save(T item);

      void Delete(string id);
   }
}