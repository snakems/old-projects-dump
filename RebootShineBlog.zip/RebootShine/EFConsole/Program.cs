﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RebootShine;
using RebootShine.Data;

namespace EFConsole
{
   internal class Program
   {
      private static void Main(string[] args)
      {
         var connectionString = "mongodb://localhost";
         var databaseName = "RebootShine";

         Entity.SetContextProvider(type =>
         {
            var contextType = typeof(MongoContext<>).MakeGenericType(type);
            var context = Activator.CreateInstance(contextType, connectionString, databaseName);
            return context;
         });

         //var user = new User()
         //{
         //   Name = "Andrew",
         //   Email = "weratt@gmail.com",
         //   PasswordHash = "arxxalt".GetHashCode().ToString(),
         //};

         //user.Save();

         //var articles = new List<Article>()
         //{
         //   new Article() { Title = "Article 1", Contents = "Bla-bla-bla", UserId = user.Id, PostedTime = DateTime.UtcNow, Tags = new List<string>() { "Tag1", "Tag2" } },
         //   new Article() { Title = "Article 2", Contents = "Ble-ble-ble", UserId = user.Id, PostedTime = DateTime.UtcNow, Tags = new List<string>() { "Tag3", "Tag4" } },
         //   new Article() { Title = "Article 3", Contents = "Blu-blu-blu", UserId = user.Id, PostedTime = DateTime.UtcNow, Tags = new List<string>() { "Tag5", "Tag6" } },
         //   new Article() { Title = "Article 4", Contents = "Bly-bly-bly", UserId = user.Id, PostedTime = DateTime.UtcNow, Tags = new List<string>() { "Tag3", "Tag8" } },
         //   new Article() { Title = "Article 5", Contents = "Bli-bli-bli", UserId = user.Id, PostedTime = DateTime.UtcNow, Tags = new List<string>() { "Tag3", "Tag10" } },
         //   new Article() { Title = "Article 6", Contents = "Blo-blo-blo", UserId = user.Id, PostedTime = DateTime.UtcNow, Tags = new List<string>() { "Tag8", "Tag4" } },
         //};

         //foreach (var article in articles)
         //{
         //   article.Save();
         //}

         var ar = Article.All().ToList();
         Console.ReadKey();
      }
   }
}