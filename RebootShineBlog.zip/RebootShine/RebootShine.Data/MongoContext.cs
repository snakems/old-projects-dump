﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MongoDB.Driver;
using MongoDB.Driver.Builders;

namespace RebootShine.Data
{
   public class MongoContext<T> : IBlogContext<T> where T : Entity
   {
      private MongoDatabase db;

      public MongoContext(string connectionString, string databaseName)
      {
         var client = new MongoClient(connectionString);
         db = client.GetServer().GetDatabase(databaseName);
      }

      private MongoCollection<T> GetCollection()
      {
         return db.GetCollection<T>(typeof(T).Name);
      }

      public IQueryable<T> All()
      {
         return GetCollection().FindAll().AsQueryable();
      }

      public void Save(T item)
      {
         if (item == null) throw new ArgumentNullException("item", "Item cannot be null");
         GetCollection().Save(item);
      }

      public void Delete(string id)
      {
         if (id == null) throw new ArgumentNullException("id", "Id cannot be null");

         GetCollection().Remove(Query.EQ("_id", id));
      }

      public void Dispose()
      {
      }
   }
}