using System;
using System.Collections;
using System.Linq;
using UnityEngine;

public class Combat : MonoBase
{
   public int Health;
   public int Stamina;
   public int Power;

   protected bool dead;

   internal bool Dead
   {
      get { return dead; }
      set { dead = value; if (dead) OnDied(); }
   }

   public event EventHandler Died;

   // TODO: add amount of damage received
   public event EventHandler DamageReceived;

   public void TakeDamage(int damage)
   {
      Health -= damage;
      OnDamageReceived();
      if (Health <= 0) Dead = true;
   }

   public virtual void Attack()
   {
      // TODO: animation
      transform.FindChild("Weapon").animation.Play();

      var cellInFront = DungeonMap.GetCellInDirection(transform.position, transform.forward);
      var target = cellInFront.gameObjects.FirstOrDefault(o => o.GetComponent<Combat>() != null);

      if (target != null)
      {
         var targetCombat = target.GetComponent<Combat>();
         targetCombat.TakeDamage(Power);
      }
   }

   protected virtual void OnDamageReceived()
   {
      InvokeHandler(DamageReceived);
   }

   protected virtual void OnDied()
   {
      InvokeHandler(Died);
   }

   private void InvokeHandler(EventHandler handler)
   {
      if (handler != null)
      {
         handler(this, EventArgs.Empty);
      }
   }
}