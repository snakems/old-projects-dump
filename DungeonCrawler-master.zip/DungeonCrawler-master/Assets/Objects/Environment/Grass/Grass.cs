using UnityEngine;

public class Grass : MonoBehaviour
{
   public float Period, Amplitude;
   private float rnd;

   private void Start()
   {
      rnd = Random.Range(0f, 10f);
   }

   private void Update()
   {
      Matrix4x4 skew = Matrix4x4.identity;
      float d = Amplitude * Mathf.Sin((rnd + Time.time) / Period * Mathf.PI * 2);
      skew[0, 2] = d;
      skew[0, 3] = d / 2 * transform.localScale.y;
      renderer.material.SetMatrix("Transform", skew);
   }
}