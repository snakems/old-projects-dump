using System;
using System.Collections.Generic;
using UnityEngine;

public class DungeonMap : MonoSingleton<DungeonMap>
{
   private readonly float MaxDistance = 10.0f;
   private List<DungeonCell> cells = new List<DungeonCell>();

   public LayerMask DungeonMapLayer;

   // Use this for initialization
   public void Start()
   {
      var objects = gameObject.GetComponentsInChildren<DungeonCell>();
      cells.AddRange(objects);
   }

   // Update is called once per frame
   private void Update()
   {
   }

   public static DungeonCell GetCellInPosition(Vector3 position)
   {
      // TODO: bad - do something
      if (position.y == 0) position += new Vector3(0, 2, 0);

      // TODO: bounds - not such a good solution, maybe rays?
      return Instance.cells.Find(c => c.collider.bounds.Contains(position));
   }

   public static DungeonCell GetCellInDirection(Vector3 position, Vector3 direction)
   {
      return Instance.getCellInDirection(position, direction);
   }

   public DungeonCell getCellInDirection(Vector3 position, Vector3 direcion)
   {
      // TODO: bad - do something
      if (position.y == 0) position += new Vector3(0, 2, 0);

      RaycastHit hit;
      if (Physics.Raycast(position, direcion, out hit, MaxDistance, DungeonMapLayer))
      {
         var obj = hit.transform.gameObject;
         var cell = obj.GetComponent<DungeonCell>();
         if (cell == null)
         {
            throw new Exception("Expected cell, but found: " + obj.name + "( " + obj + "). Maybe you have broken Dungeon Map Layer?");
         }
         return cell;
      }
      else
      {
         throw new Exception("Something bad happened, there are no cell from " + position + " in direction " + direcion + ".");
      }
   }
}