using System.Collections.Generic;
using UnityEngine;

public class DungeonCell : MonoBase
{
   internal List<GameObject> gameObjects = new List<GameObject>();

   private void OnTriggerEnter(Collider other)
   {
      //if (other.gameObject.name != "Wall")
      //   print("Enter " + other.gameObject.name + " at " + other.gameObject.transform.position);
      Add(other.gameObject);
   }

   private void OnTriggerExit(Collider other)
   {
      //if (other.gameObject.name != "Wall")
      //   print("Exit " + other.gameObject.name + " at " + other.gameObject.transform.position);
      Remove(other.gameObject);
   }

   public void Add(GameObject gameObject)
   {
      if (!gameObjects.Contains(gameObject))
         gameObjects.Add(gameObject);
   }

   public void Remove(GameObject gameObject)
   {
      if (gameObjects.Contains(gameObject))
         gameObjects.Remove(gameObject);
   }

   private void OnDrawGizmos()
   {
      var pos = collider.bounds.center;

      var color = Color.cyan;
      color.r /= 1.3f; color.g /= 1.3f; color.b /= 1.3f;
      Gizmos.color = color;

      Gizmos.DrawWireCube(pos, Vector3.one * 4);
   }
}