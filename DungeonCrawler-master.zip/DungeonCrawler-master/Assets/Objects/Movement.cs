using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class Movement : MonoBase
{
   protected DungeonCell currentCell;

   protected List<string> impassableObjects = new List<string>
   {
      "Wall", "Goblin", "Eyeball", "Hero",
   };

   protected bool CanMoveToCell(DungeonCell cell)
   {
      // TODO: not name, maybe tag.
      return !cell.gameObjects.Any(item => impassableObjects.Contains(item.name));
   }

   // Use this for initialization
   public virtual void Start()
   {
      currentCell = DungeonMap.GetCellInPosition(transform.position);
      if (currentCell != null) RegisterInCell(currentCell);
   }

   public void InstantMoveToCell(DungeonCell cell)
   {
      // We assign creature to the next cel right now because
      // other entities need to know its future position
      RegisterInCell(cell);

      var movement = cell.transform.position - transform.position;
      transform.Translate(movement);
   }

   public void MoveToCell(DungeonCell cell, Action onFinished = null)
   {
      // We assign creature to the next cel right now because
      // other entities need to know its future position
      RegisterInCell(cell);

      var movement = cell.transform.position - transform.position;
      StartCoroutine(transform.SmoothTranslate(movement, GameManager.TurnDuration, onFinished));
   }

   public void InstantRotate(bool right)
   {
      var clockwise = right ? 1 : -1;
      transform.Rotate(transform.up * 90 * clockwise);
   }

   public void Rotate(bool right, Action onFinished = null)
   {
      var clockwise = right ? 1 : -1;
      StartCoroutine(transform.SmoothRotate(transform.up * 90 * clockwise, GameManager.TurnDuration, onFinished));
   }

   private void RegisterInCell(DungeonCell cell)
   {
      if (currentCell != null) currentCell.Remove(gameObject);
      cell.Add(gameObject);
      currentCell = cell;
   }

   public override void OnDestroy()
   {
      currentCell.Remove(gameObject);
      base.OnDestroy();
   }
}