using System.Collections;
using UnityEngine;

public class HeroMovement : Movement
{
   private bool isRotating;

   public bool Move(Vector3 direction)
   {
      var cell = DungeonMap.GetCellInDirection(transform.position, direction);
      if (CanMoveToCell(cell))
      {
         MoveToCell(cell);
         return true;
      }
      return false;
   }

   public void Rotate(bool right)
   {
      if (isRotating) return;

      isRotating = true;
      Rotate(right, () => isRotating = false);
   }
}