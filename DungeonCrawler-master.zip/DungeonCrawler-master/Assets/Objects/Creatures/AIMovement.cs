using System;
using System.Collections;
using UnityEngine;

public class AIMovement : Movement
{
   public virtual bool MakeTurn()
   {
      // TODO: think on return type
      return true;
   }
}