using System.Collections;
using UnityEngine;

public class GoblinMovement : AIMovement
{
   public override bool MakeTurn()
   {
      return true;
   }
}