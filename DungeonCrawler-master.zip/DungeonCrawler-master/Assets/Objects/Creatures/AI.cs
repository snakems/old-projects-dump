using System;
using UnityEngine;

public class AI : MonoBase
{
   // Use this for initialization
   protected AIMovement movement;
   protected Combat combat;

   public void Start()
   {
      movement = GetComponent<AIMovement>();
      if (movement == null)
      {
         throw new Exception("AIMovement must be added to the object in order to move");
      }
      combat = GetComponent<Combat>();
      if (combat == null)
      {
         throw new Exception("Combat must be added to the object in order to move");
      }
      combat.Died += combat_Died;
      combat.DamageReceived += combat_DamageReceived;
      GameManager.Instance.AddMonster(this);
   }

   private void combat_Died(object sender, EventArgs e)
   {
      Debug.Log(name + " just died");
      DestroyImmediate(gameObject);
   }

   private void combat_DamageReceived(object sender, EventArgs e)
   {
      Debug.Log(name + " just received damage");
   }

   // Update is called once per frame
   private void Update()
   {
   }

   public void PlayAI()
   {
      movement.MakeTurn();
   }

   public override void OnDestroy()
   {
      GameManager.Instance.RemoveMonster(this);
      base.OnDestroy();
   }
}