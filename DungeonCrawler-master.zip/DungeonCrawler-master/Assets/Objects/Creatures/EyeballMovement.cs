using System.Collections;
using UnityEngine;

public class EyeballMovement : AIMovement
{
   public override bool MakeTurn()
   {
      var clockwise = Random.value > 0.5;

      var directions = 4;
      while (directions-- > 0)
      {
         var cell = DungeonMap.GetCellInDirection(transform.position, transform.forward);
         if (CanMoveToCell(cell))
         {
            MoveToCell(cell);
            break;
         }
         else
         {
            InstantRotate(clockwise);
         }
      }
      return true;
   }
}