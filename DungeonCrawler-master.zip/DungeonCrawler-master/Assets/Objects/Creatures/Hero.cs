using System;
using System.Collections;
using System.Linq;
using UnityEngine;

public class Hero : MonoBase
{
   private HeroMovement movement;
   private Combat combat;

   private void Start()
   {
      movement = GetComponent<HeroMovement>();
      if (movement == null)
      {
         throw new Exception("HeroMovement must be added to the object in order to move");
      }
      combat = GetComponent<Combat>();
      if (combat == null)
      {
         throw new Exception("Combat must be added to the object in order to move");
      }
      combat.Died += combat_Died;
   }

   private void combat_Died(object sender, EventArgs e)
   {
      Debug.Log("Hero just died");
   }

   // Update is called once per frame
   private void Update()
   {
      if (GameManager.TurnInProgress) return;

      var endTurn = false;
      if (Input.GetKeyDown(KeyCode.W) || Input.GetKeyDown(KeyCode.UpArrow))
      {
         endTurn |= movement.Move(transform.forward);
      }
      if (Input.GetKeyDown(KeyCode.S) || Input.GetKeyDown(KeyCode.DownArrow))
      {
         endTurn |= movement.Move(-transform.forward);
      }
      if (Input.GetKeyDown(KeyCode.A) || Input.GetKeyDown(KeyCode.LeftArrow))
      {
         movement.Rotate(false);
      }
      if (Input.GetKeyDown(KeyCode.D) || Input.GetKeyDown(KeyCode.RightArrow))
      {
         movement.Rotate(true);
      }
      if (Input.GetKeyDown(KeyCode.LeftControl))
      {
         combat.Attack();
         endTurn = true;
      }

      if (endTurn || Input.GetKeyDown(KeyCode.Space))
      {
         GameManager.EndTurn();
      }
   }

   private void OnDrawGizmos()
   {
      var pos = transform.position; pos.y += 2f;

      Gizmos.color = Color.magenta;
      Gizmos.DrawSphere(pos, 0.5f);
   }
}