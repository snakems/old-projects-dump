using System.Collections;
using UnityEngine;

public class SignalSender : MonoBehaviour
{
   public bool onlyOnce;
   public ReceiverItem[] receivers;

   private bool hasFired = false;

   public void SendSignals(MonoBehaviour sender)
   {
      if (hasFired == false || onlyOnce == false)
      {
         for (var i = 0; i < receivers.Length; i++)
         {
            sender.StartCoroutine(receivers[i].SendWithDelay(sender));
         }
         hasFired = true;
      }
   }
}

public class ReceiverItem
{
   public GameObject receiver;
   public string action = "OnSignal";
   public float delay;

   public IEnumerator SendWithDelay(MonoBehaviour sender)
   {
      yield return new WaitForSeconds(delay);
      if (receiver)
      {
         receiver.SendMessage(action);
      }
      else
      {
         Debug.LogWarning("No receiver of signal \"" + action + "\" on object " + sender.name + " (" + sender.GetType().Name + ")", sender);
      }
   }
}