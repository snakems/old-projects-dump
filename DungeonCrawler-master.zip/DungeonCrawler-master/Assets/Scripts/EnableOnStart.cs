using UnityEngine;

public class EnableOnStart : MonoBehaviour
{
   public GameObject[] Objects;

   // Use this for initialization
   private void Start()
   {
      foreach (var obj in Objects)
      {
         obj.SetActive(true);
      }
   }
}