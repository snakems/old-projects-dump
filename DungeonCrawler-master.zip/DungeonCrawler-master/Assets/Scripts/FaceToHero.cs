using UnityEngine;

[ExecuteInEditMode]
public class FaceToHero : MonoBehaviour
{
   private GameObject hero;

   // Use this for initialization
   private void Start()
   {
      hero = GameObject.Find("Hero");
   }

   // Update is called once per frame
   private void Update()
   {
      if (hero == null) return;

      var direction = -hero.transform.forward;
      transform.rotation = Quaternion.LookRotation(direction);
   }
}