﻿using UnityEngine;

public class MonoSingleton<T> : MonoBase where T : MonoBehaviour
{
   public static T Instance = null;

   public virtual void Awake()
   {
      if (Instance == null)
      {
         Instance = this as T;
      }
      else
      {
         Debug.LogWarning("There should only be one of these");
      }
   }
}