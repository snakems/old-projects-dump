using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MonoBase : MonoBehaviour
{
   private List<GameObject> DestructionRegistry = new List<GameObject>();
   private Dictionary<Type, Component> cachedComponents = new Dictionary<Type, Component>();

   public T _<T>() where T : Component
   {
      if (!cachedComponents.ContainsKey(typeof(T)))
         cachedComponents[typeof(T)] = GetComponent<T>();
      return cachedComponents[typeof(T)] as T;
   }

   public new Transform transform { get { return _<Transform>(); } }

   public new Collider collider { get { return _<Collider>(); } }

   public new Rigidbody rigidbody { get { return _<Rigidbody>(); } }

   public void RegisterForDestruction(GameObject g)
   {
      DestructionRegistry.Add(g);
   }

   public void UnregisterForDestruction(GameObject g)
   {
      DestructionRegistry.Remove(g);
   }

   public virtual void OnDestroy()
   {
      foreach (var o in DestructionRegistry)
         Destroy(o);
      DestructionRegistry.Clear();
   }
}