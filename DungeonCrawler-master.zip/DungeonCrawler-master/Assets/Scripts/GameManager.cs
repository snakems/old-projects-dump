using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameManager : MonoSingleton<GameManager>
{
   public static float TurnDuration = 0.25f;
   private bool turnInProgress;

   private List<AI> monsters = new List<AI>();

   public static bool TurnInProgress { get { return Instance.turnInProgress; } }

   public void AddMonster(AI monster)
   {
      monsters.Add(monster);
   }
   public void RemoveMonster(AI monster)
   {
      monsters.Remove(monster);       
   }

   public static void EndTurn()
   {
      Instance.StartCoroutine(Instance.DoTurn());
   }

   private IEnumerator DoTurn()
   {
      turnInProgress = true;
      PlayAI();
      yield return new WaitForSeconds(TurnDuration);
      turnInProgress = false;
      yield return new WaitForEndOfFrame();
   }

   private void PlayAI()
   {
      foreach (var monster in monsters)
      {
         monster.PlayAI();
      }
   }
}