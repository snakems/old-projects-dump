﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;

public static class TransformExtensions
{
   public static IEnumerator SmoothTranslate(this Transform thisTransform, Vector3 movement, float value, Action finished = null)
   {
      var startPos = thisTransform.position;
      var endPos = startPos + movement;
      var rate = 1.0f / value;
      var t = 0.0f;
      while (t < 1.0)
      {
         t += Time.deltaTime * rate;
         thisTransform.position = Vector3.Lerp(startPos, endPos, t);
         yield return null;
      }
      if (finished != null) finished();
   }

   public static IEnumerator SmoothRotate(this Transform thisTransform, Vector3 degrees, float time, Action finished = null)
   {
      var startRotation = thisTransform.rotation;
      var endRotation = thisTransform.rotation * Quaternion.Euler(degrees);
      var rate = 1.0f / time;
      var t = 0.0f;
      while (t < 1.0)
      {
         t += Time.deltaTime * rate;
         thisTransform.rotation = Quaternion.Slerp(startRotation, endRotation, t);
         yield return null;
      }
      if (finished != null) finished();
   }
}