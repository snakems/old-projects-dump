﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using MovablePython;
using ScreenGrabber.Properties;

namespace ScreenGrabber
{
   internal class GrabberTray : ApplicationContext
   {
      private Hotkey hk;
      private NotifyIcon icon;

      private Form dummy;

      public GrabberTray()
      {
         icon = new NotifyIcon();
         icon.Icon = Resources.Screenshot;
         icon.ContextMenuStrip = GetContextMenu();

         dummy = new Form();
         hk = GetHotKeyFromString(Settings.Default.HotKey);
         hk.Pressed += grabToolStripMenuItem_Click;
         if (!hk.GetCanRegister(dummy))
            Console.WriteLine("Can't register hotkey!");
         else
            hk.Register(dummy);

         icon.Visible = true;
      }

      private ContextMenuStrip GetContextMenu()
      {
         var contextMenu = new ContextMenuStrip();
         var toolStrip = new ToolStripMenuItem("Grab");
         toolStrip.Click += new EventHandler(grabToolStripMenuItem_Click);
         contextMenu.Items.Add(toolStrip);
         toolStrip = new ToolStripMenuItem("Open Folder");
         toolStrip.Click += new EventHandler(grabFolderToolStripMenuItem_Click);
         contextMenu.Items.Add(toolStrip);
         var separator = new ToolStripSeparator();
         separator.Size = new Size(134, 6);
         contextMenu.Items.Add(separator);
         toolStrip = new ToolStripMenuItem("Exit");
         toolStrip.Click += new EventHandler(exitToolStripMenuItem_Click);
         contextMenu.Items.Add(toolStrip);
         return contextMenu;
      }

      private Hotkey GetHotKeyFromString(string hotkey)
      {
         var mods = new Dictionary<string, bool>()
         {
            {"Ctrl", false}, {"Alt", false}, {"Shift",false}, {"Win",false},
         };

         try
         {
            var tokens = hotkey.Split('+').ToList();
            foreach (var mod in mods.Keys.ToList())
            {
               if (tokens.Contains(mod))
               {
                  tokens.Remove(mod);
                  mods[mod] = true;
               }
            }

            if (tokens.Count != 1) throw new ArgumentException();

            var keyString = tokens[0];
            var key = (Keys)Enum.Parse(typeof(Keys), keyString);
            return new Hotkey(key, mods["Shift"], mods["Ctrl"], mods["Alt"], mods["Win"]);
         }
         catch (Exception)
         {
            MessageBox.Show("Can't register hotkey, set to default Ctrl+Alt+G");
            return new Hotkey(Keys.G, false, true, true, false);
         }
      }

      private void grabToolStripMenuItem_Click(object sender, EventArgs e)
      {
         var rect = Screen.PrimaryScreen.Bounds;
         Bitmap bmpScreenShot = new Bitmap(rect.Width, rect.Height);
         using (var g = Graphics.FromImage(bmpScreenShot))
            g.CopyFromScreen(0, 0, 0, 0, rect.Size, CopyPixelOperation.SourceCopy);

         var grabber = new ScreenGrabber(bmpScreenShot);
         grabber.Show();
      }

      private void grabFolderToolStripMenuItem_Click(object sender, EventArgs e)
      {
         var baseFolder = Properties.Settings.Default.BaseFolder;
         System.Diagnostics.Process.Start(baseFolder);
      }

      private void exitToolStripMenuItem_Click(object sender, EventArgs e)
      {
         icon.Visible = false;
         hk.Unregister();
         Application.Exit();
      }
   }
}