﻿using System;
using System.Drawing;
using System.Globalization;
using System.Windows.Forms;

namespace ScreenGrabber
{
	public partial class ScreenGrabber : Form
	{
		#region Form level declarations

		private bool mouseDown = false;
		private Point mouseDownPoint = Point.Empty;
		private Point mousePoint = Point.Empty;
		private Pen pen = new Pen(Color.Black, 1);
		private SolidBrush brush = new SolidBrush(Color.FromArgb(128, Color.Gray));
		private Rectangle bounds = Rectangle.Empty;
		private Rectangle selectionWindow = Rectangle.Empty;

		private Bitmap image = null;

		#endregion

		public ScreenGrabber(Bitmap img)
		{
			InitializeComponent();
			image = img;

			bounds.X = 0;
			bounds.Y = 0;
			bounds.Width = Screen.PrimaryScreen.Bounds.Width;
			bounds.Height = Screen.PrimaryScreen.Bounds.Height;

			this.Size = new Size(bounds.Width, bounds.Height);
		}

		#region Events

		private void ScreenGrabber_Load(object sender, EventArgs e)
		{
			mousePoint = Cursor.Position;
		}

		private void ScreenGrabber_KeyDown(object sender, KeyEventArgs e)
		{
			if (e.KeyData == Keys.Escape)
			{
				this.Close();
			}
		}

		private void ScreenGrabber_MouseMove(object sender, MouseEventArgs e)
		{
			mousePoint = e.Location;
			Invalidate();
		}

		private void ScreenGrabber_MouseUp(object sender, MouseEventArgs e)
		{
			mouseDown = false;

			if (selectionWindow != Rectangle.Empty)
				Screenshot.TakeAndSave(image, selectionWindow);
			this.Close();
		}

		private void ScreenGrabber_MouseDown(object sender, MouseEventArgs e)
		{
			mouseDown = true;
			mousePoint = mouseDownPoint = e.Location;
		}

		private void ScreenGrabber_Paint(object sender, PaintEventArgs e)
		{
			using (var region = new Region(bounds))
			{
				e.Graphics.DrawImage(image, 0, 0);
				if (mouseDown)
				{
					selectionWindow = new Rectangle(
						 Math.Min(mouseDownPoint.X, mousePoint.X),
						 Math.Min(mouseDownPoint.Y, mousePoint.Y),
						 Math.Abs(mouseDownPoint.X - mousePoint.X),
						 Math.Abs(mouseDownPoint.Y - mousePoint.Y));
					region.Xor(selectionWindow);

					e.Graphics.FillRegion(brush, region);
					e.Graphics.DrawRectangle(pen, selectionWindow);

					string text = String.Format(CultureInfo.InvariantCulture,
						"{0}x{1}", selectionWindow.Width, selectionWindow.Height);
					Font font = new Font(FontFamily.GenericSansSerif, 11f, FontStyle.Regular);
					Size size = TextRenderer.MeasureText(e.Graphics, text, font);

					TextRenderer.DrawText(e.Graphics,
						text, font,
						new Rectangle(
							selectionWindow.Right - size.Width,
							selectionWindow.Bottom - size.Height,
							size.Width, size.Height),
						Color.Red,
						TextFormatFlags.WordBreak | TextFormatFlags.HorizontalCenter);
					font.Dispose();
				}
				else
				{
					e.Graphics.FillRegion(brush, region);
					e.Graphics.DrawLine(pen,
						 mousePoint.X, 0,
						 mousePoint.X, this.Size.Height);
					e.Graphics.DrawLine(pen,
						 0, mousePoint.Y,
						 this.Size.Width, mousePoint.Y);
				}
			}
		}

		#endregion
	}
}
