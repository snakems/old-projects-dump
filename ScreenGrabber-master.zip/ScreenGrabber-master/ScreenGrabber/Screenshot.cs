﻿using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.Windows.Forms;
using ScreenGrabber.Properties;

namespace ScreenGrabber
{
	public static class Screenshot
	{
		public static void TakeAndSave(Bitmap image, Rectangle rect)
		{
			var basePath = Settings.Default.BaseFolder;
			var baseUrl = Settings.Default.BaseUrl;
			using (var bitmap = TakeScreenshot(image, rect))
			{
				var name = DateTime.Now.ToString("yyyy'-'MM'-'dd'-'HH'-'mm'-'ss") + ".png";
				bitmap.Save(basePath + name, ImageFormat.Png);
				Clipboard.SetText(baseUrl + name);
			}
		}

		private static Bitmap TakeScreenshot(Bitmap image, Rectangle rect)
		{
			Bitmap screenshot = new Bitmap(rect.Width, rect.Height);
			using (var graphics = Graphics.FromImage(screenshot))
				graphics.DrawImage(image, 0, 0, rect, GraphicsUnit.Pixel);
			return screenshot;
		}
	}
}
