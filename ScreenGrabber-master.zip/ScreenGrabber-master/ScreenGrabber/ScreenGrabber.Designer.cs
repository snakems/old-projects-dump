﻿namespace ScreenGrabber
{
	partial class ScreenGrabber
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing)
			{
				if (components != null) components.Dispose();
				if (pen != null) pen.Dispose();
				if (brush != null) brush.Dispose();
				if (image != null) image.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.SuspendLayout();
			// 
			// ScreenGrabber
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.White;
			this.ClientSize = new System.Drawing.Size(284, 262);
			this.Cursor = System.Windows.Forms.Cursors.Cross;
			this.DoubleBuffered = true;
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			this.KeyPreview = true;
			this.Name = "ScreenGrabber";
			this.ShowInTaskbar = false;
			this.Text = "ScreenGrabber";
			this.TopMost = true;
			this.Load += new System.EventHandler(this.ScreenGrabber_Load);
			this.Paint += new System.Windows.Forms.PaintEventHandler(this.ScreenGrabber_Paint);
			this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.ScreenGrabber_KeyDown);
			this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.ScreenGrabber_MouseDown);
			this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.ScreenGrabber_MouseMove);
			this.MouseUp += new System.Windows.Forms.MouseEventHandler(this.ScreenGrabber_MouseUp);
			this.ResumeLayout(false);

		}

		#endregion

	}
}

