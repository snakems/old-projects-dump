﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using Blog.Domain;
using Blog.Infrastructure.Data;

namespace TestQueries
{
   internal class Program
   {
      private static void Main(string[] args)
      {
         var postRepository = new MongoDbArticleRepository("mongodb://localhost/UtBBlog?safe=true");
         var posts = postRepository.All().ToList();

         int i = 0;
         foreach (var post in posts)
         {
            post.Title = HttpUtility.HtmlDecode(post.Title);

            post.Preview = HttpUtility.HtmlDecode(post.Preview);
            post.Contents = HttpUtility.HtmlDecode(post.Contents);

            var tags = post.Tags.ToArray();
            post.Tags.Clear();
            post.AddTags(tags.Select(t => HttpUtility.HtmlDecode(t)).ToArray());
            postRepository.Save(post);

            Console.WriteLine("Post {0} of {1}", ++i, posts.Count);
         }

         i = 0;

         Console.WriteLine("Done");
         Console.ReadKey();
      }

      private class Proj
      {
         public DateTime PostedTime { get; set; }
      }

      private static Proj Convert(BlogArticle post)
      {
         return new Proj() { PostedTime = post.PostedTime };
      }
   }
}