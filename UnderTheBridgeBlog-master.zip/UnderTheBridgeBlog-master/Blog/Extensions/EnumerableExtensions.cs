using System;
using System.Collections.Generic;

namespace Blog.Extensions
{
   public static class EnumerableExtensions
   {
      public static IEnumerable<T> ForEach<T>(this IEnumerable<T> enumeration, Action<T> action)
      {
         if (enumeration == null) throw new ArgumentNullException("enumeration");
         if (action == null) throw new ArgumentNullException("action");

         foreach (T item in enumeration)
         {
            action(item);
            yield return item;
         }
      }
   }
}