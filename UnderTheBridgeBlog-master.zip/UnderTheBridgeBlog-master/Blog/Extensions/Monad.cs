using System;

namespace Blog.Extensions
{
   public static class Monad
   {
      public static TOut IfNotNull<TIn, TOut>(this TIn self, Func<TIn, TOut> extractor)
         where TIn : class
         where TOut : class
      {
         if (self == null)
            return null;
         return extractor(self);
      }

      public static void IfNotNullDo<TIn>(this TIn self, Action<TIn> action)
         where TIn : class
      {
         if (self != null) action(self);
      }
   }
}