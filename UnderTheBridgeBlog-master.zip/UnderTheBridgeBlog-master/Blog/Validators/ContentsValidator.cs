﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace Blog.Validators
{
   public class ContentsValidator
   {
      private readonly string newline = "\n";

      private readonly string TAG_PATTERN
         = @"(?'tag_start'\[/?)(?'tag'\w+)(=(?'attr'.*?))?(?'tag_end'/?\])";

      public string Validate(string contents)
      {
         var validated = contents;

         //Fix newlines
         validated = FixNewlines(validated);

         // Fix tags
         validated = ValidateTags(validated);

         return validated;
      }

      public string FixNewlines(string text)
      {
         return Regex.Replace(text, @"\r\n?|\n", newline);
      }

      public string ValidateTags(string text)
      {
         if (text == null) throw new ArgumentNullException("text", "Text  cannot be null.");

         Regex htmlTagExpression = new Regex(TAG_PATTERN,
            RegexOptions.Singleline | RegexOptions.IgnoreCase | RegexOptions.Compiled);

         Stack<string> tagsStack = new Stack<string>();

         var validated = htmlTagExpression.Replace(text, m =>
         {
            Group tag = m.Groups["tag"];

            var attr = m.Groups["attr"].Value.Replace(" ", "");
            var tagStartVal = m.Groups["tag_start"].Value.Replace(" ", "");
            var tagEndVal = m.Groups["tag_end"].Value.Replace(" ", "");

            if (tagStartVal == "[/")
            {
               var tags = String.Empty;
               bool invalid = true;
               while (invalid)
               {
                  if (!tagsStack.Any())
                     return String.Empty;

                  var previous = tagsStack.Pop();
                  if (previous == tag.Value)
                  {
                     tags += m.Value;
                     invalid = false;
                  }
                  else
                  {
                     tags += String.Format("[/{0}]", previous);
                  }
               }
               return tags.ToString();
            }
            else if (tagEndVal != "/]")
            {
               tagsStack.Push(tag.Value);
            }
            return m.Value;
         });

         while (tagsStack.Count > 0)
         {
            var tag = tagsStack.Pop();
            validated += String.Format("[/{0}]", tag);
         }

         return validated;
      }
   }
}