﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Blog.Domain;

namespace Blog.Validators
{
   public class PostValidator : IValueValidator<BlogArticle>
   {
      public bool Validate(BlogArticle article)
      {
         var validator = new ContentsValidator();

         article.Title = validator.Validate(article.Title);

         article.Contents = validator.Validate(article.Contents);

         var tags = article.Tags.ToArray();
         article.Tags.Clear();
         article.AddTags(tags.Select(t => validator.Validate(t)).ToArray());

         if (String.IsNullOrWhiteSpace(article.Title)
          || String.IsNullOrWhiteSpace(article.Contents)
          || String.IsNullOrWhiteSpace(article.Preview)
          || article.Tags.Count == 0)
         {
            return false;
         }

         return true;
      }
   }
}