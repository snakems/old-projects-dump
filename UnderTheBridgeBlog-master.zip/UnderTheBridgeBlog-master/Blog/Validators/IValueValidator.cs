﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Blog.Domain;

namespace Blog.Validators
{
   public interface IValueValidator<T> where T : Entity
   {
      bool Validate(T item);
   }
}