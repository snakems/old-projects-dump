using System;
using System.Runtime.Serialization;
using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Bson.Serialization.IdGenerators;

namespace Blog.Domain
{
   public abstract class Entity : IEquatable<Entity>
   {
      [BsonId(IdGenerator = typeof(StringObjectIdGenerator))]
      public string Id { get; set; }

      public bool Equals(Entity other)
      {
         if (other == null) return false;
         return Id == other.Id;
      }
   }
}