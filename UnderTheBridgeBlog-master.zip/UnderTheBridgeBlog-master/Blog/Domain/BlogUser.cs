using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;

namespace Blog.Domain
{
   public class BlogUser : Entity
   {
      public string Name { get; set; }

      public string Email { get; set; }

      public bool EmailHidden { get; set; }

      public string PasswordHash { get; set; }

      public bool Banned { get; set; }

      public Sex Sex { get; set; }

      public IList<string> Roles { get; private set; }

      public IList<PostStatsEntry> PostStats { get; private set; }

      public BlogUser()
      {
         Roles = new List<string>();
         PostStats = new List<PostStatsEntry>();
      }
   }

   public enum Sex
   {
      Male,
      Female,
      Undefined,
   }
}