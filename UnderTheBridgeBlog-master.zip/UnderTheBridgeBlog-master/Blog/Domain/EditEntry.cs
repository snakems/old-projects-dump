using System;
using System.Runtime.Serialization;

namespace Blog.Domain
{
   public class EditEntry
   {
      public string UserId { get; set; }

      public DateTime EditTime { get; set; }
   }
}