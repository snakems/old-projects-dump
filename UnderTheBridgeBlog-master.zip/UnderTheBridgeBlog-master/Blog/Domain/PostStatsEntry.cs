using System;
using System.Runtime.Serialization;

namespace Blog.Domain
{
   public class PostStatsEntry
   {
      public string PostId { get; set; }

      public DateTime VisitedTime { get; set; }

      public bool IsTracked { get; set; }
   }
}