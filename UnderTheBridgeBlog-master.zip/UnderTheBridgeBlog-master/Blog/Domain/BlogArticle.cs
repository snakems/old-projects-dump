using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using MongoDB.Bson.Serialization.Attributes;

namespace Blog.Domain
{
   public class BlogArticle : Entity
   {
      public string UserId { get; set; }

      public string Title { get; set; }

      public string TitleImageUrl { get; set; }

      public string Preview { get; set; }

      public string Contents { get; set; }

      public DateTime PostedTime { get; set; }

      public IList<EditEntry> EditHistory { get; private set; }

      public IList<string> Tags { get; private set; }

      public BlogArticle()
      {
         EditHistory = new List<EditEntry>();
         Tags = new List<string>();
      }

      public void AddTags(params string[] tags)
      {
         foreach (var tag in tags) Tags.Add(tag);
      }
   }
}