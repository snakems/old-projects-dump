using System.Linq;
using Blog.Domain;

namespace Blog.Data
{
   public interface IArticleRepository : IRepository<BlogArticle>
   {
   }
}