﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Blog.Domain;

namespace Blog.Data
{
   public interface IBlogContext
   {
      IUserRepository Users { get; }

      IArticleRepository Articles { get; }

      //IQueryable<BlogArticle> Articles();

      //IQueryable<BlogComment> Comments();

      //IQueryable<BlogUser> Users();
   }
}