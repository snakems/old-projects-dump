using System.Linq;
using Blog.Domain;

namespace Blog.Data
{
   public interface IRepository<T> where T : Entity
   {
      T Find(string id);

      IQueryable<T> All();

      void Delete(string id);

      void Save(T item);
   }
}