using Blog.Domain;

namespace Blog.Data
{
   public interface IUserRepository : IRepository<BlogUser>
   {
      BlogUser FindByName(string name);
   }
}