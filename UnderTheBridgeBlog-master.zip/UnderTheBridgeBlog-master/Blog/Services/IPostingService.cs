﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Blog.Domain;

namespace Blog.Services
{
   public interface IPostingService
   {
      /// <summary>
      /// Save article. Returns true if successful, false if validation failed.
      /// </summary>
      /// <param name="article">Article to save.</param>
      /// <returns>True if successful, false if validation failed.</returns>
      bool Save(BlogArticle article);

      void DeleteArticle(string userId, string articleId);
   }
}