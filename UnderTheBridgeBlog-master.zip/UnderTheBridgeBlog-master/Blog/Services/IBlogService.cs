﻿using System;
using System.Linq;
using Blog.Domain;

namespace Blog.Services
{
   public interface IBlogService
   {
      BlogArticle GetArticle(string articleId);

      IQueryable<BlogArticle> GetArticles();

      BlogUser GetUser(string userId);
   }
}