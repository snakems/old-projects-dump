﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Blog.Domain;

namespace Blog.Services
{
   public interface IPermissionService
   {
      bool CanEditArticle(BlogUser user, BlogArticle article);
   }
}