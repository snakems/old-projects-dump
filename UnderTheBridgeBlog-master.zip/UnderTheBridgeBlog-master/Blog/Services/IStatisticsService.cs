﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Blog.Domain;

namespace Blog.Services
{
   public interface IStatisticsService
   {
      void VisitPost(string postId, string userId);

      void TrackPost(string postId, string userId);

      void UntrackPost(string postId, string userId);

      //IEnumerable<BlogPost> GetTrackingPosts(BlogUser user);
   }
}