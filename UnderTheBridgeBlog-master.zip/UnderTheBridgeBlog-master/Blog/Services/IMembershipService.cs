﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Blog.Domain;

namespace Blog.Services
{
   public interface IMembershipService
   {
      BlogUser CreateUser(string username, string password, string email);

      BlogUser ValidateUser(string username, string password);

      bool IsUsernameTaken(string username);
   }
}