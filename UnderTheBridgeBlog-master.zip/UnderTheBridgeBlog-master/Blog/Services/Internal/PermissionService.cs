﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Blog.Domain;

namespace Blog.Services
{
   public class PermissionService : IPermissionService
   {
      public bool CanEditArticle(BlogUser user, BlogArticle article)
      {
         if (user == null || user.Banned)
         {
            return false;
         }
         return (user.Id == article.UserId && user.Roles.Contains("writer")) || user.Roles.Contains("admin");
      }
   }
}