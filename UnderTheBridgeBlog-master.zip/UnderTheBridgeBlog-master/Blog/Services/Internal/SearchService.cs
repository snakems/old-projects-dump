﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Blog.Data;
using Blog.Domain;

namespace Blog.Services
{
   public class SearchService : ISearchService
   {
      private IBlogContext context;

      public SearchService(IBlogContext context)
      {
         this.context = context;
      }

      public IQueryable<BlogArticle> SearchArticlesByText(string text)
      {
         if (String.IsNullOrWhiteSpace(text))
            throw new ArgumentException("text", "Search pattern cannot be empty");

         text = text.ToLowerInvariant();
         return context.Articles.All().Where(p => p.Title.ToLower().Contains(text)
                                          || p.Contents.ToLower().Contains(text)
                                          || p.Preview.ToLower().Contains(text));
      }

      public IQueryable<BlogArticle> SearchArticlesByTag(string tag)
      {
         if (String.IsNullOrWhiteSpace(tag))
            throw new ArgumentException("text", "Search pattern cannot be empty");

         return context.Articles.All().Where(p => p.Tags.Contains(tag));
      }
   }
}