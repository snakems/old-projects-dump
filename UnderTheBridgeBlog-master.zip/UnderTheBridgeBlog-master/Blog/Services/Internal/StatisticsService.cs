﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Blog.Data;
using Blog.Domain;

namespace Blog.Services
{
   public class StatisticsService : IStatisticsService
   {
      private IBlogContext context;

      public StatisticsService(IBlogContext context)
      {
         this.context = context;
      }

      public void VisitPost(string postId, string userId)
      {
         var user = context.Users.Find(userId);
         if (user == null) throw new Exception("User not found");

         var entry = user.PostStats.FirstOrDefault(e => e.PostId == postId);
         if (entry != null)
         {
            entry.VisitedTime = DateTime.Now;
         }
         else
         {
            user.PostStats.Add(new PostStatsEntry()
            {
               PostId = postId,
               VisitedTime = DateTime.Now,
            });
         }
         context.Users.Save(user);
      }

      public void TrackPost(string postId, string userId)
      {
         var user = context.Users.Find(userId);
         if (user == null) throw new Exception("User not found");

         var entry = user.PostStats.FirstOrDefault(te => te.PostId == postId);
         if (entry != null)
         {
            entry.IsTracked = true;
         }
         else
         {
            user.PostStats.Add(new PostStatsEntry()
            {
               PostId = postId,
               VisitedTime = DateTime.Now,
               IsTracked = true,
            });
         }
         context.Users.Save(user);
      }

      public void UntrackPost(string postId, string userId)
      {
         var user = context.Users.Find(userId);
         if (user == null) throw new Exception("User not found");

         var entry = user.PostStats.FirstOrDefault(te => te.PostId == postId);
         if (entry != null) entry.IsTracked = false;
         context.Users.Save(user);
      }
   }
}