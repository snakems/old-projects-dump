﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using Blog.Data;
using Blog.Domain;

namespace Blog.Services
{
   public class MembershipService : IMembershipService
   {
      private IBlogContext context;

      public MembershipService(IBlogContext context)
      {
         this.context = context;
      }

      public BlogUser CreateUser(string username, string password, string email)
      {
         if (username == null) throw new ArgumentNullException("username", "Username cannot be null");

         var exists = context.Users.FindByName(username);
         if (exists != null) return null;

         var user = new BlogUser()
         {
            Name = username,
            Email = email,
            PasswordHash = CreateHash(password),
            Sex = Sex.Undefined,
         };

         context.Users.Save(user);

         return user;
      }

      public BlogUser ValidateUser(string username, string password)
      {
         if (username == null) throw new ArgumentNullException("name", "Username cannot be null");

         var user = context.Users.FindByName(username);
         if (user == null) return null;

         if (ValidatePassword(password, user.PasswordHash))
            return user;

         return null;
      }

      public bool IsUsernameTaken(string username)
      {
         if (String.IsNullOrWhiteSpace(username)) return false;
         return context.Users.FindByName(username) != null;
      }

      private bool ValidatePassword(string password, string passwordHash)
      {
         var inputHash = CreateHash(password);
         return inputHash == passwordHash;
      }

      private string CreateHash(string password)
      {
         var sha = new SHA1CryptoServiceProvider();
         var bytes = sha.ComputeHash(Encoding.UTF8.GetBytes(password));
         return Convert.ToBase64String(bytes);
      }
   }
}