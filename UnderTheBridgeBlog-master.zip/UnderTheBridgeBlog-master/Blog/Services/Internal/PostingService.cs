﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Blog.Data;
using Blog.Domain;
using Blog.Validators;

namespace Blog.Services
{
   public class PostingService : IPostingService
   {
      private IBlogContext context;
      private IPermissionService permissions;

      public PostingService(IBlogContext context, IPermissionService permissions)
      {
         this.context = context;
         this.permissions = permissions;
      }

      /// <summary>
      /// Save article
      /// </summary>
      /// <param name="article">Article to save</param>
      /// <returns>True if successful, false if validation failed</returns>
      public bool Save(BlogArticle article)
      {
         if (article == null) throw new ArgumentNullException("item", "Post cannot be null.");

         var user = context.Users.Find(article.UserId);
         if (user == null) throw new Exception("There is no such user.");

         var actionAllowed = permissions.CanEditArticle(user, article);
         if (!actionAllowed) throw new InvalidOperationException("Action is not allowed for this user!");

         var validator = new PostValidator();
         if (validator.Validate(article))
         {
            article.EditHistory.Add(new EditEntry() { EditTime = DateTime.Now, UserId = user.Id });
            context.Articles.Save(article);

            return true;
         }

         return false;
      }

      public void DeleteArticle(string userId, string id)
      {
         if (id == null) throw new ArgumentNullException("id", "Post Id cannot be null");

         var post = context.Articles.Find(id);
         if (post == null) throw new Exception("There is no such post.");

         var user = context.Users.Find(userId);
         if (user == null) throw new Exception("There is no such user.");

         var actionAllowed = permissions.CanEditArticle(user, post);
         if (!actionAllowed) throw new InvalidOperationException("Action is not allowed for this user!");

         //TODO: disqus comments

         context.Articles.Delete(id);
      }
   }
}