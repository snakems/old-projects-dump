﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Blog.Data;
using Blog.Domain;

namespace Blog.Services
{
   public class BlogService : Blog.Services.IBlogService
   {
      private IBlogContext context;

      public BlogService(IBlogContext context)
      {
         this.context = context;
      }

      public BlogArticle GetArticle(string articleId)
      {
         return context.Articles.Find(articleId);
      }

      public IQueryable<BlogArticle> GetArticles()
      {
         return context.Articles.All().OrderByDescending(ba => ba.PostedTime);
      }

      public BlogUser GetUser(string userId)
      {
         return context.Users.Find(userId);
      }
   }
}