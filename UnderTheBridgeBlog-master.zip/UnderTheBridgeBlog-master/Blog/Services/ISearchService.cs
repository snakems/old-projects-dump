﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Blog.Domain;

namespace Blog.Services
{
   public interface ISearchService
   {
      IQueryable<BlogArticle> SearchArticlesByText(string text);

      IQueryable<BlogArticle> SearchArticlesByTag(string tag);
   }
}