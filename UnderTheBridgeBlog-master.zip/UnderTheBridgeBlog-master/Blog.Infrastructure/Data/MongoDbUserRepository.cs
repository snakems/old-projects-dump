﻿using System;
using System.Linq;
using Blog.Data;
using Blog.Domain;
using MongoDB.Driver;
using MongoDB.Driver.Builders;
using MongoDB.Driver.Linq;

namespace Blog.Infrastructure.Data
{
   public class MongoDbUserRepository : MongoContext<BlogUser>, IUserRepository
   {
      public MongoDbUserRepository(string connectionString)
         : base(connectionString)
      {
      }

      public BlogUser FindByName(string name)
      {
         if (name == null) throw new ArgumentNullException("name", "Name cannot be null");
         return All().SingleOrDefault(u => u.Name == name);
      }
   }
}