﻿using System;
using System.Linq;
using Blog.Data;
using Blog.Domain;
using MongoDB.Driver;
using MongoDB.Driver.Builders;
using MongoDB.Driver.Linq;

namespace Blog.Infrastructure.Data
{
   public class MongoDbArticleRepository : MongoContext<BlogArticle>, IArticleRepository
   {
      public MongoDbArticleRepository(string connectionString)
         : base(connectionString)
      {
      }
   }
}