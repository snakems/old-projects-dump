﻿using System;
using System.Linq;
using Blog.Data;
using Blog.Domain;
using MongoDB.Driver;
using MongoDB.Driver.Builders;
using MongoDB.Driver.Linq;

namespace Blog.Infrastructure.Data
{
   public abstract class MongoContext<T> : IRepository<T> where T : Entity
   {
      protected MongoCollection<T> collection;

      public MongoContext(string connectionString)
      {
         var db = MongoDatabase.Create(connectionString);
         collection = db.GetCollection<T>(typeof(T).Name);
      }

      public virtual T Find(string id)
      {
         if (id == null) throw new ArgumentNullException("id", "Id cannot be null");
         return All().SingleOrDefault(p => p.Id == id);
      }

      public virtual IQueryable<T> All()
      {
         return collection.AsQueryable();
      }

      public virtual void Delete(string id)
      {
         if (id == null) throw new ArgumentNullException("id", "Id cannot be null");
         collection.Remove(Query.EQ("_id", id));
      }

      public virtual void Save(T item)
      {
         if (item == null) throw new ArgumentNullException("item", "Item cannot be null");
         collection.Save(item);
      }
   }
}