﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Blog.Data;

namespace Blog.Infrastructure.Data
{
   public class MongoDbBlogContext : IBlogContext
   {
      private IUserRepository users;
      private IArticleRepository articles;

      public MongoDbBlogContext(IUserRepository users,
                                IArticleRepository articles)
      {
         this.users = users;
         this.articles = articles;
      }

      public IUserRepository Users
      {
         get { return users; }
      }

      public IArticleRepository Articles
      {
         get { return articles; }
      }
   }
}