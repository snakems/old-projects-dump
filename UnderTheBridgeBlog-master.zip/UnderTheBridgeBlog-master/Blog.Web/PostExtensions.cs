﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Web;
using Blog.Domain;

namespace Blog.Web
{
   public static class PostExtensions
   {
      private static string[] allowedTags
         = { "b", "i", "u", "s", "video", "img", "url" };

      public static BlogArticle EncodeArticle(this BlogArticle post)
      {
         post.Title = post.Title;
         post.Preview = ParseString(post.Preview);
         post.Contents = ParseString(post.Contents);

         return post;
      }

      private static string ParseString(string toParse)
      {
         var processingText = HttpUtility.HtmlEncode(toParse);

         processingText = processingText.Split(new string[] { "\n" }, StringSplitOptions.RemoveEmptyEntries)
                                        .Select(p => "<p>" + p + "</p>")
                                        .Aggregate("", (p1, p2) => p1 + p2);

         var tagParser = new TagParser();
         processingText = tagParser.Parse(processingText, allowedTags);

         return processingText;
      }
   }
}