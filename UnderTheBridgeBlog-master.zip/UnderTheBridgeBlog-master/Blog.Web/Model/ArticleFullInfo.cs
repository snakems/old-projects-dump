﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Blog.Web.Model
{
   public class ArticleFullInfo : ArticleInfo
   {
      public string TitleImageUrl { get; set; }

      public string Contents { get; set; }
   }
}