﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Blog.Domain;

namespace Blog.Web.Model
{
   public class UserInfo
   {
      public string Id { get; set; }

      public string Name { get; set; }

      public string Email { get; set; }

      public bool EmailHidden { get; set; }

      public bool Banned { get; set; }

      public Sex Sex { get; set; }

      public IList<string> Roles { get; private set; }
   }
}