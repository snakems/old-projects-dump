﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Blog.Domain;

namespace Blog.Web.Model
{
   public class ArticlePreviewInfo : ArticleInfo
   {
      public string Preview { get; set; }
   }
}