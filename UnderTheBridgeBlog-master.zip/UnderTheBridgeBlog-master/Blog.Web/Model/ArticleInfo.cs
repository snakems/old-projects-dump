﻿using System;
using System.Collections.Generic;

namespace Blog.Web.Model
{
   public abstract class ArticleInfo
   {
      public string Id { get; set; }

      public UserInfo User { get; set; }

      public string Title { get; set; }

      public string PostedTime { get; set; }

      public IList<string> Tags { get; set; }
   }
}