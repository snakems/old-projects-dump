﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Web;
using System.Web.Security;
using Blog.Data;
using Blog.Domain;
using Blog.Services;

namespace Blog.Web.Authentication
{
   public class AuthService : IAuthService
   {
      public void AuthenticateUser(BlogUser user)
      {
         var userInfo = new UserCookieInfo() { UserId = user.Id, Roles = user.Roles.ToArray() };
         var ticket = new FormsAuthenticationTicket(1, user.Name,
            DateTime.Now, DateTime.Now + TimeSpan.FromDays(30), true, userInfo.ToString());
         var ticketEncrypted = FormsAuthentication.Encrypt(ticket);
         HttpCookie cookie = new HttpCookie(FormsAuthentication.FormsCookieName, ticketEncrypted)
         {
            HttpOnly = true,
            Path = FormsAuthentication.FormsCookiePath,
            Secure = FormsAuthentication.RequireSSL,
            Expires = ticket.Expiration
         };

         var response = HttpContext.Current.Response;

         response.Cookies.Remove(FormsAuthentication.FormsCookieName);
         response.Cookies.Add(cookie);
      }

      public void SignOut()
      {
         FormsAuthentication.SignOut();
      }
   }
}