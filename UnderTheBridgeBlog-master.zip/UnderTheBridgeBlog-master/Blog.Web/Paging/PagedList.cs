﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Blog.Web.Paging
{
   public class PagedList<T> : List<T>, IPagedList<T>
   {
      public int ItemCount { get; set; }

      public int PageIndex { get; set; }

      public int PageCount { get; set; }

      public bool PrevPage { get; set; }

      public bool NextPage { get; set; }
   }
}