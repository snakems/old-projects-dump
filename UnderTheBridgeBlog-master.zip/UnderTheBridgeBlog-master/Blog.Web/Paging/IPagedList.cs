﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Blog.Web.Paging
{
   public interface IPagedList<T> : IList<T>
   {
      int ItemCount { get; set; }

      int PageIndex { get; set; }

      int PageCount { get; set; }

      bool PrevPage { get; set; }

      bool NextPage { get; set; }
   }
}