﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Blog.Web.Paging
{
   public static class Extensions
   {
      public static IPagedList<T> ToPagedList<T>(this IQueryable<T> items, int pageIndex, int pageSize)
      {
         var page = pageIndex < 0 ? 0 : pageIndex;

         var itemCount = items.Count() - 1;
         if (itemCount / pageSize < page)
            page = itemCount / pageSize;

         var lowerBound = page * pageSize;
         var upperBound = lowerBound + pageSize;

         var query = items.Skip(lowerBound).Take(pageSize);

         var prevPage = upperBound < itemCount;
         var nextPage = page > 0;

         var result = new PagedList<T>()
         {
            ItemCount = itemCount + 1,
            PageIndex = page + 1,
            PageCount = itemCount / pageSize + 1,
            PrevPage = prevPage,
            NextPage = nextPage,
         };
         result.AddRange(query);

         return result;
      }
   }
}