﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;
using Microsoft.Practices.Unity;

namespace Blog.Web.Mvc
{
   public class ControllerFactory : DefaultControllerFactory
   {
      private IUnityContainer container;

      public ControllerFactory(IUnityContainer container)
      {
         this.container = container;
      }

      protected override IController GetControllerInstance(RequestContext requestContext, Type controllerType)
      {
         try
         {
            if (controllerType == null)
               return base.GetControllerInstance(requestContext, controllerType);
         }
         catch (HttpException ex)
         {
            if (ex.GetHttpCode() == (int)HttpStatusCode.NotFound)
            {
               throw new HttpException(404, "Page not found.");
            }
            return null;
         }

         return (IController)container.Resolve(controllerType);
      }
   }
}