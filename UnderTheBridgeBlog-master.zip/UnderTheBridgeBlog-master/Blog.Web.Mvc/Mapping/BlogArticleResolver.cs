﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using AutoMapper;
using Blog.Data;
using Blog.Domain;

namespace Blog.Web.Mvc.Mapping
{
   public class BlogArticleResolver : ValueResolver<string, BlogArticle>
   {
      private IBlogContext context;

      public BlogArticleResolver(IBlogContext context)
      {
         this.context = context;
      }

      protected override BlogArticle ResolveCore(string source)
      {
         if (String.IsNullOrEmpty(source)) return null;

         return context.Articles.Find(source);
      }
   }
}