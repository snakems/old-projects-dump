﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using AutoMapper;
using Blog.Data;
using Blog.Domain;

namespace Blog.Web.Mvc.Mapping
{
   public class BlogUserResolver : ValueResolver<string, BlogUser>
   {
      private IBlogContext context;

      public BlogUserResolver(IBlogContext context)
      {
         this.context = context;
      }

      protected override BlogUser ResolveCore(string source)
      {
         if (String.IsNullOrEmpty(source)) return null;

         return context.Users.Find(source);
      }
   }
}