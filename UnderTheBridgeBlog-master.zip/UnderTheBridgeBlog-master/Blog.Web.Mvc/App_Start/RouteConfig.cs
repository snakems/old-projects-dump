﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Http;
using System.Web.Mvc;
using System.Web.Routing;

namespace Blog.Web.Mvc
{
   public class RouteConfig
   {
      public static void RegisterRoutes(RouteCollection routes)
      {
         routes.IgnoreRoute("{resource}.axd/{*pathInfo}");
         routes.IgnoreRoute("{*favicon}", new { favicon = @"(.*/)?favicon.([iI][cC][oO]|[gG][iI][fF])(/.*)?" });

         routes.MapHttpRoute(
            name: "DefaultApi",
            routeTemplate: "api/{controller}/{id}",
            defaults: new { id = RouteParameter.Optional }
         );

         routes.MapLowercaseRoute("", "Login", new { controller = "Account", action = "Login" });
         routes.MapLowercaseRoute("", "Register", new { controller = "Account", action = "Register" });

         //routes.MapLowercaseRoute(
         //   name: "User",
         //   url: "User/{id}",
         //   defaults: new { controller = "User", action = "Details" }
         //);

         //routes.MapLowercaseRoute(
         //   name: "Post",
         //   url: "Post/{id}",
         //   defaults: new { controller = "Post", action = "Details", id = UrlParameter.Optional }
         //);

         routes.MapLowercaseRoute(
            name: "Default",
            url: "{controller}/{action}/{id}",
            defaults: new { controller = "Blog", action = "Index", id = UrlParameter.Optional }
         );
      }
   }

   public class LowercaseRoute : System.Web.Routing.Route
   {
      public LowercaseRoute(string url, IRouteHandler routeHandler)
         : base(url, routeHandler) { }

      public LowercaseRoute(string url, RouteValueDictionary defaults, IRouteHandler routeHandler)
         : base(url, defaults, routeHandler) { }

      public LowercaseRoute(string url, RouteValueDictionary defaults, RouteValueDictionary constraints, IRouteHandler routeHandler)
         : base(url, defaults, constraints, routeHandler) { }

      public LowercaseRoute(string url, RouteValueDictionary defaults, RouteValueDictionary constraints, RouteValueDictionary dataTokens, IRouteHandler routeHandler)
         : base(url, defaults, constraints, dataTokens, routeHandler) { }

      public override VirtualPathData GetVirtualPath(RequestContext requestContext, RouteValueDictionary values)
      {
         VirtualPathData path = base.GetVirtualPath(requestContext, values);

         if (path != null)
            path.VirtualPath = path.VirtualPath.ToLowerInvariant();

         return path;
      }
   }

   public static class RouteCollectionExtensions
   {
      public static Route MapLowercaseRoute(this RouteCollection routes, string name, string url, object defaults)
      {
         return MapLowercaseRoute(routes, name, url, defaults, null);
      }

      public static Route MapLowercaseRoute(this RouteCollection routes, string name, string url, object defaults, object constraints)
      {
         if (routes == null)
            throw new ArgumentNullException("routes");
         if (url == null)
            throw new ArgumentNullException("url");

         var route = new LowercaseRoute(url, new MvcRouteHandler())
         {
            Defaults = new RouteValueDictionary(defaults),
            Constraints = new RouteValueDictionary(constraints),
            DataTokens = new RouteValueDictionary()
         };
         routes.Add(name, route);
         return route;
      }
   }
}