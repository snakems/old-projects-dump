﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using System.Web;
using System.Web.Http;
using System.Web.Mvc;
using System.Web.Routing;
using System.Web.Security;
using AutoMapper;
using Blog.Domain;
using Blog.Web.Authentication;
using Blog.Web.Model;
using Blog.Web.Mvc;
using Blog.Web.Mvc.ActionResults;
using Blog.Web.Mvc.Mapping;
using Blog.Web.Mvc.Model;
using Microsoft.Practices.Unity;

namespace Blog.Web.Mvc
{
   // Note: For instructions on enabling IIS6 or IIS7 classic mode,
   // visit http://go.microsoft.com/?LinkId=9394801
   public class MvcApplication : System.Web.HttpApplication
   {
      protected void Application_Start()
      {
         var viewEngines = System.Web.Mvc.ViewEngines.Engines;
         var webFormsEngine = viewEngines.OfType<WebFormViewEngine>().FirstOrDefault();
         if (webFormsEngine != null) viewEngines.Remove(webFormsEngine);

         var container = Unity.Initialize();

         Mapper.Initialize(cfg =>
         {
            cfg.ConstructServicesUsing(t => container.Resolve(t));

            //cfg.AddProfile<WebsiteProfile>();
            cfg.CreateMap<BlogUser, UserInfo>();

            cfg.CreateMap<BlogArticle, ArticlePreviewInfo>()
               .BeforeMap((ba, ai) => ba.EncodeArticle())
               .ForMember(a => a.User, c => c.ResolveUsing<BlogUserResolver>().FromMember(ba => ba.UserId))
               .ForMember(a => a.PostedTime, c => c.MapFrom(ba => ba.PostedTime.ToLocalTime().ToPrettyDate()));

            cfg.CreateMap<BlogArticle, ArticleFullInfo>()
               .BeforeMap((ba, ai) => ba.EncodeArticle())
               .ForMember(a => a.User, c => c.ResolveUsing<BlogUserResolver>().FromMember(ba => ba.UserId))
               .ForMember(a => a.PostedTime, c => c.MapFrom(ba => ba.PostedTime.ToLocalTime().ToPrettyDate()));
         });

         var controllerFactory = new ControllerFactory(container);
         ControllerBuilder.Current.SetControllerFactory(controllerFactory);

         MappedViewResult.Map = AutoMapper.Mapper.Map;
         MappedViewPartialResult.Map = AutoMapper.Mapper.Map;

         //config.DependencyResolver = new UnityDependencyResolver(container);
         //DependencyResolver.SetResolver(new UnityDependencyResolver(container));

         AreaRegistration.RegisterAllAreas();

         FilterConfig.RegisterGlobalFilters(GlobalFilters.Filters);
         RouteConfig.RegisterRoutes(RouteTable.Routes);
      }

      protected void Application_Error(object sender, EventArgs e)
      {
         if (!HttpContext.Current.IsCustomErrorEnabled)
            return;

         var exception = Server.GetLastError();
         var httpException = new HttpException(null, exception);

         var routeData = new RouteData();
         routeData.Values.Add("controller", "Error");
         routeData.Values.Add("action", "Index");
         routeData.Values.Add("httpException", httpException);

         Server.ClearError();

         var errorController = ControllerBuilder.Current.GetControllerFactory().CreateController(
             new RequestContext(new HttpContextWrapper(Context), routeData), "Error");

         errorController.Execute(new RequestContext(new HttpContextWrapper(Context), routeData));
      }

      protected void Application_PostAuthenticateRequest()
      {
         if (Request.IsAuthenticated)
         {
            if (User.Identity.IsAuthenticated && User.Identity.AuthenticationType == "Forms")
            {
               var ticket = ((FormsIdentity)User.Identity).Ticket;
               var userInfo = UserCookieInfo.FromString(ticket.UserData);
               var identity = new BlogIdentity() { UserId = userInfo.UserId, Name = ticket.Name };
               var principal = new GenericPrincipal(identity, userInfo.Roles);

               HttpContext.Current.User = principal;
            }
         }
      }
   }
}