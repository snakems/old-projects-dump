﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using AutoMapper;
using Blog.Data;
using Blog.Domain;
using Blog.Services;
using Blog.Web.Authentication;
using Blog.Web.Model;
using Blog.Web.Mvc.Model;
using Blog.Web.Mvc.Model.Account;
using Blog.Web.Paging;

namespace Blog.Web.Mvc.Controllers
{
   public class UserController : BaseController
   {
      private IBlogService blogService;
      private IMembershipService membership;

      public UserController(IBlogService blogService, IMembershipService membership)
      {
         this.blogService = blogService;
         this.membership = membership;
      }

      // GET: /User/Details/id

      public ActionResult Details(string id, int? page)
      {
         var pageIndex = page.HasValue ? page.Value : 0;

         var user = blogService.GetUser(id);
         if (user == null) throw new HttpException(404, "User not found");

         var posts = blogService.GetArticles().Where(p => p.UserId == user.Id).Count();

         var model = new UserViewModel()
         {
            User = Mapper.Map<UserInfo>(user),
            PostCount = posts,
            PageIndex = pageIndex,
            PageSize = 10,
         };

         return View(model);
      }

      #region Child Actions

      [ChildActionOnly]
      public ActionResult LoadPosts(string userId, int? page)
      {
         var pageIndex = page.HasValue ? page.Value - 1 : 0;
         var posts = blogService.GetArticles().Where(p => p.UserId == userId)
                                              .ToPagedList(pageIndex, 10).Map<BlogArticle, ArticlePreviewInfo>();
         ViewBag.UserID = userId;
         return PartialView(posts);
      }

      public JsonResult IsUsernameTaken(string Username)
      {
         var exists = membership.IsUsernameTaken(Username);
         return Json(exists, JsonRequestBehavior.AllowGet);
      }

      public JsonResult IsUsernameAvailable(string Username)
      {
         var exists = membership.IsUsernameTaken(Username);
         return Json(!exists, JsonRequestBehavior.AllowGet);
      }

      // GET: /User/Avatar/userId

      [ChildActionOnly]
      public ActionResult Avatar(string userId, int? size)
      {
         var user = blogService.GetUser(userId ?? CurrentUserId);
         return MappedPartialView<UserInfo>("Parts/Avatar", user);
      }

      #endregion Child Actions
   }
}