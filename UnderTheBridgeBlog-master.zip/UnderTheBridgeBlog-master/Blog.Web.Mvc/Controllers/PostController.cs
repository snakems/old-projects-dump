﻿using System;
using System.Linq;
using System.Threading;
using System.Web;
using System.Web.Mvc;
using AutoMapper;
using Blog.Domain;
using Blog.Services;
using Blog.Web.Model;
using Blog.Web.Mvc.ActionResults;
using Blog.Web.Mvc.Model;

namespace Blog.Web.Mvc.Controllers
{
   public class PostController : BaseController
   {
      private IBlogService blogService;
      private IPostingService postingService;
      private IStatisticsService statistics;

      public PostController(IBlogService blogServive, IPostingService postingService, IStatisticsService statistics)
      {
         this.blogService = blogServive;
         this.postingService = postingService;
         this.statistics = statistics;
      }

      // GET: /Post/Details/id
      public ActionResult Details(string id)
      {
         var Article = blogService.GetArticle(id);
         if (Article == null) throw new HttpException(404, "Article not found");

         if (CurrentUserId != null) statistics.VisitPost(id, CurrentUserId);

         var model = new { Article };

         return View(Mapper.DynamicMap<PostViewModel>(model));
      }

      // GET: /Post/Create
      [Authorize(Roles = "writer, admin")]
      public ActionResult Create()
      {
         return View("Edit");
      }

      // POST: /Post/Create
      [HttpPost]
      [ValidateAntiForgeryToken]
      [ValidateInput(false)]
      public ActionResult Create(EditPostModel model)
      {
         if (ModelState.IsValid)
         {
            var article = new BlogArticle()
               {
                  UserId = CurrentUserId,
                  PostedTime = DateTime.Now,
                  Title = model.Title,
                  Preview = model.Preview,
                  Contents = model.Contents,
               };

            //TODO: model binder
            var tags = model.Tags.Split(new string[] { "," }, StringSplitOptions.RemoveEmptyEntries)
                                 .Select(s => s.Trim()).ToArray();
            article.AddTags(tags);

            try
            {
               // Should always pass the check, if ModelState.IsValid returns true
               if (postingService.Save(article))
               {
                  return RedirectToAction("Details", new { id = article.Id });
               }
            }
            catch (Exception e)
            {
               ModelState.AddModelError("exception", e);
            }
         }
         return View("Edit", model);
      }

      // GET: /Post/Create
      [Authorize(Roles = "writer, admin")]
      public ActionResult Edit(string id)
      {
         var article = blogService.GetArticle(id);
         if (article == null) throw new HttpException(404, "Article not found");

         var editModel = new EditPostModel()
         {
            Title = article.Title,
            Preview = article.Preview,
            Contents = article.Contents,
            Tags = article.Tags.Aggregate((a, t) => a + ", " + t),
         };

         return View("Edit", editModel);
      }

      // POST: /Post/Create
      [HttpPost]
      [Authorize(Roles = "writer, admin")]
      [ValidateAntiForgeryToken]
      [ValidateInput(false)]
      public ActionResult Edit(string id, EditPostModel model)
      {
         if (ModelState.IsValid)
         {
            var article = blogService.GetArticle(id);
            if (article == null) throw new HttpException(404, "Article not found");

            article.Title = model.Title;
            article.Preview = model.Preview;
            article.Contents = model.Contents;

            //TODO: model binder
            var tags = model.Tags.Split(new string[] { "," }, StringSplitOptions.RemoveEmptyEntries)
                                .Select(s => s.Trim()).ToArray();
            article.Tags.Clear();
            article.AddTags(tags);

            try
            {
               // Should always pass the check, if ModelState.IsValid returns true
               if (postingService.Save(article))
               {
                  return RedirectToAction("Details", new { id = article.Id });
               }
            }
            catch (Exception e)
            {
               ModelState.AddModelError("exception", e);
            }
         }
         return View("Edit", model);
      }

      // POST: /Post/Delete/id
      [HttpPost]
      public ActionResult Delete(string id, string returnUrl)
      {
         string message;
         try
         {
            if (CurrentUserId == null) throw new InvalidOperationException("User is not authenticated");
            postingService.DeleteArticle(CurrentUserId, id);

            if (Request.IsAjaxRequest()) return Json(new { success = true });
            return String.IsNullOrEmpty(returnUrl) ? Redirect("/") : Redirect(HttpUtility.UrlDecode(returnUrl));
         }
         catch (InvalidOperationException e)
         {
            // User is not allowed to delete this article
            message = e.Message;
         }
         catch (Exception e) { message = e.Message; }

         if (Request.IsAjaxRequest()) return Json(new { success = false, message = message });
         return RedirectToAction("Details", new { id = id });
      }
   }
}