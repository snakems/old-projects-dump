﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Blog.Services;
using Blog.Web.Model;

namespace Blog.Web.Mvc.Controllers
{
   public class AdminController : BaseController
   {
      private IBlogService blogService;
      private IPermissionService permissions;

      public AdminController(IBlogService blogService, IPermissionService permissions)
      {
         this.blogService = blogService;
         this.permissions = permissions;
      }

      [ChildActionOnly]
      public ActionResult ArticleActions(string id)
      {
         var article = blogService.GetArticle(id);
         if (article == null) throw new HttpException(404, "Article not found");

         var user = blogService.GetUser(CurrentUserId);
         if (user == null) throw new HttpException(500, "There is no such user. Maybe cookie is a little bit old.");

         var allowed = permissions.CanEditArticle(user, article);

         if (allowed)
         {
            return PartialView((object)article.Id);
         }

         return new EmptyResult();
      }
   }
}