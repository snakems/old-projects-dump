﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Http;
using System.Web.Mvc;
using Blog.Data;
using Blog.Domain;
using Blog.Services;
using Blog.Web.Authentication;
using Blog.Web.Mvc.ActionResults;

namespace Blog.Web.Mvc.Controllers
{
   public abstract class BaseController : Controller
   {
      public string CurrentUserId
      {
         get
         {
            var identity = User.Identity as BlogIdentity;
            if (identity != null)
            {
               return identity.UserId;
            }
            return null;
         }
      }

      //public MappedViewResult MappedView<TModel>(object Model)
      //{
      //   return MappedView<TModel>(String.Empty, Model);
      //}

      //public MappedViewResult MappedView<TModel>(string ViewName, object Model)
      //{
      //   ViewData.Model = Model;
      //   return new MappedViewResult(typeof(TModel))
      //   {
      //      ViewData = ViewData,
      //      TempData = TempData,
      //      ViewName = ViewName,
      //   };
      //}

      public MappedViewPartialResult MappedPartialView<TModel>(object Model)
      {
         return MappedPartialView<TModel>(String.Empty, Model);
      }

      public MappedViewPartialResult MappedPartialView<TModel>(string ViewName, object Model)
      {
         ViewData.Model = Model;
         return new MappedViewPartialResult(typeof(TModel))
         {
            ViewData = ViewData,
            TempData = TempData,
            ViewName = ViewName,
         };
      }
   }
}