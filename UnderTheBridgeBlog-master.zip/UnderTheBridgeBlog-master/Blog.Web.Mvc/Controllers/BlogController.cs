﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using AutoMapper;
using Blog.Data;
using Blog.Services;
using Blog.Web.Model;
using Blog.Web.Mvc.Model;
using Blog.Web.Paging;

namespace Blog.Web.Mvc.Controllers
{
   public class BlogController : BaseController
   {
      private IBlogService blogService;
      private ISearchService searchService;

      public BlogController(IBlogService blogService, ISearchService searchService)
      {
         this.blogService = blogService;
         this.searchService = searchService;
      }

      //
      // GET: /Blog/

      public ActionResult Index(int? page)
      {
         var pageIndex = page.HasValue ? page.Value - 1 : 0;

         var articles = blogService.GetArticles().Take(10).ToPagedList(pageIndex, 10);

         var model = new HomePageViewModel()
         {
            Articles = articles.Map<Blog.Domain.BlogArticle, ArticlePreviewInfo>()
         };

         return View(model);
      }

      public ActionResult Feedback()
      {
         return View();
      }

      //
      // GET: /Blog/Search/pattern

      [ValidateInput(false)]
      public ActionResult Search(string text, string tag)
      {
         var model = new SearchViewModel();
         IQueryable<Blog.Domain.BlogArticle> query = null;

         if (!String.IsNullOrWhiteSpace(text))
         {
            query = searchService.SearchArticlesByText(text);
            model.SearchPattern = text;
            model.Type = SearchType.Text;
         }
         else if (!String.IsNullOrWhiteSpace(tag))
         {
            query = searchService.SearchArticlesByTag(tag);
            model.SearchPattern = tag;
            model.Type = SearchType.Tag;
         }
         if (query != null)
         {
            var articles = Mapper.Map<ArticlePreviewInfo[]>(query.OrderByDescending(p => p.PostedTime));
            model.Articles.AddRange(articles);
         }

         return View(model);
      }
   }
}