﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using AutoMapper;
using Blog.Data;
using Blog.Services;
using Blog.Web.Model;

namespace Blog.Web.Mvc.Controllers
{
   public class SidebarController : BaseController
   {
      private IBlogService blogService;

      public SidebarController(IBlogService blogService)
      {
         this.blogService = blogService;
      }

      // GET: /Blog/LatestPosts

      [ChildActionOnly]
      public ActionResult LatestPosts()
      {
         var posts = blogService.GetArticles().Take(10).ToArray();

         return MappedPartialView<ArticlePreviewInfo[]>(posts);
      }
   }
}