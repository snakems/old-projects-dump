﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Blog.Services;
using Blog.Web.Mvc.Model.Account;

namespace Blog.Web.Mvc.Controllers
{
   public class AccountController : Controller
   {
      private IAuthService authService;
      private IMembershipService membershipService;

      public AccountController(IAuthService authService, IMembershipService membershipService)
      {
         this.authService = authService;
         this.membershipService = membershipService;
      }

      // GET: /User/Register

      public ActionResult Register(string returnUrl)
      {
         return View();
      }

      // POST: /User/Register

      [HttpPost]
      public ActionResult Register(RegisterModel info, string returnUrl)
      {
         if (ModelState.IsValid)
         {
            var user = membershipService.CreateUser(info.Username, info.Password, info.Email);

            if (user != null)
            {
               authService.AuthenticateUser(user);
               if (!String.IsNullOrWhiteSpace(returnUrl))
               {
                  return Redirect(HttpUtility.UrlDecode(returnUrl));
               }
               return Redirect("/");
            }
         }
         return View(info);
      }

      // GET: /User/Login

      public ActionResult Login(string returnUrl)
      {
         if (User.Identity.IsAuthenticated)
         {
            return Redirect("/");
         }
         return View();
      }

      // POST: /User/Login

      [HttpPost]
      public ActionResult Login(LoginModel info, string returnUrl)
      {
         if (ModelState.IsValid)
         {
            var user = membershipService.ValidateUser(info.Username, info.Password);
            if (user != null)
            {
               authService.AuthenticateUser(user);
               if (!String.IsNullOrWhiteSpace(returnUrl))
               {
                  return Redirect(HttpUtility.UrlDecode(returnUrl));
               }
               return Redirect("/");
            }
            ModelState.AddModelError("Password", "Неверный пароль");
         }
         return View(info);
      }

      // GET: /User/Logout

      public ActionResult Logout(string returnUrl)
      {
         authService.SignOut();

         if (!String.IsNullOrWhiteSpace(returnUrl))
         {
            return Redirect(HttpUtility.UrlDecode(returnUrl));
         }
         return Redirect("/");
      }
   }
}