﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Blog.Web.Mvc.Model;

namespace Blog.Web.Mvc.Controllers
{
   public class ErrorController : Controller
   {
      public ActionResult Index()
      {
         var model = new ErrorModel();

         var httpException = RouteData.Values["httpException"] as HttpException;

         var httpCode = (httpException == null) ? 500 : httpException.GetHttpCode();

         switch (httpCode)
         {
            case 403:
               Response.StatusCode = 403;
               model.Heading = "Доступ запрещен";
               model.Message = "У вас не хватает прав, чтобы выполнить это действие.";
               break;

            case 404:
               Response.StatusCode = 404;
               model.Heading = "Страница не найдена";
               model.Message = "Такой страницы у нас в блоге нет. Возможно, стоит воспользоваться поиском.";
               break;

            case 500:
            default:
               Response.StatusCode = 500;
               model.Heading = "Ошибка";
               model.Message = "Что-то пошло не так. Не волнуйтесь, мы разберемся.";
               break;
         }

         Response.TrySkipIisCustomErrors = true;

         return View(model);
      }
   }
}