﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using AutoMapper;
using Blog.Data;
using Blog.Domain;
using Blog.Infrastructure.Data;
using Blog.Web.Model;
using Lydian.Unity.Automapper;
using Microsoft.Practices.Unity;

namespace Blog.Web.Mvc
{
   public static class Unity
   {
      private static IUnityContainer container;

      public static IUnityContainer Container
      {
         get
         {
            if (container == null)
               throw new Exception("Unity container is not initialized.");

            return container;
         }
      }

      public static IUnityContainer Initialize()
      {
         container = BuildUnityContainer();
         return container;
      }

      public static T Resolve<T>()
      {
         return Container.Resolve<T>();
      }

      public static object Resolve(Type t, params ResolverOverride[] overrides)
      {
         return Container.Resolve(t, overrides);
      }

      private static IUnityContainer BuildUnityContainer()
      {
         var container = new UnityContainer();

         // Register all types
         var options = new MappingOptions(MappingBehaviors.MultimapByDefault);
         container.AutomapAssemblies(options, "Blog", "Blog.Infrastructure", "Blog.Web", "Blog.Web.Mvc");

         // Register repositories (they have params in ctor)
         var connectingString = ConfigurationManager.AppSettings.Get("MONGOLAB_URI")
                             ?? ConfigurationManager.AppSettings.Get("MongoUri");

         container.RegisterType<IArticleRepository, MongoDbArticleRepository>(
            new InjectionConstructor(connectingString));
         container.RegisterType<IUserRepository, MongoDbUserRepository>(
            new InjectionConstructor(connectingString));

         return container;
      }
   }
}