﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using AutoMapper;
using Blog.Web.Paging;

namespace Blog.Web.Mvc
{
   public static class Extensions
   {
      public static IPagedList<TDestination> Map<TSource, TDestination>(this IPagedList<TSource> list)
      {
         var sourceList = Mapper.Map<IEnumerable<TSource>, IEnumerable<TDestination>>(list);
         var result = new PagedList<TDestination>()
         {
            ItemCount = list.ItemCount,
            PageIndex = list.PageIndex,
            PageCount = list.PageCount,
            PrevPage = list.PrevPage,
            NextPage = list.NextPage,
         };
         result.AddRange(sourceList);
         return result;
      }

      public static string ToPrettyDate(this DateTime dateTime)
      {
         return dateTime.ToString("d MMMM yyyy в HH:mm");
      }
   }
}