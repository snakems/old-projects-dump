﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Blog.Web.Mvc.Model
{
   public class ErrorModel
   {
      public string Heading { get; set; }

      public string Message { get; set; }
   }
}