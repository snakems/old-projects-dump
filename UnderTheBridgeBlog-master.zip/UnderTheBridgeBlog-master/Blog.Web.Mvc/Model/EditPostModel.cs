﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Blog.Web.Mvc.Model
{
   public class EditPostModel
   {
      [Required(ErrorMessage = "Пост без заголовка? Нонсенс!")]
      public string Title { get; set; }

      [Required(ErrorMessage = "Как же обойтись без небольшой превьюшки?")]
      public string Preview { get; set; }

      [Required(ErrorMessage = "Что за пост без содержимого?")]
      public string Contents { get; set; }

      [Required(ErrorMessage = "Придумайте уж хотя бы один-два коротеньких тега")]
      [DisplayFormat(ConvertEmptyStringToNull = false)]
      public string Tags { get; set; }
   }
}