﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Blog.Web.Mvc.Model.Account
{
   public class LoginModel
   {
      [Required(ErrorMessage = "Надо ввести имя")]
      [Remote("IsUsernameTaken", "User", ErrorMessage = "Нет такого пользователя")]
      [RegularExpression("\\w{4,}", ErrorMessage = "Содержит недопустимые символы (либо короткий)")]
      public string Username { get; set; }

      [Required(ErrorMessage = "Надо ввести пароль")]
      [DataType(DataType.Password)]
      public string Password { get; set; }
   }
}