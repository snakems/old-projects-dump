﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Blog.Web.Model;

namespace Blog.Web.Mvc.Model
{
   public enum SearchType
   {
      Text,
      Tag,
      None,
   }

   public class SearchViewModel
   {
      public SearchType Type { get; set; }

      public string SearchPattern { get; set; }

      public List<ArticlePreviewInfo> Articles { get; set; }

      public SearchViewModel()
      {
         Type = SearchType.None;
         Articles = new List<ArticlePreviewInfo>();
      }
   }
}