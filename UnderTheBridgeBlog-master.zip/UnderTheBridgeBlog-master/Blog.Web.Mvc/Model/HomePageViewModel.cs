﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Blog.Web.Model;
using Blog.Web.Paging;

namespace Blog.Web.Mvc.Model
{
   public class HomePageViewModel
   {
      public IPagedList<ArticlePreviewInfo> Articles { get; set; }
   }
}