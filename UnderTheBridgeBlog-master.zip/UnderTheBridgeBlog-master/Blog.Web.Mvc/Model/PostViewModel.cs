﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Blog.Web.Model;

namespace Blog.Web.Mvc.Model
{
   public class PostViewModel
   {
      public ArticleFullInfo Article { get; set; }
   }
}