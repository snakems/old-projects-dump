﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Blog.Data;
using Blog.Services;
using Blog.Web.Mvc.Model;
using Blog.Web.Mvc.Services;
using Blog.Web.ServiceBus;

namespace Blog.Web.Mvc.ServiceBus
{
   public class UserViewHandler : MessageHandler<UserViewMessage>
   {
      private IBlogContext blogContext;
      private IMappingService mapper;

      public UserViewHandler(IUserContext userContext, IMappingService mapper,
                             IBlogContext blogContext)
         : base(userContext)
      {
         this.blogContext = blogContext;
         this.mapper = mapper;
      }

      public override Result Handle(UserViewMessage message)
      {
         var user = blogContext.Users.Find(message.UserId);
         if (user == null)
         {
            return new Result() { Successfull = false };
         }

         var posts = blogContext.Articles.All().Where(p => p.UserId == user.Id).Count();
         var comments = blogContext.Comments.All().Where(c => c.UserId == user.Id).Count();

         var show = String.Empty;
         if (!String.IsNullOrEmpty(message.Show))
         {
            var lower = message.Show.ToLowerInvariant();
            show = lower == "comments" ? lower : "posts";
         }
         else
         {
            show = (posts == 0 && comments > 0) ? "comments" : "posts";
         }

         bool canEdit = false;
         var current = userContext.GetCurrentUser();
         if (current != null && current.Id != user.Id && current.Roles.Contains("admin"))
            canEdit = true;

         var model = new UserViewModel()
         {
            User = mapper.Map(user),
            CanEdit = canEdit,
            Show = show,
            PageIndex = message.PageIndex,
            PageSize = message.PageSize,
            PostCount = posts,
            CommentCount = comments,
         };

         return new Result() { Successfull = true, Model = model };
      }
   }
}