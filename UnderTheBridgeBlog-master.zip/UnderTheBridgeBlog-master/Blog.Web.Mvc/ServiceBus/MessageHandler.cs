﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Blog.Services;
using Blog.Web.ServiceBus;

namespace Blog.Web.Mvc.ServiceBus
{
   public abstract class MessageHandler<T> : IHandler<T>
   {
      protected IUserContext userContext;

      public MessageHandler(IUserContext userContext)
      {
         this.userContext = userContext;
      }

      public abstract Result Handle(T message);
   }
}