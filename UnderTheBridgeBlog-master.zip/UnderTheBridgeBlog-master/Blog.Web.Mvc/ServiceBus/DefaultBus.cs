﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Blog.Web.ServiceBus;
using Microsoft.Practices.Unity;

namespace Blog.Web.Mvc.ServiceBus
{
   public class DefaultBus : IServiceBus
   {
      public Result Send(object message)
      {
         var messageType = message.GetType();
         var handlerType = typeof(IHandler<>).MakeGenericType(messageType);
         var handler = Unity.Resolve(handlerType);

         var method = handlerType.GetMethod("Handle");
         var result = method.Invoke(handler, new object[] { message });

         return (Result)result;
      }
   }
}