﻿function deleteArticle(id) {
   $.ajax({
      type: "POST",
      url: "/Post/Delete/" + id,
      data: { returnUrl: window.location.pathname }
   }).done(function (data) {
      if (data.success) {
         window.location.replace("/");
      }
      else {
         alert('Error removing article:\n' + data.message);
      }
   }).fail(function () {
      alert("Error sending ajax request");
   });
}