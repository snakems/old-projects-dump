﻿$(function () {
   // Validation
   $('form').addTriggersToJqueryValidate().triggerElementValidationsOnFormValidation();
});

function highlightElement(input) {
   var el = $(input);
   if (el.hasClass('input-validation-error')) {
      el.parents('div.item').addClass('error');
      //Set Tipsy text
      var fieldDiv = el.parents("div.item");
      var text = fieldDiv.find('span.field-validation-error').find('span').text();
      fieldDiv.attr("original-title", text.toString());
   } else {
      el.parents('div.item').removeClass('error');
      //Remove Tipsy text
      el.parents('div.item').removeAttr("original-title");
   }
}