﻿using AurumGoldLib.Physics;
using AurumGoldLib.World.Characters;
using Microsoft.Xna.Framework;

namespace AurumGoldLib.World.Props
{
   internal abstract class Collectible : Prop
   {
      #region Fields

      #endregion Fields

      #region Properties

      #endregion Properties

      #region Constructors

      public Collectible(Scene scene, Vector2 position, Vector2 size)
         : base(scene, position, size)
      {
      }

      #endregion Constructors

      #region Public Methods

      protected override bool OnCollision(Physical first, Physical second)
      {
         if (second.Entity is Player)
         {
            Pickup((Player)second.Entity);
         }
         return false;
      }

      public abstract void Pickup(Player player);

      #endregion Public Methods
   }
}