﻿using AurumGoldLib.Render;
using AurumGoldLib.World.Characters;
using Microsoft.Xna.Framework;

namespace AurumGoldLib.World.Props
{
   internal class Coin : Collectible
   {
      #region Properties

      public CoinType Type { get; private set; }

      #endregion Properties

      #region Constructors

      public Coin(Scene scene, CoinType type, Vector2 position)
         : base(scene, position, new Vector2(16, 16))
      {
         Type = type;
         switch (type)
         {
            case CoinType.Golden:
               sprite = new AnimatedSprite(1f, ContentHelper.GetTexture("Misc\\Spinning_coin_gold"), 8, 16);
               break;

            case CoinType.Silver:
               sprite = new AnimatedSprite(1f, ContentHelper.GetTexture("Misc\\Spinning_coin_silver"), 8, 16);
               break;
         }
      }

      #endregion Constructors

      #region Public Methods

      public override void Pickup(Player player)
      {
         Scene.RemoveFromScene(this);
      }

      #endregion Public Methods
   }
}