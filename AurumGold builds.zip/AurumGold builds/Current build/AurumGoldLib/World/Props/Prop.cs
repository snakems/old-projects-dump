﻿using AurumGoldLib.Physics;
using AurumGoldLib.Render;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace AurumGoldLib.World.Props
{
   internal abstract class Prop : Entity, IPhysical, IRenderable
   {
      #region Fields

      protected AnimatedSprite sprite;
      protected Physical physical;

      protected bool facingLeft;

      #endregion Fields

      #region Properties

      public int DrawOrder { get; protected set; }

      #endregion Properties

      #region Constructors

      public Prop(Scene scene, Vector2 position, Vector2 size)
         : base(scene)
      {
         physical = new Physical(this);
         physical.Position = position;
         physical.Size = size;
         physical.Static = true;
         physical.Collided += new CollisionEventHandler(OnCollision);

         DrawOrder = 2;
      }

      #endregion Constructors

      #region Public Methods

      protected virtual bool OnCollision(Physical first, Physical second)
      {
         return second.Static;
      }

      public Physical GetPhysical()
      {
         return physical;
      }

      public void Draw(SpriteBatch spriteBatch)
      {
         var drawRect = physical.AABB.Rect;
         sprite.Draw(spriteBatch, physical.AABB.Center, Color.White, facingLeft);
      }

      public override void Update(GameTime gameTime)
      {
         var elapsed = (float)gameTime.ElapsedGameTime.TotalSeconds;
         sprite.UpdateFrame(elapsed);
      }

      #endregion Public Methods
   }
}