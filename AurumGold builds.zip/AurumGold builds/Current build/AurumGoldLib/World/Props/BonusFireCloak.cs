﻿using AurumGoldLib.Render;
using AurumGoldLib.World.Characters;
using Microsoft.Xna.Framework;

namespace AurumGoldLib.World.Props
{
   internal class BonusFireCloak : Collectible
   {
      #region Constructors

      public BonusFireCloak(Scene scene, Vector2 position)
         : base(scene, position, new Vector2(32, 32))
      {
         sprite = new AnimatedSprite(1f, ContentHelper.GetTexture("Misc\\FireCloak"), 8, 12);
      }

      #endregion Constructors

      #region Public Methods

      public override void Pickup(Player player)
      {
         Scene.RemoveFromScene(this);
      }

      #endregion Public Methods
   }
}