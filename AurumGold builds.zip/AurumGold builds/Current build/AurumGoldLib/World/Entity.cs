﻿using Microsoft.Xna.Framework;

namespace AurumGoldLib.World
{
   internal abstract class Entity
   {
      #region Properties

      public Scene Scene { get; protected set; }

      #endregion Properties

      #region Constructors

      public Entity(Scene scene)
      {
         Scene = scene;
      }

      #endregion Constructors

      #region Public Methods

      public virtual void Update(GameTime gameTime) { }

      #endregion Public Methods
   }
}