﻿using System;
using AurumGoldLib.Extensions;
using AurumGoldLib.Input;
using AurumGoldLib.Physics;
using AurumGoldLib.Render;
using AurumGoldLib.World;
using AurumGoldLib.World.Characters;
using AurumGoldLib.World.Landscape;
using AurumGoldLib.World.Props;
using C3.XNA;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace AurumGoldLib.World.Characters
{
   internal class Player : Mob
   {
      #region Constants

      private static float PLAYER_INPUT_SCALE_GROUND = 50f * .8f;
      private static float PLAYER_INPUT_SCALE_AIR = 30f * .8f;

      private static float JUMP_VELOCITY = -17f; //30
      private static float OFF_LEDGE_JUMP_TIME = 0.125f;

      private static float DEFAULT_STUNNED_TIME = 2f;

      private static float SHOOT_COOLDOWN = 0.3f;

      #endregion Constants

      #region Fields

      private bool nictating;
      private float nictateRate = 1.0f / 10;

      private MobInput previousInput;

      private bool waitingForAttackRelease;

      private bool canShoot;

      #endregion Fields

      #region Properties

      #endregion Properties

      #region Constructor

      public Player(Scene scene)
         : base(scene, Vector2.Zero, new Vector2(1.5f, 1.5f))
      {
         this.canShoot = true;

         var blinkTexture = ContentHelper.GetTexture("Characters\\purple");
         sprites.Add("idle", new AnimatedSprite(physical.Size, blinkTexture, 1, 1));

         this.currentSprite = sprites["idle"];
      }

      #endregion Constructor

      #region Public Methods

      public override void Update(GameTime gameTime)
      {
         var elapsed = (float)gameTime.ElapsedGameTime.TotalSeconds;

         var previousSprite = currentSprite;
         currentSprite = sprites["idle"];

         var playerInput = InputManager.GatherPlayerInput();

         if (playerInput.MovementVector != Vector2.Zero)
         {
            //currentSprite = sprites["run"];
            facingLeft = playerInput.MovementVector.X < 0;
         }

         if (playerInput.Attack && !waitingForAttackRelease)
         {
            if (!previousInput.Attack && !waitingForAttackRelease)
               waitingForAttackRelease = true;
            PerformAttack();
         }

         if (waitingForAttackRelease)
            waitingForAttackRelease = playerInput.Attack;

         if (physical.OnGround)
            physical.Acceleration += playerInput.MovementVector * PLAYER_INPUT_SCALE_GROUND;
         else
            physical.Acceleration += playerInput.MovementVector * PLAYER_INPUT_SCALE_AIR;

         if (playerInput.Jump && !physical.AtCeiling)
         {
            if (CanJump() && !previousInput.Jump)
            {
               physical.SetVelocityY(JUMP_VELOCITY);
            }
         }

         previousInput = playerInput;

         //if (!physical.OnGround) currentSprite = sprites["jump"];
         if (currentSprite != previousSprite)
            currentSprite.Reset();

         currentSprite.UpdateFrame(elapsed);
      }

      public override void Draw(SpriteBatch spriteBatch)
      {
         var color = nictating ? new Color(128, 128, 128, 128) : Color.White;
         currentSprite.Draw(spriteBatch, physical.Position, color, facingLeft);
      }

      //TODO: insert some checks here
      public override bool TakeDamage(int amount, Vector2 direction)
      {
         return false;
      }

      #endregion Public Methods

      #region Protected Methods

      protected override bool OnCollision(Physical first, Physical second)
      {
         var target = second.Entity;
         if (target is Spike)
         {
            HitSpike((Spike)target);
         }
         if (target is Monster)
         {
            HitMonster((Monster)target);
            //return false;
         }
         return true;
      }

      #endregion Protected Methods

      #region Private Methods

      private void PerformAttack()
      {
         if (CanShoot())
         {
            canShoot = false;
            var velocity = new Vector2(400f, 0f);
            var mul = (facingLeft ? -1 : 1);
            var position = physical.Position + (physical.AABB.HalfWidth + new Vector2(8, 0)) * mul;
            var bullet = new Bullet(Scene, this, position, velocity * mul);
            Scene.AddToScene(bullet);
            Scene.Timers.Create(SHOOT_COOLDOWN, () => canShoot = true);
         }
      }

      private bool CanShoot()
      {
         return canShoot;
      }

      private bool CanJump()
      {
         return physical.OffGroundTime < Player.OFF_LEDGE_JUMP_TIME;
      }

      private void HitSpike(Spike spike)
      {
         if (HitDangerousObstacle())
            spike.SetBlooded();
      }

      private void HitMonster(Monster monster)
      {
      }

      /// <summary>
      /// Returns true if hit was occured.
      /// </summary>
      private bool HitDangerousObstacle()
      {
         if (TakeDamage(1, Vector2.Zero))
         {
            SetInvulnerable(Player.DEFAULT_STUNNED_TIME);
            return true;
         }
         return false;
      }

      private void SetInvulnerable(float time)
      {
         nictating = true;
         stunned = true;
         Scene.Timers.Create(nictateRate, () => nictating = !nictating, (int)(time / nictateRate));
         Scene.Timers.Create(time, () => stunned = nictating = false);
      }

      #endregion Private Methods
   }
}