﻿namespace AurumGoldLib.World
{
   public enum BonusType
   {
      DoubleJump,
      Shield,
      FireCloak,
   }
}