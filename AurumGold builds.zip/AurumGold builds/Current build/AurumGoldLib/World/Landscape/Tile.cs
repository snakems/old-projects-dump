﻿using AurumGoldLib.Physics;
using AurumGoldLib.Render;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace AurumGoldLib.World.Landscape
{
   internal abstract class Tile : Entity, IPhysical, IRenderable
   {
      #region Fields

      protected Physical physical;

      #endregion Fields

      #region Properties

      public bool Passable { get; set; }

      public int DrawOrder { get; protected set; }

      #endregion Properties

      #region Constructors

      public Tile(Scene scene, Rectangle rect)
         : base(scene)
      {
         physical = new Physical(new AABB(rect), this);
         physical.Static = true;

         DrawOrder = 4;
      }

      public Tile(Scene scene, Vector2 center, float width, float height)
         : base(scene)
      {
         physical = new Physical(new AABB(center, width, height), this);
         physical.Static = true;

         DrawOrder = 4;
      }

      #endregion Constructors

      #region Public Methods

      public Physical GetPhysical()
      {
         return physical;
      }

      public abstract void Draw(SpriteBatch spriteBatch);

      #endregion Public Methods
   }
}