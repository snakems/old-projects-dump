﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace AurumGoldLib.World.Landscape
{
   internal class Spike : Tile
   {
      private const float BLOODEED_TIME_DEFAULT = 20f;

      #region Fields

      private Texture2D texture_normal;
      private Texture2D texture_blooded;

      #endregion Fields

      #region Properties

      public bool Blooded { get; private set; }

      #endregion Properties

      #region Constructors

      public Spike(Scene scene, Rectangle rect)
         : base(scene, rect)
      {
         texture_normal = ContentHelper.GetTexture("Landscape\\Spikes\\texture_normal");
         texture_blooded = ContentHelper.GetTexture("Landscape\\Spikes\\texture_blooded");
      }

      #endregion Constructors

      #region Public Methods

      public void SetBlooded(float time = Spike.BLOODEED_TIME_DEFAULT)
      {
         Blooded = true;
         Scene.Timers.Create(time, () => Blooded = false);
      }

      public override void Draw(SpriteBatch spriteBatch)
      {
         var drawRect = physical.AABB.Rect;
         var texture = Blooded ? texture_blooded : texture_normal;
         spriteBatch.Draw(texture, drawRect, Color.White);
      }

      #endregion Public Methods
   }
}