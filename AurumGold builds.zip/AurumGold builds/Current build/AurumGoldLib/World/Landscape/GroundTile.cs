﻿using AurumGoldLib.Physics;
using AurumGoldLib.Render;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace AurumGoldLib.World.Landscape
{
   internal class GroundTile : Tile
   {
      #region Fields

      //protected Texture2D center;
      //protected Texture2D topEmpty;
      //protected Texture2D bottom;
      //protected Texture2D bottomEmpty;
      //protected Texture2D left;
      //protected Texture2D leftEmpty;

      protected AnimatedSprite sprite;
      protected Texture2D texture;

      #endregion Fields

      #region Properties

      //public bool TopEmpty { get; set; }

      //public bool BottomEmpty { get; set; }

      //public bool LeftEmpty { get; set; }

      //public bool RightEmpty { get; set; }

      #endregion Properties

      #region Constructors

      public GroundTile(Scene scene, Rectangle rect)
         : base(scene, rect)
      {
         physical.Collided += new CollisionEventHandler(OnCollision);

         texture = ContentHelper.GetTexture("Landscape\\ship_decoration");

         sprite = new AnimatedSprite(physical.Size, texture, 1, 1);
         //center = ContentHelper.GetTexture("Landscape\\Ground\\center");
         //left = ContentHelper.GetTexture("Landscape\\Ground\\left");
         //leftEmpty = ContentHelper.GetTexture("Landscape\\Ground\\leftEmpty");
         //topEmpty = ContentHelper.GetTexture("Landscape\\Ground\\topEmpty");
         //bottom = ContentHelper.GetTexture("Landscape\\Ground\\bottom");
         //bottomEmpty = ContentHelper.GetTexture("Landscape\\Ground\\bottomEmpty");
      }

      public GroundTile(Scene scene, Vector2 center, float width, float height)
         : base(scene, center, width, height)
      {
         physical.Collided += new CollisionEventHandler(OnCollision);

         texture = ContentHelper.GetTexture("Landscape\\ship_decoration");

         sprite = new AnimatedSprite(physical.Size, texture, 1, 1);
         //center = ContentHelper.GetTexture("Landscape\\Ground\\center");
         //left = ContentHelper.GetTexture("Landscape\\Ground\\left");
         //leftEmpty = ContentHelper.GetTexture("Landscape\\Ground\\leftEmpty");
         //topEmpty = ContentHelper.GetTexture("Landscape\\Ground\\topEmpty");
         //bottom = ContentHelper.GetTexture("Landscape\\Ground\\bottom");
         //bottomEmpty = ContentHelper.GetTexture("Landscape\\Ground\\bottomEmpty");
      }

      protected virtual bool OnCollision(Physical first, Physical second)
      {
         return !Passable;
      }

      #endregion Constructors

      #region Public Methods

      public override void Draw(SpriteBatch spriteBatch)
      {
         //var drawRect = physical.AABB.Rect;
         //spriteBatch.Draw(center, drawRect, Color.White);
         //var leftTexture = LeftEmpty ? leftEmpty : left;
         //spriteBatch.Draw(leftTexture, drawRect, Color.White);
         //var RightTexture = RightEmpty ? leftEmpty : left;
         //spriteBatch.Draw(RightTexture, drawRect, null, Color.White, 0, Vector2.Zero, SpriteEffects.FlipHorizontally, 0f);

         //if (TopEmpty)
         //   spriteBatch.Draw(topEmpty, new Rectangle(drawRect.X, drawRect.Y - 12, drawRect.Width, 25), Color.White);
         //var BottomTexture = BottomEmpty ? bottomEmpty : bottom;
         //spriteBatch.Draw(BottomTexture, drawRect, Color.White);

         sprite.Draw(spriteBatch, physical.Position, Color.White);
         //spriteBatch.Draw(texture, physical.AABB.Rect, Color.White);
      }

      #endregion Public Methods
   }
}