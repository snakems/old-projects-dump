﻿using System;
using System.Collections.Generic;
using System.Linq;
using AurumGoldLib.Core;
using AurumGoldLib.GameScreenManagement;
using AurumGoldLib.Physics;
using AurumGoldLib.Render;
using AurumGoldLib.World;
using AurumGoldLib.World.Characters;
using AurumGoldLib.World.Landscape;
using AurumGoldLib.World.Props;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace AurumGoldLib
{
   internal class Scene
   {
      #region Fields

      private PhysicsEngine physicsEngine;

      private Map map = new Map();
      private List<Entity> entities = new List<Entity>();

      private List<Collectible> props = new List<Collectible>();
      private List<Monster> monsters = new List<Monster>();

      private List<Entity> entitesToAdd = new List<Entity>();
      private List<Entity> entitesToRemove = new List<Entity>();

      private Player player;

      private BasicEffect effect;

      #endregion Fields

      #region Properties

      public Camera Camera { get; private set; }

      public TimerCollection Timers { get; private set; }

      #endregion Properties

      #region Constructors

      public Scene()
      {
         physicsEngine = new PhysicsEngine(68, 30);
         physicsEngine.Gravity = new Vector2(0, 9.8f * 4);
         Timers = new TimerCollection();

         LoadLevel();

         Camera = new Camera(this);
         Camera.Target = player;
         Camera.SnapToTarget();

         effect = new BasicEffect(RenderManager.Instance.GraphicsDevice);
         effect.World = Matrix.Identity;
         effect.Projection = Camera.ProjectionMatrix;
         effect.TextureEnabled = true;
         effect.VertexColorEnabled = true;
      }

      #endregion Constructors

      #region Public Methods

      public void AddToScene(Entity entity)
      {
         entitesToAdd.Add(entity);
      }

      public void RemoveFromScene(Entity entity)
      {
         entitesToRemove.Add(entity);
      }

      public void Update(GameTime gameTime)
      {
         var elapsed = (float)gameTime.ElapsedGameTime.TotalSeconds;

         Timers.Update(gameTime);

         UpdateAddedEntites();
         foreach (var entity in entities)
            entity.Update(gameTime);
         physicsEngine.Update(gameTime);
         UpdateRemovedEntities();
         //player.Update(gameTime);

         Camera.Update(elapsed);
         effect.View = Camera.ViewMatrix;

         if (player.HitPoints < 0)
            ScreenManager.Instance.AddScreen(new GameOverPopup());
      }

      public void Draw(SpriteBatch spriteBatch)
      {
         spriteBatch.Begin();
         map.DrawBackgroundLayer(spriteBatch);
         spriteBatch.End();

         spriteBatch.Begin(SpriteSortMode.Deferred, null, SamplerState.PointClamp, null, null, effect);
         var query = physicsEngine.QueryAABB(Camera.BoundsInMeters);

         foreach (var current in query.Select(p => p.Entity as IShadowCaster)
                                      .Where(p => p != null))
         {
            current.DrawShadow(spriteBatch);
         }
         foreach (var current in query.Select(p => p.Entity as IRenderable)
                                      .Where(p => p != null)
                                      .OrderBy(p => p.DrawOrder))
         {
            current.Draw(spriteBatch);
         }
         spriteBatch.End();

         spriteBatch.Begin();
         map.DrawMidgroundLayer(spriteBatch);
         map.DrawForegroundLayer(spriteBatch);
         spriteBatch.End();

         // Drawing HUD
         DrawHUD(spriteBatch);
      }

      #endregion Public Methods

      #region Private Methods

      private void UpdateAddedEntites()
      {
         foreach (var current in entitesToAdd)
         {
            if (!entities.Contains(current))
               entities.Add(current);
            if (current is IPhysical)
               physicsEngine.Add((IPhysical)current);
         }
         entitesToAdd.Clear();
      }

      private void UpdateRemovedEntities()
      {
         foreach (var current in entitesToRemove)
         {
            entities.Remove(current);
            if (current is IPhysical)
               physicsEngine.Remove((IPhysical)current);
         }
         entitesToRemove.Clear();
      }

      private void DrawHUD(SpriteBatch spriteBatch)
      {
      }

      private void LoadLevel()
      {
         var lines = System.IO.File.ReadAllLines(@"Content\Levels\Level1\Ground.txt");
         Vector2 playerPos = Vector2.Zero;
         for (int i = 0; i < lines.Length; ++i)
         {
            for (int j = 0; j < lines[i].Length; ++j)
            {
               var ch = lines[i][j];
               if (Char.ToUpper(ch) == 'W')
               {
                  var block = new GroundTile(this, new Vector2(j, i), 1, 1);
                  block.Passable = ch == 'w';
                  AddToScene(block);
                  continue;
               }
               //if (ch == 'C')
               //{
               //   var coin = new Coin(CoinType.Golden, new Vector2(j * 35 + 17, i * 35 + 17));
               //   AddToScene(coin);
               //}
               //if (ch == 'I')
               //{
               //   var bonus = new BonusShield(new Vector2(j * 35 + 17, i * 35 + 17));
               //   AddToScene(bonus);
               //}
               //if (ch == 'F')
               //{
               //   var bonus = new BonusFireCloak(new Vector2(j * 35 + 17, i * 35 + 17));
               //   AddToScene(bonus);
               //}
               //if (ch == 'L')
               //{
               //   var bonus = new BonusLife(new Vector2(j * 35 + 17, i * 35 + 17));
               //   AddToScene(bonus);
               //}
               //if (ch == 'M')
               //{
               //   var monster = new Monster(this);
               //   monster.GetPhysical().Position = new Vector2(j + 0.5f, i + 0.5f);
               //   monster.ResetPatrol();
               //   AddToScene(monster);
               //}
               if (ch == 'P')
               {
                  playerPos = new Vector2(j + 0.5f, i + 0.5f);
               }
            }
         }
         player = new Player(this);
         player.GetPhysical().Position = playerPos;
         AddToScene(player);
      }

      #endregion Private Methods
   }
}