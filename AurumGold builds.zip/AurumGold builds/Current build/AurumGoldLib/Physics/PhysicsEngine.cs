﻿using System;
using System.Collections.Generic;
using System.Linq;
using AurumGoldLib.Core;
using AurumGoldLib.World;
using Microsoft.Xna.Framework;

namespace AurumGoldLib.Physics
{
   internal sealed class PhysicsEngine
   {
      #region Constants

      public readonly Vector2 MaxVelocity = new Vector2(30f);

      private static float MAX_STEP = 0.0166666675f;
      private static float EPSILON = MAX_STEP / 10f;

      #endregion Constants

      #region Fields

      private QuadTree<Entity> quadTree;

      private List<IPhysical> dynamicEntities = new List<IPhysical>();
      private List<Physical> entitiesInCollision = new List<Physical>();

      #endregion Fields

      #region Properties

      public Vector2 Gravity { get; set; }

      #endregion Properties

      #region Constructors

      public PhysicsEngine(int width, int height)
      {
         var max = (float)Math.Max(width, height);
         quadTree = new QuadTree<Entity>(new AABB(new Vector2(max / 2), max, max), 2, false, 5);
      }

      #endregion Constructors

      #region Public Methods

      public void Add(IPhysical obj)
      {
         quadTree.Insert(obj.GetPhysical());
         if (!obj.GetPhysical().Static && !dynamicEntities.Contains(obj))
            dynamicEntities.Add(obj);
      }

      public void Remove(IPhysical obj)
      {
         obj.GetPhysical().Delete();
         dynamicEntities.Remove(obj);
      }

      public void Update(GameTime gameTime)
      {
         var elapsed = (float)gameTime.ElapsedGameTime.TotalSeconds;
         while (elapsed > 0f)
         {
            float dt = Math.Min(elapsed, MAX_STEP);
            PerformStep(dt);
            elapsed -= dt;
            if (elapsed < EPSILON) elapsed = 0f;
         }
      }

      public IEnumerable<Physical> QueryAABB(AABB aabb)
      {
         List<QuadTreeItem<Entity>> queryList;
         quadTree.Query(aabb, out queryList);
         return queryList.Cast<Physical>();
      }

      #endregion Public Methods

      #region Private Methods

      private void PerformStep(float dt)
      {
         foreach (IPhysical current in dynamicEntities)
         {
            var physical = current.GetPhysical();
            physical.Velocity += physical.Acceleration * dt;
            if (physical.GravityApplied)
               physical.Velocity += Gravity * dt;
            if (physical.OnGround)
               physical.SetVelocityX(physical.Velocity.X * (1f - physical.GroundFriction * dt));
            else
               physical.SetVelocityX(physical.Velocity.X * (1f - physical.AirFriction * dt));
            physical.Velocity = Vector2.Clamp(physical.Velocity, -MaxVelocity, MaxVelocity);
            physical.Position += physical.Velocity * dt;
            physical.Acceleration = Vector2.Zero;
            physical.OnGround = false;
            physical.AtCeiling = false;
         }
         foreach (IPhysical current in dynamicEntities)
         {
            var physical = current.GetPhysical();
            DoCollision(physical);
            physical.OffGroundTime += dt;
         }
      }

      private void DoCollision(Physical physicalA)
      {
         bool flag = false;
         int num = 0;
         int num2 = 0;
         Vector2 zero = Vector2.Zero;
         Vector2 smallestResolutionVector = new Vector2(float.MaxValue);
         entitiesInCollision.Clear();
         List<QuadTreeItem<Entity>> tempCollisionQueryList;
         quadTree.Query(physicalA.AABB, out tempCollisionQueryList);
         foreach (var current in tempCollisionQueryList)
         {
            var physicalB = (Physical)current;
            if (physicalA != physicalB)
            {
               bool flag2 = physicalA.AABB.Collides(physicalB.AABB, out zero);
               if (flag2)
               {
                  flag2 &= physicalA.OnCollision(physicalB);
                  flag2 &= physicalB.OnCollision(physicalA);
               }
               flag |= flag2;
               if (flag2)
               {
                  entitiesInCollision.Add(physicalB);
                  if (Math.Abs(zero.X) < Math.Abs(smallestResolutionVector.X))
                     smallestResolutionVector.X = zero.X;
                  if (Math.Abs(zero.Y) < Math.Abs(smallestResolutionVector.Y))
                     smallestResolutionVector.Y = zero.Y;
                  if (zero.X < 0f)
                     num--;
                  else if (zero.X > 0f)
                     num++;
                  if (zero.Y < 0f)
                     num2--;
                  else if (zero.Y > 0f)
                     num2++;
               }
            }
         }
         if (flag)
         {
            if (Math.Abs(num) > Math.Abs(num2))
            {
               smallestResolutionVector.Y = 0f;
               ResolveCollisionXThenY(physicalA, smallestResolutionVector);
            }
            else if (Math.Abs(num) < Math.Abs(num2))
            {
               smallestResolutionVector.X = 0f;
               ResolveCollisionYThenX(physicalA, smallestResolutionVector);
            }
            else
            {
               if (Math.Abs(smallestResolutionVector.X) <= Math.Abs(smallestResolutionVector.Y))
               {
                  smallestResolutionVector.Y = 0f;
                  ResolveCollisionXThenY(physicalA, smallestResolutionVector);
               }
               else
               {
                  smallestResolutionVector.X = 0f;
                  ResolveCollisionYThenX(physicalA, smallestResolutionVector);
               }
            }

            UpdateVelocitiesAndFlags(physicalA, smallestResolutionVector);
         }
      }

      private void ResolveCollisionXThenY(Physical physical, Vector2 smallestResolutionVector)
      {
         var zero = Vector2.Zero;
         var flag = false;
         physical.Position += smallestResolutionVector;
         var vector = new Vector2(0f, float.MaxValue);
         foreach (var current in entitiesInCollision)
         {
            if (physical.AABB.Collides(current.AABB, out zero))
            {
               flag = true;
               vector.Y = Math.Min(vector.Y, zero.Y);
            }
            //var flag2 = physical.AABB.Collides(current.AABB, out zero);
            //flag |= flag2;
            //if (flag2) vector.Y = Math.Min(vector.Y, zero.Y);
         }
         if (flag)
         {
            physical.Position += vector;
            UpdateVelocitiesAndFlags(physical, vector);
         }
      }

      private void ResolveCollisionYThenX(Physical physical, Vector2 smallestResolutionVector)
      {
         var zero = Vector2.Zero;
         var flag = false;
         physical.Position += smallestResolutionVector;
         var vector = new Vector2(float.MaxValue, 0f);
         foreach (var current in entitiesInCollision)
         {
            if (physical.AABB.Collides(current.AABB, out zero))
            {
               flag = true;
               vector.X = Math.Min(vector.X, zero.X);
            }
            //var flag2 = physical.AABB.Collides(current.AABB, out zero);
            //flag |= flag2;
            //if (flag2) vector.X = Math.Min(vector.X, zero.X);
         }
         if (flag)
         {
            physical.Position += vector;
            UpdateVelocitiesAndFlags(physical, vector);
         }
      }

      private void UpdateVelocitiesAndFlags(Physical physical, Vector2 smallestResolutionVector)
      {
         if ((smallestResolutionVector.X < 0f && physical.Velocity.X > 0f) ||
             (smallestResolutionVector.X > 0f && physical.Velocity.X < 0f))
         {
            physical.SetVelocityX(0f);
         }
         if ((smallestResolutionVector.Y < 0f && physical.Velocity.Y > 0f) ||
             (smallestResolutionVector.Y > 0f && physical.Velocity.Y < 0f))
         {
            physical.SetVelocityY(0f);
         }
         if (smallestResolutionVector.Y < 0f)
         {
            physical.OnGround = true;
            physical.OffGroundTime = 0f;
            //return;
         }
         if (smallestResolutionVector.Y > 0f)
         {
            physical.AtCeiling = true;
         }
      }

      #endregion Private Methods
   }
}