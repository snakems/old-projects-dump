﻿using AurumGoldLib.Physics;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace AurumGoldLib
{
   internal class Camera
   {
      private static float pixelsPerMeter = 64f; //64f
      private static float metersPerPixel = 1f / Camera.pixelsPerMeter;
      private static float SPEED = 4.5f;
      private Vector2 screenDimensions = new Vector2(1280f, 720f);
      private Viewport vp = new Viewport(0, 0, 1280, 720);

      private Vector2 velocity;
      private Vector2 position;
      private Vector2 minPosition;
      private Vector2 maxPosition;
      private Vector2 halfScreenInMeters;
      private IPhysical target;
      private Vector2 lastTargetPosition;
      private Scene scene;

      public IPhysical Target
      {
         get { return target; }
         set
         {
            target = value;
            lastTargetPosition = target.GetPhysical().Position;
         }
      }

      public Vector2 Offset { get; set; }

      public Matrix ViewMatrix { get; private set; }

      public Matrix ProjectionMatrix { get; private set; }

      public AABB BoundsInMeters { get; private set; }

      #region Camera physics (typically set when creating camera)

      /// <summary>
      /// Physics coefficient which controls the influence of the camera's position
      /// over the spring force. The stiffer the spring, the closer it will stay to
      /// the chased object.
      /// </summary>
      public float Stiffness
      {
         get { return stiffness; }
         set { stiffness = value; }
      }

      private float stiffness = 3000.0f;

      /// <summary>
      /// Physics coefficient which approximates internal friction of the spring.
      /// Sufficient damping will prevent the spring from oscillating infinitely.
      /// </summary>
      public float Damping
      {
         get { return damping; }
         set { damping = value; }
      }

      private float damping = 600.0f;

      /// <summary>
      /// Mass of the camera body. Heaver objects require stiffer springs with less
      /// damping to move at the same rate as lighter objects.
      /// </summary>
      public float Mass
      {
         get { return mass; }
         set { mass = value; }
      }

      private float mass = 30.0f;

      #endregion Camera physics (typically set when creating camera)

      public Camera(Scene scene)
      {
         this.scene = scene;
         Matrix matrix = Matrix.CreateTranslation(0f, 0f, 0f) * Camera.metersPerPixel;
         halfScreenInMeters = screenDimensions * Camera.metersPerPixel * 0.5f;
         ProjectionMatrix = matrix * Matrix.CreateOrthographicOffCenter(-halfScreenInMeters.X, halfScreenInMeters.X,
                                                                         halfScreenInMeters.Y, -halfScreenInMeters.Y,
                                                                         0.0f, -1f);
         minPosition = new Vector2(halfScreenInMeters.X - 0.5f, halfScreenInMeters.Y - 0.5f);
         maxPosition = new Vector2(68 - halfScreenInMeters.X - 2.5f, 30 - halfScreenInMeters.Y - 0.5f);
         BoundsInMeters = new AABB();
         BoundsInMeters.Width = 1280f * Camera.metersPerPixel + 1f;
         BoundsInMeters.Height = 720f * Camera.metersPerPixel + 1f;
      }

      public void Update(float elapsed)
      {
         if (Target == null) return;

         var targetPhysical = Target.GetPhysical();
         Vector2 targetPos = Vector2.Clamp(targetPhysical.Position, minPosition - Offset, maxPosition - Offset);
         Vector2 desiredPos = targetPos + Offset;
         //float targetSpeed = targetPhysical.Velocity.Length();
         //Vector2 direction = desiredPos - position;
         //float distance = direction.Length();
         //direction.Normalize();

         // Calculate spring force
         Vector2 stretch = position - desiredPos;
         Vector2 force = -stiffness * stretch - damping * velocity;
         // Apply acceleration
         Vector2 acceleration = force / mass;
         velocity += acceleration * elapsed;
         // Apply velocity
         position += velocity * elapsed;

         ViewMatrix = Matrix.CreateTranslation(-position.X, -position.Y, 0f);
         BoundsInMeters.Center = position;
      }

      public Vector2 WorldToScreen(Vector2 vector)
      {
         Vector3 vector3 = vp.Project(new Vector3(vector, 0.0f), ProjectionMatrix, ViewMatrix, Matrix.Identity);
         return new Vector2(vector3.X, vector3.Y);
      }

      public Vector2 ScreenToWorld(Vector2 vector)
      {
         Vector3 vector3 = vp.Unproject(new Vector3(vector, 0.0f), ProjectionMatrix, ViewMatrix, Matrix.Identity);
         return new Vector2(vector3.X, vector3.Y);
      }

      internal void SnapToTarget()
      {
         if (Target == null) return;

         var targetPhysical = Target.GetPhysical();
         Vector2 targetPos = Vector2.Clamp(targetPhysical.Position, minPosition - Offset, maxPosition - Offset);

         position = targetPos + Offset;
      }
   }
}