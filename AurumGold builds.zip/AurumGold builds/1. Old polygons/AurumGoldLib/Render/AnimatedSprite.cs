﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace AurumGoldLib.Render
{
   public class AnimatedSprite
   {
      private int framecount;
      private Texture2D texture;
      private float timePerFrame;
      private int frame;
      private float totalElapsed;
      private bool paused;

      public float Rotation { get; set; }

      public Vector2 Origin { get; set; }

      public bool IsPaused
      {
         get { return paused; }
      }

      public AnimatedSprite(Vector2 origin, float rotation, Texture2D texture, int frameCount, int framesPerSec)
      {
         this.Origin = origin;
         this.Rotation = rotation;
         this.texture = texture;
         this.framecount = frameCount;
         this.timePerFrame = 1.0f / framesPerSec;
         this.frame = 0;
         this.totalElapsed = 0;
         this.paused = false;
      }

      public void UpdateFrame(float elapsed)
      {
         if (paused)
            return;
         totalElapsed += elapsed;
         if (totalElapsed > timePerFrame)
         {
            frame++;
            frame = frame % framecount;
            totalElapsed -= timePerFrame;
         }
      }

      public void DrawFrame(SpriteBatch batch, Rectangle rect, Color color, bool flip = false)
      {
         DrawFrame(batch, frame, rect, color, flip);
      }

      public void DrawFrame(SpriteBatch batch, int frame, Rectangle rect, Color color, bool flip = false)
      {
         int FrameWidth = texture.Width / framecount;
         Rectangle sourcerect = new Rectangle(FrameWidth * frame, 0,
             FrameWidth, texture.Height);
         var effect = flip ? SpriteEffects.FlipHorizontally : SpriteEffects.None;
         batch.Draw(texture, rect, sourcerect, color,
             Rotation, Origin, effect, 0f);
      }

      public void Reset()
      {
         frame = 0;
         totalElapsed = 0f;
      }

      public void Stop()
      {
         Pause();
         Reset();
      }

      public void Play()
      {
         paused = false;
      }

      public void Pause()
      {
         paused = true;
      }
   }
}