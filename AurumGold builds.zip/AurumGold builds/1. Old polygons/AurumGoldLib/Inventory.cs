﻿using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;

namespace AurumGoldLib
{
   internal class Inventory
   {
      #region Fields

      private HashSet<Bonus> bonuses = new HashSet<Bonus>();

      #endregion Fields

      #region Properties

      public IEnumerable<Bonus> Bonuses { get { return bonuses; } }

      #endregion Properties

      #region Public Methods

      public void AddBonus(Bonus bonus)
      {
         var old = bonuses.SingleOrDefault(b => b.Type == bonus.Type);
         if (old != null)
         {
            if (bonus.Permanent)
            {
               bonuses.Remove(old);
               bonuses.Add(bonus);
            }
            else
            {
               old.AddDuration(bonus.DurationTotal.Value);
            }
         }
         else
         {
            bonuses.Add(bonus);
         }
      }

      public bool Contains(BonusType bonus)
      {
         return bonuses.Any(b => b.Type == bonus);
      }

      public void Update(GameTime gameTime)
      {
         var elapsed = (float)gameTime.ElapsedGameTime.TotalSeconds;
         foreach (var bonus in bonuses)
         {
            bonus.Update(gameTime);
         }
         bonuses.RemoveWhere(b => b.Expired);
      }

      #endregion Public Methods
   }
}