﻿using System;
using System.Collections.Generic;
using System.Linq;
using AurumGoldLib.Input;
using AurumGoldLib.Physics;
using AurumGoldLib.World.Mobs;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace AurumGoldLib
{
   public class Scene
   {
      #region Fields

      private List<Entity> sceneEntites = new List<Entity>();
      private PhysicsEngine physicsEngine;

      private Player player;

      private bool levelLoaded = false;
      private Level level;

      #endregion Fields

      #region Properties

      public Camera Camera { get; private set; }

      #endregion Properties

      #region Constructors

      public Scene()
      {
         Camera = new Camera(800, 600);
         physicsEngine = new PhysicsEngine();

         LoadLevel("PinkCave");
         player.Inventory.AddBonus(new Bonus(BonusType.DoubleJump));
      }

      #endregion Constructors

      #region Public Methods

      public void Update(GameTime gameTime)
      {
         UpdateObjects(gameTime);
         player.Update(gameTime);
         physicsEngine.Update(gameTime);

         Camera.Update();

         //if (InputManager.IsMouseKeyClicked(InputManager.MouseButtons.Left))
         //{
         //   var c = instance.Camera.ScreenToScene(new Vector2(InputManager.MouseCoordinates.X, InputManager.MouseCoordinates.Y));
         //   var coin = new Coin(CoinType.Golden, c);

         //   instance.physicsEngine.AddObject(coin);
         //   instance.sceneObjects.Add(coin);
         //   instance.level.StaticObjects.Add(coin);
         //}
         //if (InputManager.IsMouseKeyClicked(InputManager.MouseButtons.Right))
         //{
         //   var c = instance.Camera.ScreenToScene(new Vector2(InputManager.MouseCoordinates.X, InputManager.MouseCoordinates.Y));
         //   var coin = new Coin(CoinType.Silver, c);

         //   instance.physicsEngine.AddObject(coin);
         //   instance.sceneObjects.Add(coin);
         //   instance.level.StaticObjects.Add(coin);
         //}

         var c = Camera.ScreenToScene(new Vector2(InputManager.MouseCoordinates.X, InputManager.MouseCoordinates.Y));
         if (InputManager.IsMouseKeyClicked(InputManager.MouseButtons.Right))
         {
            System.IO.File.AppendAllText(@"D:\tst.txt", String.Format("\t\t<point value=\"{0},{1}\" />\n", (int)c.X, (int)c.Y));
         }

         DebugDraw.Write(new Vector2(100, 100), c.ToString());
      }

      public void Draw(SpriteBatch spriteBatch)
      {
         DrawObjects(spriteBatch);

         // Drawing HUD
         DrawHUD(spriteBatch);
      }

      #endregion Public Methods

      #region Private Methods

      private void UpdateObjects(GameTime gameTime)
      {
         var elapsed = (float)gameTime.ElapsedGameTime.TotalSeconds;
         foreach (var item in sceneEntites.Where(o => o.Dead).ToList())
         {
            sceneEntites.Remove(item);
            if (item is IPhysical)
               physicsEngine.RemoveObject((IPhysical)item);
         }
         foreach (var item in sceneEntites)
         {
            item.Update(gameTime);
         }
      }

      private void DrawObjects(SpriteBatch spriteBatch)
      {
         foreach (var item in sceneEntites)
         {
            if (Camera.IsOnScreen(item.BoundingRect))
               item.Draw(spriteBatch);
         }
         player.Draw(spriteBatch);
      }

      private void DrawHUD(SpriteBatch spriteBatch)
      {
         var heart = ContentHelper.GetTexture("Misc_Heart");
         var font = ContentHelper.GetFont("GuiFont");
         spriteBatch.Begin();
         for (int i = 0; i < player.HitPoints; ++i)
         {
            spriteBatch.Draw(heart, new Rectangle(10 + i * heart.Width, 10, heart.Width, heart.Height), Color.White);
         }
         var text = String.Format("Total gold: {0}", player.Gold);
         spriteBatch.DrawString(font, text, new Vector2(10, heart.Height + 15), Color.White);
         spriteBatch.End();
      }

      private void LoadLevel(string title)
      {
         if (levelLoaded)
         {
            sceneEntites.Clear();
            physicsEngine.ResetEngine();
         }
         physicsEngine.Gravity = new Vector2(0, 1400f);

         level = Level.Load(title);
         sceneEntites.AddRange(level.LevelObjects);
         foreach (var item in sceneEntites)
         {
            if (item is IPhysical)
               physicsEngine.AddObject((IPhysical)item);
         }

         player = new Player();
         player.GetPhysicsObject().Move(level.PlayerStartPosition);
         physicsEngine.AddObject(player);
         Camera.TrackingEntity = player;

         levelLoaded = true;
      }

      #endregion Private Methods
   }
}