﻿using System;
using System.Collections.Generic;
using System.Xml.Linq;
using AurumGoldLib.Extensions;
using AurumGoldLib.Physics;
using AurumGoldLib.World.Geometry;
using AurumGoldLib.World.Mobs;
using AurumGoldLib.World.Props;
using Microsoft.Xna.Framework;

namespace AurumGoldLib
{
   internal class Level
   {
      #region Fields

      private List<Entity> levelObjects = new List<Entity>();

      private Vector2 playerStartPosition = Vector2.Zero;

      #endregion Fields

      #region Properties

      public string Title { get; set; }

      public List<Entity> LevelObjects { get { return levelObjects; } }

      public Vector2 PlayerStartPosition { get { return playerStartPosition; } }

      #endregion Properties

      #region Constructors

      private Level() { }

      #endregion Constructors

      #region Static Methods

      public static Level Load(string title)
      {
         var level = new Level();

         var doc = XDocument.Load(@"Levels\" + title + ".xml");
         var root = doc.Root;

         level.Title = root.Attribute("title").Value;
         level.playerStartPosition = Vector2Extensions.Parse(root.Element("Player").Attribute("position").Value);

         foreach (var element in root.Element("StaticObjects").Elements())
         {
            var type = element.Name.LocalName;
            var points = new List<Vector2>();
            switch (type)
            {
               case "Block":
                  foreach (var point in element.Elements("point"))
                     points.Add(Vector2Extensions.Parse(point.Attribute("value").Value));
                  level.levelObjects.Add(new Block(points.ToArray()));
                  points.Clear();
                  break;
               case "Spike":
                  foreach (var point in element.Elements("point"))
                     points.Add(Vector2Extensions.Parse(point.Attribute("value").Value));
                  level.levelObjects.Add(new Spike(points.ToArray()));
                  points.Clear();
                  break;
               case "Coin":
                  var pos = Vector2Extensions.Parse(element.Attribute("position").Value);
                  var cointype = (CoinType)Enum.Parse(typeof(CoinType), element.Attribute("type").Value);
                  level.levelObjects.Add(new Coin(cointype, pos));
                  break;
               case "BonusLife":
                  pos = Vector2Extensions.Parse(element.Attribute("position").Value);
                  level.levelObjects.Add(new BonusLife(pos));
                  break;
               case "BonusShield":
                  pos = Vector2Extensions.Parse(element.Attribute("position").Value);
                  level.levelObjects.Add(new BonusShield(pos));
                  break;
               case "BonusFireCloak":
                  pos = Vector2Extensions.Parse(element.Attribute("position").Value);
                  level.levelObjects.Add(new BonusFireCloak(pos));
                  break;
               case "Monster":
                  pos = Vector2Extensions.Parse(element.Attribute("position").Value);
                  var monster = new Monster();
                  monster.GetPhysicsObject().Move(pos);
                  if (element.Attribute("patrol") != null)
                  {
                     var patrol = Vector2Extensions.Parse(element.Attribute("patrol").Value);
                     monster.SetPatrol(patrol.X, patrol.Y);
                  }
                  level.levelObjects.Add(monster);
                  break;

               default:
                  break;
            }
         }

         return level;
      }

      #endregion Static Methods

      #region Public Methods

      //public void Save(string path)
      //{
      //   var doc = new XDocument(
      //      new XDeclaration("1.0", "UTF-8", "yes"),
      //      new XElement("Level", new XAttribute("title", Title)));

      //   doc.Root.Add(
      //      new XElement("Player",
      //         new XAttribute("position", String.Format("{0},{1}", playerStartPosition.X, playerStartPosition.Y))));

      //   var staticObjs = new XElement("StaticObjects");
      //   foreach (var obj in LevelObjects)
      //   {
      //      var type = obj.GetType().Name;
      //      var el = new XElement(type);

      //      if (obj is Monster)
      //      {
      //      }
      //      else if (obj is Coin)
      //      {
      //         var pickup = (Coin)obj;
      //         var point = pickup.Position;
      //         el.Add(new XAttribute("position", String.Format("{0},{1}", point.X, point.Y)));
      //         el.Add(new XAttribute("type", pickup.Type));
      //      }
      //      else if (obj is IPhysical)
      //      {
      //         var geom = (IPhysical)obj;
      //         foreach (var point in geom.GetPhysicsObject().Body.Points)
      //            el.Add(new XElement("point", new XAttribute("value", String.Format("{0},{1}", point.X, point.Y))));
      //      }

      //      staticObjs.Add(el);
      //   }
      //   doc.Root.Add(staticObjs);
      //   if (!System.IO.Directory.Exists("Levels"))
      //      System.IO.Directory.CreateDirectory("Levels");
      //   doc.Save(@"Levels\" + Title + ".xml");
      //}

      #endregion Public Methods
   }
}