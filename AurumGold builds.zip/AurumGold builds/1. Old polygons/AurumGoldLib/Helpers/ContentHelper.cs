﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;

namespace AurumGoldLib
{
   public static class ContentHelper
   {
      private static ContentManager content;

      private static Dictionary<string, Texture2D> textures;
      private static Dictionary<string, SpriteFont> fonts;

      public static void Init(ContentManager manager)
      {
         content = manager;

         textures = new Dictionary<string, Texture2D>();
         fonts = new Dictionary<string, SpriteFont>();
      }

      public static Texture2D GetTexture(string asset)
      {
         if (textures == null)
            throw new Exception("ContentHelper was not initialized!");

         if (String.IsNullOrEmpty(asset))
            throw new ArgumentException("asset can't be null or empty!", "asset");

         if (!textures.ContainsKey(asset))
         {
            var texture = content.Load<Texture2D>("Sprites\\" + asset);
            textures.Add(asset, texture);
         }
         return textures[asset];

         throw new Exception("Asset was not found!");
      }

      public static SpriteFont GetFont(string asset)
      {
         if (fonts == null)
            throw new Exception("ContentHelper was not initialized!");

         if (String.IsNullOrEmpty(asset))
            throw new ArgumentException("asset can't be null or empty!", "asset");

         if (!fonts.ContainsKey(asset))
         {
            var font = content.Load<SpriteFont>("Fonts\\" + asset);
            fonts.Add(asset, font);
         }
         return fonts[asset];

         throw new Exception("Asset was not found!");
      }
   }
}