﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;

namespace AurumGoldLib
{
   public static class DebugDraw
   {
      private static SpriteFont font;
      private static SpriteBatch spriteBatch;

      private static Queue<Tuple<Vector2, string>> queue
         = new Queue<Tuple<Vector2, string>>();

      public static void Initialize(ContentManager content, SpriteBatch s)
      {
         font = content.Load<SpriteFont>(@"Fonts\DebugFont");
         spriteBatch = s;
      }

      public static void Write(Vector2 position, string text)
      {
         queue.Enqueue(Tuple.Create(position, text));
      }

      public static void Draw()
      {
         while (queue.Any())
         {
            var t = queue.Dequeue();
            spriteBatch.Begin();
            spriteBatch.DrawString(font, t.Item2, t.Item1, Color.Red);
            spriteBatch.End();
         }
      }
   }
}