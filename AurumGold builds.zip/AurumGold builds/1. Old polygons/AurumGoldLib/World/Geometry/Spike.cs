﻿using C3.XNA;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace AurumGoldLib.World.Geometry
{
   internal class Spike : Block
   {
      private const float BLOODEED_TIME_DEFAULT = 20f;

      private float bloodedTime;
      private float bloodedElapsed;

      public bool Blooded { get; private set; }

      public void SetBlooded(float time = Spike.BLOODEED_TIME_DEFAULT)
      {
         Blooded = true;
         bloodedTime = time;
      }

      public Spike(params Vector2[] points)
         : base(points)
      {
      }

      public override void Update(GameTime gameTime)
      {
         base.Update(gameTime);

         var elapsed = (float)gameTime.ElapsedGameTime.TotalSeconds;
         if (Blooded)
         {
            bloodedElapsed += elapsed;
            if (bloodedElapsed >= bloodedTime)
            {
               Blooded = false;
               bloodedElapsed = 0f;
            }
         }
      }

      public override void Draw(SpriteBatch spriteBatch)
      {
         spriteBatch.Begin();
         var points = physical.Body.Points;
         for (int i = 0; i < points.Length; ++i)
         {
            var p1 = Singleton<SceneManager>.Instance.CurrentScene.Camera.SceneToScreen(points[i]);
            var p2 = Singleton<SceneManager>.Instance.CurrentScene.Camera.SceneToScreen(points[(i + 1) % points.Length]);
            var color = Blooded ? Color.Red : Color.Black;
            spriteBatch.DrawLine(p1, p2, color);
         }
         spriteBatch.End();
      }
   }
}