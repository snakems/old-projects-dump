﻿using AurumGoldLib.Physics;
using C3.XNA;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace AurumGoldLib.World.Geometry
{
   internal class Block : Entity, IPhysical
   {
      public override Rectangle BoundingRect
      {
         get { return physical.Body.BoundingRect; }
      }

      protected PhysicalObject physical;

      public Block(params Vector2[] points)
      {
         physical = new PhysicalObject(this, Body.CreateBody(points));
         physical.Static = true;
      }

      public override void Draw(SpriteBatch spriteBatch)
      {
         spriteBatch.Begin();
         var points = physical.Body.Points;
         for (int i = 0; i < points.Length; ++i)
         {
            var p1 = Singleton<SceneManager>.Instance.CurrentScene.Camera.SceneToScreen(points[i]);
            var p2 = Singleton<SceneManager>.Instance.CurrentScene.Camera.SceneToScreen(points[(i + 1) % points.Length]);
            spriteBatch.DrawLine(p1, p2, Color.Red);
         }
         spriteBatch.End();
      }

      public override void Update(GameTime gameTime)
      {
      }

      public PhysicalObject GetPhysicsObject()
      {
         return physical;
      }
   }
}