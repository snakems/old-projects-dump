﻿using System.Collections.Generic;
using AurumGoldLib.AI;
using AurumGoldLib.Physics;
using AurumGoldLib.Render;
using C3.XNA;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace AurumGoldLib.World.Mobs
{
   internal abstract class Mob : Entity, IPhysical
   {
      #region Fields

      protected PhysicalObject physical;

      protected Dictionary<string, AnimatedSprite> sprites
         = new Dictionary<string, AnimatedSprite>();

      protected AnimatedSprite currentSprite;

      protected bool facingLeft;

      #endregion Fields

      #region Propetries

      public int HitPoints { get; protected set; }

      public PhysicalObject GetPhysicsObject()
      {
         return physical;
      }

      public override Rectangle BoundingRect
      {
         get { return physical.Body.BoundingRect; }
      }

      #endregion Propetries

      #region Constructors

      public Mob(Body body)
      {
         physical = new PhysicalObject(this, body);

         physical.GravityApplied = true;
         physical.GroundFriction = 6f;
         physical.AirFriction = 4.2f;

         physical.Collided += new CollisionEventHandler(OnCollision);
      }

      #endregion Constructors

      #region Public Methods

      /// <summary>
      /// Take some damage.
      /// </summary>
      /// <returns>True if damage was taken.</returns>
      public virtual bool TakeDamage(int amount)
      {
         HitPoints -= amount;
         if (HitPoints < 0) Dead = true;
         return true;
      }

      /// <summary>
      /// Gain some hit points.
      /// </summary>
      /// <returns>True if health was gained.</returns>
      public virtual bool GainHealth(int amount)
      {
         HitPoints += amount;
         return true;
      }

      public override void Update(GameTime gameTime)
      {
         var elapsed = (float)gameTime.ElapsedGameTime.TotalSeconds;
         currentSprite.UpdateFrame(elapsed);
      }

      public override void Draw(SpriteBatch spriteBatch)
      {
         DrawBoundingPolygon(spriteBatch);

         spriteBatch.Begin();

         var drawRect = Singleton<SceneManager>.Instance.CurrentScene.Camera.SceneToScreen(physical.Body.BoundingRect);
         currentSprite.DrawFrame(spriteBatch, drawRect, Color.White, facingLeft);

         spriteBatch.End();
      }

      #endregion Public Methods

      #region Protected Methods

      protected virtual bool OnCollision(PhysicalObject first, PhysicalObject second)
      {
         return second.Static;
      }

      protected void DrawBoundingPolygon(SpriteBatch spriteBatch, Color color)
      {
         spriteBatch.Begin();

         var points = physical.Body.Points;
         for (int i = 0; i < points.Length; ++i)
         {
            var p1 = Singleton<SceneManager>.Instance.CurrentScene.Camera.SceneToScreen(points[i]);
            var p2 = Singleton<SceneManager>.Instance.CurrentScene.Camera.SceneToScreen(points[(i + 1) % points.Length]);
            spriteBatch.DrawLine(p1, p2, color);
         }

         spriteBatch.End();
      }

      protected void DrawBoundingPolygon(SpriteBatch spriteBatch)
      {
         DrawBoundingPolygon(spriteBatch, Color.DarkBlue);
      }

      #endregion Protected Methods
   }
}