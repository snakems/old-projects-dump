﻿using AurumGoldLib.AI;
using AurumGoldLib.Physics;
using AurumGoldLib.Render;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace AurumGoldLib.World.Mobs
{
   internal class Monster : Mob
   {
      #region Fields

      private AIController controller;
      private float jumpVelocity = -400;

      #endregion Fields

      #region Properties

      public float Speed { get; set; }

      #endregion Properties

      #region Constructors

      public Monster()
         : base(Body.CreateBody(new Rectangle(2, 5, 28, 27)))
      {
         var runTexture = ContentHelper.GetTexture("Wheelie_run_right");
         sprites.Add("run", new AnimatedSprite(Vector2.Zero, 0f, runTexture, 4, 9));

         Speed = 400f;
         controller = new AIController(new IdleBehavior());

         currentSprite = sprites["run"];
      }

      #endregion Constructors

      #region Public Methods

      public void SetPatrol(float from, float to)
      {
         controller.Behavior = new PatrolBehaviour(this)
         {
            FromX = from,
            ToX = to,
         };
      }

      public void ResetPatrol()
      {
         controller = new AIController(new WanderBehavior()
         {
            MinWanderTime = 0.75f,
            MaxWanderTime = 2f,
            MinDelayTime = 0.25f,
            MaxDelayTime = 1f
         });
      }

      public override void Draw(SpriteBatch spriteBatch)
      {
         base.Draw(spriteBatch);
      }

      public override void Update(GameTime gameTime)
      {
         var elapsed = (float)gameTime.ElapsedGameTime.TotalSeconds;
         UpdateAI(elapsed);
         base.Update(gameTime);
      }

      public void UpdateAI(float elapsed)
      {
         if (controller == null || Dead)
            return;

         controller.Update(elapsed);
         physical.Acceleration += controller.MobInput.MovementVector * this.Speed;
         if (controller.MobInput.Jump)
            if (jumpVelocity != 0)
               physical.SetVelocityY(jumpVelocity);
         facingLeft = controller.MobInput.MovementVector.X < 0;
      }

      #endregion Public Methods
   }
}