﻿using AurumGoldLib.Render;
using Microsoft.Xna.Framework;

namespace AurumGoldLib.World.Props
{
   internal class BonusShield : Collectible
   {
      #region Constructors

      public BonusShield(Vector2 position)
         : base(new Rectangle(0, 0, 32, 32), position)
      {
         sprite = new AnimatedSprite(Vector2.Zero, 0f, ContentHelper.GetTexture("Misc_Invincibility"), 8, 12);
      }

      #endregion Constructors

      #region Public Methods

      public override void Pickup(Player player)
      {
         player.Inventory.AddBonus(new Bonus(BonusType.Shield, 5f));
         Dead = true;
      }

      #endregion Public Methods
   }
}