﻿namespace AurumGoldLib.World.Props
{
   public enum CoinType
   {
      Golden,
      Silver,
   }
}