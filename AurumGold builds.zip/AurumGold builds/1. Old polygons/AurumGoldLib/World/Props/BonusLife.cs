﻿using AurumGoldLib.Render;
using Microsoft.Xna.Framework;

namespace AurumGoldLib.World.Props
{
   internal class BonusLife : Collectible
   {
      #region Constructors

      public BonusLife(Vector2 position)
         : base(new Rectangle(0, 0, 16, 16), position)
      {
         sprite = new AnimatedSprite(Vector2.Zero, 0f, ContentHelper.GetTexture("Misc_Heart"), 1, 1);
      }

      #endregion Constructors

      #region Public Methods

      public override void Pickup(Player player)
      {
         if (player.GainHealth(1))
            Dead = true;
      }

      #endregion Public Methods
   }
}