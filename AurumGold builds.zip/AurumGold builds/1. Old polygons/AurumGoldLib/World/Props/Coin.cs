﻿using AurumGoldLib.Render;
using Microsoft.Xna.Framework;

namespace AurumGoldLib.World.Props
{
   internal class Coin : Collectible
   {
      #region Properties

      public CoinType Type { get; private set; }

      #endregion Properties

      #region Constructors

      public Coin(CoinType type, Vector2 position)
         : base(new Rectangle(0, 0, 16, 16), position)
      {
         Type = type;
         switch (type)
         {
            case CoinType.Golden:
               sprite = new AnimatedSprite(Vector2.Zero, 0f, ContentHelper.GetTexture("Misc_Spinning_coin_gold"), 8, 16);
               break;
            case CoinType.Silver:
               sprite = new AnimatedSprite(Vector2.Zero, 0f, ContentHelper.GetTexture("Misc_Spinning_coin_silver"), 8, 16);
               break;
         }
      }

      #endregion Constructors

      #region Public Methods

      public override void Pickup(Player player)
      {
         switch (Type)
         {
            case CoinType.Golden:
               player.Gold += 200;
               break;
            case CoinType.Silver:
               player.Gold += 100;
               break;
         }
         this.Dead = true;
      }

      #endregion Public Methods
   }
}