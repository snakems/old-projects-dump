﻿using AurumGoldLib.Physics;
using AurumGoldLib.Render;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace AurumGoldLib.World.Props
{
   internal abstract class Collectible : Entity, IPhysical
   {
      #region Fields

      protected AnimatedSprite sprite;
      protected PhysicalObject physical;

      #endregion Fields

      #region Properties

      public override Rectangle BoundingRect
      {
         get { return physical.Body.BoundingRect; }
      }

      #endregion Properties

      #region Constructors

      public Collectible(Rectangle rect, Vector2 position)
      {
         physical = new PhysicalObject(this, Body.CreateBody(rect));
         physical.Static = true;
         physical.Collided += new CollisionEventHandler(OnCollision);
         physical.Body.Offset(position);
      }

      #endregion Constructors

      #region Public Methods

      protected virtual bool OnCollision(PhysicalObject first, PhysicalObject second)
      {
         if (second.Entity is Player)
         {
            Pickup((Player)second.Entity);
         }
         return false;
      }

      public abstract void Pickup(Player player);

      public PhysicalObject GetPhysicsObject()
      {
         return physical;
      }

      public override void Draw(SpriteBatch spriteBatch)
      {
         spriteBatch.Begin();
         var drawRect = Singleton<SceneManager>.Instance.CurrentScene.Camera.SceneToScreen(BoundingRect);
         sprite.DrawFrame(spriteBatch, drawRect, Color.White);
         spriteBatch.End();
      }

      public override void Update(GameTime gameTime)
      {
         var elapsed = (float)gameTime.ElapsedGameTime.TotalSeconds;
         sprite.UpdateFrame(elapsed);
      }

      #endregion Public Methods
   }
}