﻿using AurumGoldLib.Render;
using Microsoft.Xna.Framework;

namespace AurumGoldLib.World.Props
{
   internal class BonusFireCloak : Collectible
   {
      #region Constructors

      public BonusFireCloak(Vector2 position)
         : base(new Rectangle(0, 0, 32, 32), position)
      {
         sprite = new AnimatedSprite(Vector2.Zero, 0f, ContentHelper.GetTexture("Misc_FireCloak"), 6, 12);
      }

      #endregion Constructors

      #region Public Methods

      public override void Pickup(Player player)
      {
         player.Inventory.AddBonus(new Bonus(BonusType.FireCloak, 5f));
         this.Dead = true;
      }

      #endregion Public Methods
   }
}