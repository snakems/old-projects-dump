﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace AurumGoldLib
{
   public abstract class Entity
   {
      /// <summary>
      /// If true, then we completly remove this object.
      /// </summary>
      public bool Dead { get; protected set; }

      public abstract Rectangle BoundingRect { get; }

      public abstract void Draw(SpriteBatch spriteBatch);

      public abstract void Update(GameTime gameTime);
   }
}