﻿using Microsoft.Xna.Framework;

namespace AurumGoldLib.Controllers
{
   internal class Trigger
   {
      public Rectangle BoundingRect { get; protected set; }

      public Trigger(Rectangle rect)
      {
         BoundingRect = rect;
      }
   }
}