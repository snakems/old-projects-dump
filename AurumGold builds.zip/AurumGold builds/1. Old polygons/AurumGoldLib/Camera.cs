﻿using Microsoft.Xna.Framework;

namespace AurumGoldLib
{
   public class Camera
   {
      #region Fields

      private float offsetX;
      private float offsetY;
      private int width;
      private int height;

      #endregion Fields

      #region Properties

      public Rectangle View { get; private set; }

      public Entity TrackingEntity { get; set; }

      public Rectangle TrackRectangle { get; set; }

      #endregion Properties

      #region Constructors

      public Camera(int width, int height)
      {
         this.width = width;
         this.height = height;
         InitView();

         TrackRectangle = new Rectangle(
            View.Width / 4, View.Height / 4,
            View.Width / 2, View.Height / 2);
      }

      #endregion Constructors

      #region Public Methods

      public void SetDirectTrack(Entity obj)
      {
         TrackingEntity = obj;
         TrackRectangle = obj.BoundingRect;
      }

      public void Offset(float x, float y)
      {
         offsetX += x;
         offsetY += y;
         InitView();
      }

      public void Inflate(int dwidth, int dheight)
      {
         width += dwidth;
         height += dheight;
         InitView();
      }

      public void Resize(int width, int height)
      {
         this.width = width;
         this.height = height;
         InitView();
      }

      public Vector2 SceneToScreen(Vector2 vector)
      {
         return new Vector2(vector.X - offsetX, vector.Y - offsetY);
      }

      public Vector2 ScreenToScene(Vector2 vector)
      {
         return new Vector2(vector.X + offsetX, vector.Y + offsetY);
      }

      public Rectangle SceneToScreen(Rectangle rect)
      {
         return new Rectangle((int)(rect.X - offsetX), (int)(rect.Y - offsetY), rect.Width, rect.Height);
      }

      public Rectangle ScreenToScene(Rectangle rect)
      {
         return new Rectangle((int)(rect.X + offsetX), (int)(rect.Y + offsetY), rect.Width, rect.Height);
      }

      public bool IsOnScreen(Vector2 vector)
      {
         return View.Contains((int)vector.X, (int)vector.Y);
      }

      public bool IsOnScreen(Rectangle rect)
      {
         return View.Intersects(rect);
      }

      public void Update()
      {
         if (TrackingEntity != null)
         {
            var objRect = TrackingEntity.BoundingRect;
            var rect = ScreenToScene(TrackRectangle);

            if (objRect.Left < rect.Left)
               Offset(objRect.Left - rect.Left, 0);
            if (objRect.Right > rect.Right)
               Offset(objRect.Right - rect.Right, 0);
            if (objRect.Top < rect.Top)
               Offset(0, objRect.Top - rect.Top);
            if (objRect.Bottom > rect.Bottom)
               Offset(0, objRect.Bottom - rect.Bottom);
         }
      }

      #endregion Public Methods

      #region Private Methods

      private void InitView()
      {
         View = new Rectangle((int)offsetX, (int)offsetY, width, height);
      }

      #endregion Private Methods
   }
}