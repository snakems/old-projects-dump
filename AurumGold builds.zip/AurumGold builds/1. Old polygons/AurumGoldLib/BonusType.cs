﻿namespace AurumGoldLib
{
   public enum BonusType
   {
      DoubleJump,
      Shield,
      FireCloak,
   }
}