﻿using AurumGoldLib.Input;

namespace AurumGoldLib.AI
{
   public class IdleBehavior : MobBehavior
   {
      public override MobInput Think(float elapsed)
      {
         return MobInput.Empty;
      }
   }
}