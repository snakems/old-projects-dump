﻿using System;
using AurumGoldLib.Input;

namespace AurumGoldLib.AI
{
   internal class WanderBehavior : MobBehavior
   {
      protected Random rand = new Random((int)DateTime.Now.Ticks);
      protected float decisionTimer;
      protected MobInput currentState;

      public float MinWanderTime { get; set; }

      public float MaxWanderTime { get; set; }

      public float MinDelayTime { get; set; }

      public float MaxDelayTime { get; set; }

      public override MobInput Think(float elapsed)
      {
         decisionTimer -= elapsed;
         if (decisionTimer <= 0.0)
            ChangeDirection();
         return currentState;
      }

      private void ChangeDirection()
      {
         if (currentState.MovementVector.X == 0)
         {
            decisionTimer = MinWanderTime + (float)(rand.NextDouble() * (MaxWanderTime - MinWanderTime));
            currentState = rand.NextDouble() > 0.5 ? MobInput.MoveLeft : MobInput.MoveRight;
         }
         else if (currentState.MovementVector.X < 0)
         {
            decisionTimer = MinDelayTime + (float)(rand.NextDouble() * (MaxDelayTime - MinDelayTime));
            currentState = MobInput.Empty;
         }
         else if (currentState.MovementVector.X > 0)
         {
            decisionTimer = MinDelayTime + (float)(rand.NextDouble() * (MaxDelayTime - MinDelayTime));
            currentState = MobInput.Empty;
         }
      }
   }
}