﻿using AurumGoldLib.Input;
using AurumGoldLib.World.Mobs;

namespace AurumGoldLib.AI
{
   internal class PatrolBehaviour : MobBehavior
   {
      protected Mob mob;

      protected MobInput currentState;

      public float FromX { get; set; }

      public float ToX { get; set; }

      public PatrolBehaviour(Mob mob)
      {
         this.mob = mob;
         this.currentState = MobInput.MoveRight;
      }

      public override MobInput Think(float elapsed)
      {
         if (FromX >= ToX)
            return MobInput.Empty;

         if (mob.BoundingRect.Center.X < FromX)
            return currentState = MobInput.MoveRight;
         if (mob.BoundingRect.Center.X > ToX)
            return currentState = MobInput.MoveLeft;

         return currentState;
      }
   }
}