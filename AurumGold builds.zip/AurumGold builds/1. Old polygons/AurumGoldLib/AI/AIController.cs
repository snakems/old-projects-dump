﻿using AurumGoldLib.Input;

namespace AurumGoldLib.AI
{
   public class AIController
   {
      public MobBehavior Behavior { get; set; }

      public MobInput MobInput { get; protected set; }

      public AIController(MobBehavior behavior)
      {
         this.Behavior = behavior;
      }

      public void Update(float elapsed)
      {
         MobInput = Behavior.Think(elapsed);
      }
   }
}