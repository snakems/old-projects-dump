﻿using AurumGoldLib.Input;

namespace AurumGoldLib.AI
{
   public abstract class MobBehavior
   {
      public abstract MobInput Think(float elapsed);
   }
}