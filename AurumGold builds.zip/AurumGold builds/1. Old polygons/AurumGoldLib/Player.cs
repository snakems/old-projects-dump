﻿using System;
using System.Collections.Generic;
using AurumGoldLib.Input;
using AurumGoldLib.Physics;
using AurumGoldLib.Render;
using AurumGoldLib.World.Geometry;
using AurumGoldLib.World.Mobs;
using C3.XNA;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace AurumGoldLib
{
   internal class Player : Mob
   {
      #region Constants

      private static float PLAYER_INPUT_SCALE_GROUND = 1000f;
      private static float PLAYER_INPUT_SCALE_AIR = 750f;

      private static float MAX_JUMP_TIME = 0.61f;
      private static float JUMP_VELOCITY = -500f;
      private static float JUMP_CONTROL_POWER = 0.85f;
      private static float OFF_LEDGE_JUMP_TIME = 0.125f;

      private static float DEFAULT_HIT_INVULNERABLE_TIME = 2f;

      #endregion Constants

      #region Fields

      private float invulnerableTime;
      private float invulnerableElapsed;

      private bool nictating;
      private float nictateRate = 1.0f / 10;
      private float nictateElapsed;

      private MobInput previousInput;

      private bool waitingForJumpRelease;

      private bool hasJumped;
      private bool hasDoubleJumped;

      private float jumpTime;

      #endregion Fields

      #region Properties

      public Inventory Inventory { get; private set; }

      public int Gold { get; set; }

      public bool Invulnerable { get; private set; }

      #endregion Properties

      #region Constructor

      public Player()
         : base(Body.CreateBody(new Vector2[]
         {
            new Vector2(12,0),
            new Vector2(38,1),
            new Vector2(48,38),
            new Vector2(40,50),
            new Vector2(10,50),
            new Vector2(2,38),
         }))
      {
         this.Inventory = new Inventory();
         this.HitPoints = 3;

         var runTexture = ContentHelper.GetTexture("Hero_run_right");
         sprites.Add("run", new AnimatedSprite(Vector2.Zero, 0f, runTexture, 8, 18));
         var blinkTexture = ContentHelper.GetTexture("Hero_blink_right");
         sprites.Add("blink", new AnimatedSprite(Vector2.Zero, 0f, blinkTexture, 8, 6));
         var jumpTexture = ContentHelper.GetTexture("Hero_jump_right");
         sprites.Add("jump", new AnimatedSprite(Vector2.Zero, 0f, jumpTexture, 1, 1));

         this.currentSprite = sprites["blink"];
      }

      #endregion Constructor

      #region Public Methods

      public override void Update(GameTime gameTime)
      {
         var elapsed = (float)gameTime.ElapsedGameTime.TotalSeconds;

         Inventory.Update(gameTime);

         if (Invulnerable)
         {
            nictateElapsed += elapsed;
            if (nictateElapsed > nictateRate)
            {
               nictating = !nictating;
               nictateElapsed -= nictateRate;
            }
            invulnerableElapsed += elapsed;
            if (invulnerableElapsed > invulnerableTime)
            {
               Invulnerable = false;
               nictating = false;
               invulnerableElapsed = 0;
            }
         }

         var previousSprite = currentSprite;
         currentSprite = sprites["blink"];

         var playerInput = InputManager.GatherPlayerInput();

         if (playerInput.MovementVector != Vector2.Zero)
         {
            currentSprite = sprites["run"];
            facingLeft = playerInput.MovementVector.X < 0;
         }

         if (physical.OnGround)
            physical.Acceleration += playerInput.MovementVector * PLAYER_INPUT_SCALE_GROUND;
         else
            physical.Acceleration += playerInput.MovementVector * PLAYER_INPUT_SCALE_AIR;

         if (waitingForJumpRelease) waitingForJumpRelease = playerInput.Jump;
         if (physical.OnGround)
         {
            hasJumped = false;
            hasDoubleJumped = false;
         }
         if (!waitingForJumpRelease && playerInput.Jump && !physical.AtCeiling)
         {
            if ((CanJump() || CanDoubleJump()) && !previousInput.Jump || jumpTime > 0.0f)
            {
               if (jumpTime == 0.0f)
               {
                  if (hasJumped || !CanJump())
                     hasDoubleJumped = true;
                  hasJumped = true;
               }
               jumpTime += elapsed;
            }
            if (jumpTime > 0.0 && jumpTime <= Player.MAX_JUMP_TIME)
            {
               var v = JUMP_VELOCITY * (1f - (float)Math.Pow(jumpTime / MAX_JUMP_TIME, JUMP_CONTROL_POWER));
               physical.SetVelocityY(v);
            }
            else
            {
               jumpTime = 0.0f;
            }
         }
         else
         {
            jumpTime = 0.0f;
         }
         previousInput = playerInput;

         if (!physical.OnGround) currentSprite = sprites["jump"];
         if (currentSprite != previousSprite)
            currentSprite.Reset();

         currentSprite.UpdateFrame(elapsed);
      }

      public override void Draw(SpriteBatch spriteBatch)
      {
         DrawBoundingPolygon(spriteBatch);

         spriteBatch.Begin();

         var drawRect = Singleton<SceneManager>.Instance.CurrentScene.Camera.SceneToScreen(physical.Body.BoundingRect);
         var color = nictating ? new Color(128, 128, 128, 128) : Color.White;
         currentSprite.DrawFrame(spriteBatch, drawRect, color, facingLeft);

         if (Inventory.Contains(BonusType.Shield))
         {
            var v = new Vector2(drawRect.Center.X, drawRect.Center.Y);
            spriteBatch.DrawCircle(v, (drawRect.Width + drawRect.Height) / 4, 40, Color.Green);
         }
         if (Inventory.Contains(BonusType.FireCloak))
         {
            var v = new Vector2(drawRect.Center.X, drawRect.Center.Y);
            spriteBatch.DrawCircle(v, (drawRect.Width + drawRect.Height) / 3, 40, Color.OrangeRed);
         }

         spriteBatch.End();
      }

      public void SetInvulnerable(float time)
      {
         invulnerableTime = time;
         Invulnerable = true;
         nictating = true;
      }

      public override bool TakeDamage(int amount)
      {
         if (!Inventory.Contains(BonusType.Shield) && !Invulnerable)
         {
            HitPoints -= amount;
            return true;
         }
         return false;
      }

      #endregion Public Methods

      #region Private Methods

      protected override bool OnCollision(PhysicalObject first, PhysicalObject second)
      {
         var target = second.Entity;
         if (target is Spike)
         {
            HitSpike((Spike)target);
         }
         if (target is Monster)
         {
            HitMonster((Monster)target);
            return false;
         }
         return true;
      }

      private bool CanJump()
      {
         return physical.OffGroundTime < Player.OFF_LEDGE_JUMP_TIME;
      }

      private bool CanDoubleJump()
      {
         return Inventory.Contains(BonusType.DoubleJump) && !hasDoubleJumped;
      }

      private void HitSpike(Spike spike)
      {
         if (HitDangerousObstacle())
            spike.SetBlooded();
      }

      private void HitMonster(Monster monster)
      {
         if (Inventory.Contains(BonusType.FireCloak))
         {
            monster.TakeDamage(1);
         }
         else if (HitDangerousObstacle())
         {
            // First hit, player start nictating
         }
      }

      /// <summary>
      /// Returns true if hit was occured.
      /// </summary>
      private bool HitDangerousObstacle()
      {
         if (TakeDamage(1))
         {
            SetInvulnerable(Player.DEFAULT_HIT_INVULNERABLE_TIME);
            return true;
         }
         return false;
      }

      #endregion Private Methods
   }
}