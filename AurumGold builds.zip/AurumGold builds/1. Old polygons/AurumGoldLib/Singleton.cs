﻿namespace AurumGoldLib
{
   public class Singleton<T> where T : class, new()
   {
      private static T instance = new T();

      static Singleton() { }

      public static T Instance
      {
         get { return instance; }
      }
   }
}