﻿using Microsoft.Xna.Framework;

namespace AurumGoldLib
{
   public class Bonus
   {
      #region Fields

      private bool expired;

      #endregion Fields

      #region Properties

      public BonusType Type { get; private set; }

      public bool Permanent { get; private set; }

      public bool Expired { get { return !Permanent && expired; } }

      public float? DurationTotal { get; private set; }

      public float? DurationElapsed { get; private set; }

      #endregion Properties

      #region Constructors

      /// <summary>
      /// Create permanent bonus.
      /// </summary>
      public Bonus(BonusType name)
      {
         Type = name;
         Permanent = true;
      }

      /// <summary>
      /// Create temporary bonus.
      /// </summary>
      public Bonus(BonusType name, float duration)
      {
         Type = name;
         DurationTotal = duration;
         DurationElapsed = 0f;
      }

      #endregion Constructors

      #region Public Methods

      public void AddDuration(float duration)
      {
         if (!Permanent)
         {
            DurationTotal += duration;
         }
      }

      public void Update(GameTime gameTime)
      {
         if (!Permanent)
         {
            var elapsed = (float)gameTime.ElapsedGameTime.TotalSeconds;
            DurationElapsed += elapsed;
            if (DurationElapsed >= DurationTotal)
            {
               expired = true;
            }
         }
      }

      #endregion Public Methods
   }
}