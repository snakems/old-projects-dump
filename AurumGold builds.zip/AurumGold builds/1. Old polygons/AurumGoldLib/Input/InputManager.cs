﻿using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Input;

namespace AurumGoldLib.Input
{
   /// <summary>
   /// This class handles all keyboard and gamepad actions in the game.
   /// </summary>
   public static class InputManager
   {
      #region MouseButtons

      public enum MouseButtons
      {
         Left,
         Right,
         Middle,
      }

      #endregion MouseButtons

      #region Action Enumeration

      /// <summary>
      /// The actions that are possible within the game.
      /// </summary>
      public enum Action
      {
         Back,
         Ok,
         Up,
         Down,
         Left,
         Right,
         TotalActionCount
      }

      #endregion Action Enumeration

      #region Support Types

      /// <summary>
      /// A combination of gamepad and keyboard keys mapped to a particular action.
      /// </summary>
      public class ActionMap
      {
         /// <summary>
         /// List of Keyboard controls to be mapped to a given action.
         /// </summary>
         public List<Keys> keyboardKeys = new List<Keys>();
      }

      #endregion Support Types

      #region Keyboard Data

      private static KeyboardState previousKeyboardState;
      private static KeyboardState currentKeyboardState;

      public static KeyboardState CurrentKeyboardState
      {
         get { return currentKeyboardState; }
      }

      public static bool IsKeyPressed(Keys key)
      {
         return currentKeyboardState.IsKeyDown(key);
      }

      public static bool IsKeyTriggered(Keys key)
      {
         return (currentKeyboardState.IsKeyDown(key)) &&
             (!previousKeyboardState.IsKeyDown(key));
      }

      #endregion Keyboard Data

      #region Mouse Data

      private static MouseState previousMouseState;
      private static MouseState currentMouseState;

      public static MouseState CurrentMouseState
      {
         get { return currentMouseState; }
      }

      public static bool IsMouseKeyJustPressed(MouseButtons key)
      {
         switch (key)
         {
            case MouseButtons.Left:
               return currentMouseState.LeftButton == ButtonState.Pressed &&
                  previousMouseState.LeftButton == ButtonState.Released;
            case MouseButtons.Right:
               return currentMouseState.RightButton == ButtonState.Pressed &&
                  previousMouseState.RightButton == ButtonState.Released;
            case MouseButtons.Middle:
               return currentMouseState.MiddleButton == ButtonState.Pressed &&
                  previousMouseState.MiddleButton == ButtonState.Released;
            default:
               return false;
         }
      }

      public static bool IsMouseKeyPressed(MouseButtons key)
      {
         switch (key)
         {
            case MouseButtons.Left:
               return currentMouseState.LeftButton == ButtonState.Pressed;
            case MouseButtons.Right:
               return currentMouseState.RightButton == ButtonState.Pressed;
            case MouseButtons.Middle:
               return currentMouseState.MiddleButton == ButtonState.Pressed;
            default:
               return false;
         }
      }

      public static bool IsMouseKeyClicked(MouseButtons key)
      {
         switch (key)
         {
            case MouseButtons.Left:
               return currentMouseState.LeftButton == ButtonState.Released &&
                  previousMouseState.LeftButton == ButtonState.Pressed;
            case MouseButtons.Right:
               return currentMouseState.RightButton == ButtonState.Released &&
                  previousMouseState.RightButton == ButtonState.Pressed;
            case MouseButtons.Middle:
               return currentMouseState.MiddleButton == ButtonState.Released &&
                  previousMouseState.MiddleButton == ButtonState.Pressed;
            default:
               return false;
         }
      }

      public static bool MouseChanged()
      {
         return previousMouseState != currentMouseState;
      }

      /// <summary>
      /// Get mouse position relative to screen.
      /// </summary>
      public static Point MouseCoordinates
      {
         get { return new Point(currentMouseState.X, currentMouseState.Y); }
      }

      #endregion Mouse Data

      #region Action Mapping

      /// <summary>
      /// The action mappings for the game.
      /// </summary>
      private static ActionMap[] actionMaps;

      public static ActionMap[] ActionMaps
      {
         get { return actionMaps; }
      }

      /// <summary>
      /// Reset the action maps to their default values.
      /// </summary>
      private static void ResetActionMaps()
      {
         actionMaps = new ActionMap[(int)Action.TotalActionCount];

         actionMaps[(int)Action.Back] = new ActionMap();
         actionMaps[(int)Action.Back].keyboardKeys.Add(
             Keys.Escape);

         actionMaps[(int)Action.Ok] = new ActionMap();
         actionMaps[(int)Action.Ok].keyboardKeys.Add(
             Keys.Enter);

         actionMaps[(int)Action.Back] = new ActionMap();
         actionMaps[(int)Action.Back].keyboardKeys.Add(
             Keys.Escape);

         actionMaps[(int)Action.Up] = new ActionMap();
         actionMaps[(int)Action.Up].keyboardKeys.Add(
             Keys.Up);

         actionMaps[(int)Action.Down] = new ActionMap();
         actionMaps[(int)Action.Down].keyboardKeys.Add(
             Keys.Down);

         actionMaps[(int)Action.Left] = new ActionMap();
         actionMaps[(int)Action.Left].keyboardKeys.Add(
             Keys.Left);

         actionMaps[(int)Action.Right] = new ActionMap();
         actionMaps[(int)Action.Right].keyboardKeys.Add(
             Keys.Right);
      }

      /// <summary>
      /// Check if an action has been pressed.
      /// </summary>
      public static bool IsActionPressed(Action action)
      {
         return IsActionMapPressed(actionMaps[(int)action]);
      }

      /// <summary>
      /// Check if an action was just performed in the most recent update.
      /// </summary>
      public static bool IsActionTriggered(Action action)
      {
         return IsActionMapTriggered(actionMaps[(int)action]);
      }

      /// <summary>
      /// Check if an action map has been pressed.
      /// </summary>
      private static bool IsActionMapPressed(ActionMap actionMap)
      {
         for (int i = 0; i < actionMap.keyboardKeys.Count; i++)
         {
            if (IsKeyPressed(actionMap.keyboardKeys[i]))
            {
               return true;
            }
         }
         return false;
      }

      /// <summary>
      /// Check if an action map has been triggered this frame.
      /// </summary>
      private static bool IsActionMapTriggered(ActionMap actionMap)
      {
         for (int i = 0; i < actionMap.keyboardKeys.Count; i++)
         {
            if (IsKeyTriggered(actionMap.keyboardKeys[i]))
            {
               return true;
            }
         }
         return false;
      }

      #endregion Action Mapping

      #region Initialization

      /// <summary>
      /// Initializes the default control keys for all actions.
      /// </summary>
      public static void Initialize()
      {
         ResetActionMaps();
      }

      #endregion Initialization

      #region Updating

      /// <summary>
      /// Updates the keyboard and mouse control states.
      /// </summary>
      public static void Update()
      {
         // update the keyboard state
         previousKeyboardState = currentKeyboardState;
         currentKeyboardState = Keyboard.GetState();

         // update the mouse state;
         previousMouseState = currentMouseState;
         currentMouseState = Mouse.GetState();
      }

      public static MobInput GatherPlayerInput()
      {
         var input = new MobInput();

         if (InputManager.IsActionPressed(InputManager.Action.Left))
            input.MovementVector = new Vector2(-1, 0);
         if (InputManager.IsActionPressed(InputManager.Action.Right))
            input.MovementVector = new Vector2(1, 0);
         if (InputManager.IsActionPressed(InputManager.Action.Up))
            input.Jump = true;
         if (InputManager.IsActionPressed(InputManager.Action.Ok))
            input.Attack = true;

         return input;
      }

      #endregion Updating
   }
}