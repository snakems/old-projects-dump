﻿using Microsoft.Xna.Framework;

namespace AurumGoldLib.Input
{
   public struct MobInput
   {
      #region Static Members

      private static MobInput empty = new MobInput();
      private static MobInput moveLeft = new MobInput(new Vector2(-1, 0));
      private static MobInput moveRight = new MobInput(new Vector2(1, 0));

      public static MobInput Empty { get { return empty; } }

      public static MobInput MoveLeft { get { return moveLeft; } }

      public static MobInput MoveRight { get { return moveRight; } }

      #endregion Static Members

      #region Properties

      public Vector2 MovementVector { get; set; }

      public bool Jump { get; set; }

      public bool Attack { get; set; }

      #endregion Properties

      #region Constructors

      public MobInput(Vector2 movementVector, bool jump = false, bool attack = false)
         : this()
      {
         MovementVector = movementVector;
         Jump = jump;
         Attack = attack;
      }

      #endregion Constructors
   }
}