﻿using Microsoft.Xna.Framework;

namespace AurumGoldLib.GameScreenManagement
{
   public class GameplayScreen : GameScreen
   {
      #region Constructors

      public GameplayScreen()
      {
      }

      #endregion Constructors

      #region Public Methods

      public override void LoadContent()
      {
         Singleton<SceneManager>.Instance.LoadScene();
         base.LoadContent();
      }

      public override void Update(GameTime gameTime, bool otherScreenHasFocus, bool coveredByOtherScreen)
      {
         base.Update(gameTime, otherScreenHasFocus, coveredByOtherScreen);
         if (IsActive)
            Singleton<SceneManager>.Instance.Update(gameTime);
      }

      public override void Draw(GameTime gameTime)
      {
         base.Draw(gameTime);
         var spriteBatch = ScreenManager.SpriteBatch;
         Singleton<SceneManager>.Instance.Draw(spriteBatch);
      }

      #endregion Public Methods
   }
}