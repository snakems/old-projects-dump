﻿namespace AurumGoldLib.Physics
{
   internal interface IPhysical
   {
      PhysicalObject GetPhysicsObject();
   }
}