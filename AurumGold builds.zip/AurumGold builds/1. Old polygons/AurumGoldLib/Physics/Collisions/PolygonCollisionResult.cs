﻿using Microsoft.Xna.Framework;

namespace AurumGoldLib.Physics.Collisions
{
   /// <summary>
   /// Structure that stores the results of the PolygonCollision function.
   /// </summary>
   internal struct PolygonCollisionResult
   {
      /// <summary>
      /// Are the polygons going to intersect forward in time?
      /// </summary>
      public bool WillIntersect { get; set; }

      /// <summary>
      /// Are the polygons currently intersecting.
      /// </summary>
      public bool Intersect { get; set; }

      /// <summary>
      /// The translation to apply to polygon A to push the polygons appart.
      /// </summary>
      public Vector2 MinimumTranslationVector { get; set; }

      /// <summary>
      /// Edge which was collided.
      /// </summary>
      public Line Edge { get; set; }
   }
}