﻿namespace AurumGoldLib.Physics
{
   internal delegate bool CollisionEventHandler(PhysicalObject first, PhysicalObject second);
}