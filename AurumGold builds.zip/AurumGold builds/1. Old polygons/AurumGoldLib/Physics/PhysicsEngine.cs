﻿using System;
using System.Collections.Generic;
using AurumGoldLib.Extensions;
using AurumGoldLib.Physics.Collisions;
using AurumGoldLib.World.Mobs;
using Microsoft.Xna.Framework;

namespace AurumGoldLib.Physics
{
   internal sealed class PhysicsEngine
   {
      #region Constants

      public readonly Vector2 MaxVelocity = new Vector2(700f);

      #endregion Constants

      #region Fields

      private List<IPhysical> trackingObjects = new List<IPhysical>();

      #endregion Fields

      #region Properties

      public Vector2 Gravity { get; set; }

      #endregion Properties

      #region Public Methods

      public void AddObject(IPhysical obj)
      {
         if (!trackingObjects.Contains(obj))
            trackingObjects.Add(obj);
      }

      public void RemoveObject(IPhysical obj)
      {
         if (trackingObjects.Contains(obj))
            trackingObjects.Remove(obj);
      }

      public void ResetEngine()
      {
         trackingObjects.Clear();

         Gravity = Vector2.Zero;
      }

      public void Update(GameTime gameTime)
      {
         var elapsed = (float)gameTime.ElapsedGameTime.TotalSeconds;

         foreach (var obj in trackingObjects)
         {
            if (!obj.GetPhysicsObject().Static)
               CalculateMovementAndCollisions(obj, elapsed);
         }
      }

      #endregion Public Methods

      #region Private Methods

      private void CalculateMovementAndCollisions(IPhysical obj, float elapsed)
      {
         var physical = obj.GetPhysicsObject();
         var velocity = physical.Velocity;
         velocity += physical.Acceleration * elapsed;

         var wasOnGround = physical.OnGround;
         if (physical.GravityApplied)
         {
            velocity += this.Gravity * elapsed;
            if (wasOnGround && velocity.Y > 0)
               velocity.Y += 100f; // used for smooth walking on the slopes
         }
         if (physical.OnGround)
            velocity.X *= (1.0f - physical.GroundFriction * elapsed);
         else
            velocity.X *= (1.0f - physical.AirFriction * elapsed);

         if (Math.Abs(velocity.X) < 5.0f) velocity.X = 0f;

         velocity = Vector2.Clamp(velocity, -this.MaxVelocity, this.MaxVelocity);

         physical.Acceleration = Vector2.Zero;
         physical.OnGround = false;
         physical.AtCeiling = false;
         physical.OffGroundTime += elapsed;

         var moveAmount = velocity * elapsed;
         physical.Velocity = velocity;
         ResolveCollisions(obj, trackingObjects, ref moveAmount);

         if (wasOnGround && physical.Velocity.Y == velocity.Y)
            physical.SetVelocityY(velocity.Y - 100f); // used for correct falling

         if (Math.Abs(moveAmount.X) < 0.001f && Math.Abs(moveAmount.Y) < 0.001f)
         {
            physical.OnGround = true;
            physical.OffGroundTime = 0.0f;
            physical.ResetDynamics();
         }
         else
         {
            physical.Move(moveAmount);
         }
      }

      private void ResolveCollisions(IPhysical objA, IEnumerable<IPhysical> objects, ref Vector2 moveAmount)
      {
         var physicalA = objA.GetPhysicsObject();
         bool loop; do
         {
            loop = false;
            foreach (var objB in objects)
            {
               if (objA == objB) continue;

               var physicalB = objB.GetPhysicsObject();
               var r = PolygonCollision.CheckCollision(physicalA.Body.Polygon, physicalB.Body.Polygon, moveAmount);

               if (r.WillIntersect)
               {
                  var shouldResolve = true;
                  shouldResolve &= physicalA.OnCollision(physicalB);
                  shouldResolve &= physicalB.OnCollision(physicalA);
                  if (!shouldResolve) continue;

                  var axis = r.Edge.Second - r.Edge.First;
                  axis.Normalize();

                  var translation = r.MinimumTranslationVector;
                  moveAmount += translation;
                  var projection = translation.Project(axis);
                  moveAmount += -projection;

                  var centerAbove = -r.Edge.PointRelativeToLine(physicalA.Body.Polygon.Center);
                  var angle = Math.Abs(r.Edge.Angle);

                  if (centerAbove > 0)
                  {
                     if (angle < MathHelper.PiOver4 && physicalA.Velocity.Y >= 0)
                     {
                        physicalA.OnGround = true;
                        physicalA.OffGroundTime = 0.0f;
                        physicalA.SetVelocityY(0);
                        if (projection != Vector2.Zero)
                        {
                           moveAmount += projection;
                           var move = axis * Math.Abs(translation.X);
                           var sign = Math.Sign(physicalA.Velocity.X);
                           move.X = sign * Math.Abs(move.X);
                           move.Y = Math.Sign(r.Edge.Angle) * sign * Math.Abs(move.Y);
                           moveAmount += move;
                        }
                     }
                     else
                     {
                        //if (projection != Vector2.Zero)
                        //{
                        //   var move = Vector2.UnitY * translation.Y;
                        //   moveAmount -= move.Project(axis);
                        //}
                     }
                  }
                  else
                  {
                     if (angle < Math.PI / 6 && physicalA.Velocity.Y <= 0)
                     {
                        physicalA.SetVelocityY(0);
                        physicalA.AtCeiling = true;
                     }
                  }
                  loop = true; break;
               }
            }
         } while (loop);
      }

      private bool HandleCollision(PhysicalObject entity, PhysicalObject other)
      {
         return entity.OnCollision(other);
      }

      #endregion Private Methods
   }
}