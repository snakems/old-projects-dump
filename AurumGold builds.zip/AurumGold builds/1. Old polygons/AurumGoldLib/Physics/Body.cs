﻿using Microsoft.Xna.Framework;

namespace AurumGoldLib.Physics
{
   internal class Body
   {
      #region Properties

      public Vector2[] Points { get { return Polygon.Points.ToArray(); } }

      public Rectangle BoundingRect
      {
         get { return Polygon.BoundingRect; }
      }

      public Polygon Polygon { get; set; }

      #endregion Properties

      #region Constructors and Factories

      private Body() { }

      public static Body CreateBody(Rectangle rect)
      {
         return new Body() { Polygon = new Polygon(rect) };
      }

      public static Body CreateBody(params Vector2[] points)
      {
         return new Body() { Polygon = new Polygon(points) };
      }

      #endregion Constructors and Factories

      #region Public Methods

      public void Offset(Vector2 offset)
      {
         Polygon.Offset(offset.X, offset.Y);
      }

      public void Offset(float x, float y)
      {
         Polygon.Offset(x, y);
      }

      #endregion Public Methods
   }
}