﻿using System.Collections.Generic;
using Microsoft.Xna.Framework;

namespace AurumGoldLib.Physics
{
   internal class Polygon
   {
      #region Fields

      private List<Vector2> points;
      private List<Vector2> edges;

      #endregion Fields

      #region Properties

      public List<Vector2> Edges
      {
         get { return edges; }
      }

      public List<Vector2> Points
      {
         get { return points; }
      }

      public Vector2 Center
      {
         get
         {
            float totalX = 0;
            float totalY = 0;
            for (int i = 0; i < points.Count; i++)
            {
               totalX += points[i].X;
               totalY += points[i].Y;
            }

            return new Vector2(totalX / (float)points.Count, totalY / (float)points.Count);
         }
      }

      public Rectangle BoundingRect
      {
         get
         {
            //var minX = (int)points.Min(v => v.X);
            //var maxX = (int)points.Max(v => v.X);
            //var minY = (int)points.Min(v => v.Y);
            //var maxY = (int)points.Max(v => v.Y);

            float minX = points[0].X, maxX = points[0].X,
                  minY = points[0].Y, maxY = points[0].Y;
            for (int i = 1; i < points.Count; ++i)
            {
               if (points[i].X < minX)
                  minX = points[i].X;
               else
                  if (points[i].X > maxX)
                     maxX = points[i].X;
               if (points[i].Y < minY)
                  minY = points[i].Y;
               else
                  if (points[i].Y > maxY)
                     maxY = points[i].Y;
            }

            return new Rectangle((int)minX, (int)minY, (int)(maxX - minX), (int)(maxY - minY));
         }
      }

      #endregion Properties

      #region Constructors

      public Polygon()
      {
         points = new List<Vector2>();
         edges = new List<Vector2>();
      }

      public Polygon(params Vector2[] _points)
      {
         points = new List<Vector2>(_points);
         edges = new List<Vector2>();
         BuildEdges();
      }

      public Polygon(Rectangle rect)
      {
         points = new List<Vector2>();
         edges = new List<Vector2>();

         points.Add(new Vector2(rect.Top, rect.Left));
         points.Add(new Vector2(rect.Top, rect.Right));
         points.Add(new Vector2(rect.Bottom, rect.Right));
         points.Add(new Vector2(rect.Bottom, rect.Left));
         BuildEdges();
      }

      #endregion Constructors

      #region Public Methods

      public void BuildEdges()
      {
         Vector2 p1;
         Vector2 p2;
         edges.Clear();
         for (int i = 0; i < points.Count; i++)
         {
            p1 = points[i];
            if (i + 1 >= points.Count)
               p2 = points[0];
            else
               p2 = points[i + 1];

            edges.Add(p2 - p1);
         }
      }

      public void AddPoint(float x, float y)
      {
         AddPoint(new Vector2(x, y));
      }

      public void AddPoint(Vector2 point)
      {
         if (!points.Contains(point))
            points.Add(point);
      }

      public void Offset(Vector2 v)
      {
         Offset(v.X, v.Y);
      }

      public void Offset(float x, float y)
      {
         for (int i = 0; i < points.Count; i++)
         {
            Vector2 p = points[i];
            points[i] = new Vector2(p.X + x, p.Y + y);
         }
      }

      public override string ToString()
      {
         string result = "";

         for (int i = 0; i < points.Count; i++)
         {
            if (result != "") result += " ";
            result += "{" + points[i].ToString() + "}";
         }

         return result;
      }

      #endregion Public Methods
   }
}