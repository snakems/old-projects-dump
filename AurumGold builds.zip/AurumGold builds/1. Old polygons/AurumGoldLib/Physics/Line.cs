﻿using System;
using Microsoft.Xna.Framework;

namespace AurumGoldLib.Physics
{
   internal struct Line
   {
      public Vector2 First { get; set; }

      public Vector2 Second { get; set; }

      public Line(Vector2 first, Vector2 second)
         : this()
      {
         First = first;
         Second = second;
      }

      /// <summary>
      /// Gets the line's angle from pi to -pi.
      /// </summary>
      public float Angle
      {
         get { return (float)Math.Atan((Second.Y - First.Y) / (Second.X - First.X)); }
      }

      /// <summary>
      /// Determines the point position relarive to the line
      /// </summary>
      /// <returns>1 if point is above, -1 if below, 0 if belongs to.</returns>
      public int PointRelativeToLine(Vector2 point)
      {
         if (First.Y == Second.Y)
            return Math.Sign(point.Y - First.Y);
         if (First.X == Second.X)
            return 0;
         return Math.Sign(point.Y - First.Y - (Second.Y - First.Y) * (point.X - First.X) / (Second.X - First.X));
      }
   }
}