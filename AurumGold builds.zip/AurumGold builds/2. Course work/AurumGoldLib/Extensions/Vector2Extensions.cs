﻿using System;
using Microsoft.Xna.Framework;

namespace AurumGoldLib.Extensions
{
   public static class Vector2Extensions
   {
      public static float DotProduct(this Vector2 self, Vector2 vector)
      {
         return self.X * vector.X + self.Y * vector.Y;
      }

      public static Vector2 Project(this Vector2 self, Vector2 axis)
      {
         if (axis == Vector2.Zero)
            return Vector2.Zero;
         return axis.DotProduct(self) / axis.LengthSquared() * axis;
      }

      public static float Angle(this Vector2 self, Vector2 vector)
      {
         if (self == Vector2.Zero || vector == Vector2.Zero)
            return 0f;
         return (float)Math.Acos(self.DotProduct(vector) / self.Length() / vector.Length());
      }

      public static Vector2 Parse(string value)
      {
         var p = value.Split(',');
         var x = float.Parse(p[0]);
         var y = float.Parse(p[1]);
         return new Vector2(x, y);
      }

      public static void SetX(this Vector2 self, float x)
      {
         self.X = x;
      }

      public static void SetY(this Vector2 self, float y)
      {
         self.Y = y;
      }

      public static void AddX(this Vector2 self, float dx)
      {
         self.X += dx;
      }

      public static void AddY(this Vector2 self, float dy)
      {
         self.Y += dy;
      }
   }
}