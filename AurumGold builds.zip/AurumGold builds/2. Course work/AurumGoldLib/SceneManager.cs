﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace AurumGoldLib
{
   internal class SceneManager : Singleton<SceneManager>
   {
      #region Properties

      public Scene CurrentScene { get; private set; }

      #endregion Properties

      #region Public Methods

      public void LoadScene()
      {
         CurrentScene = new Scene();
      }

      public void Update(GameTime gameTime)
      {
         CurrentScene.Update(gameTime);
      }

      public void Draw(SpriteBatch spriteBatch)
      {
         CurrentScene.Draw(spriteBatch);
      }

      #endregion Public Methods
   }
}