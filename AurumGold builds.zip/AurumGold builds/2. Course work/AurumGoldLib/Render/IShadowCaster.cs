﻿using Microsoft.Xna.Framework.Graphics;

namespace AurumGoldLib.Render
{
   internal interface IShadowCaster
   {
      void DrawShadow(SpriteBatch spriteBatch);
   }
}