﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace AurumGoldLib.Render
{
   public class RenderManager : Singleton<RenderManager>
   {
      #region Fields

      protected GraphicsDevice graphicsDevice;
      protected int backBufferWidth;
      protected int backBufferHeight;
      protected Rectangle backBufferRTRectangle;

      #endregion Fields

      #region Properties

      public int BackBufferWidth
      {
         get { return backBufferWidth; }
         protected set { backBufferWidth = value; }
      }

      public int BackBufferHeight
      {
         get { return backBufferHeight; }
         protected set { backBufferHeight = value; }
      }

      public RenderTarget2D BackBufferRT { get; protected set; }

      public Matrix ScaleMatrix { get; protected set; }

      public Vector2 ScaleVector { get; protected set; }

      public GraphicsDevice GraphicsDevice
      {
         get { return graphicsDevice; }
         set
         {
            graphicsDevice = value;
            BackBufferWidth = graphicsDevice.PresentationParameters.BackBufferWidth;
            BackBufferHeight = graphicsDevice.PresentationParameters.BackBufferHeight;
            UpdateScales();
            BackBufferRT = new RenderTarget2D(graphicsDevice, 1280, 720, false, SurfaceFormat.Color, DepthFormat.Depth24Stencil8);
         }
      }

      public GraphicsDeviceManager GraphicsDeviceManager { get; set; }

      public Rectangle BackBufferRTRectangle
      {
         get { return backBufferRTRectangle; }
         protected set { backBufferRTRectangle = value; }
      }

      #endregion Properties

      #region Protected Methods

      protected Rectangle GetBackBufferRTRectangle()
      {
         Vector2 vector = FixAspectRatio(1280, 720, new Vector2(backBufferWidth, backBufferHeight));
         int x = 0;
         int y = 0;
         if ((int)vector.X == backBufferWidth)
         {
            y = backBufferHeight / 2 - (int)vector.Y / 2;
         }
         else
         {
            x = backBufferWidth / 2 - (int)vector.X / 2;
         }
         return new Rectangle(x, y, (int)vector.X, (int)vector.Y);
      }

      protected void UpdateScales()
      {
         BackBufferRTRectangle = GetBackBufferRTRectangle();
         ScaleMatrix = Matrix.CreateScale(BackBufferRTRectangle.Width / 1280f, BackBufferRTRectangle.Height / 720f, 1f);
         ScaleVector = new Vector2(BackBufferRTRectangle.Width / 1280f, BackBufferRTRectangle.Height / 720f);
      }

      protected Vector2 FixAspectRatio(int imageX, int imageY, Vector2 paneDimensions)
      {
         float num1 = (float)imageX / (float)imageY;
         float num2 = paneDimensions.X / paneDimensions.Y;
         if (num1 > num2)
         {
            paneDimensions.Y = paneDimensions.X / (float)imageX * (float)imageY;
         }
         else
         {
            paneDimensions.X = paneDimensions.Y / (float)imageY * (float)imageX;
         }
         return paneDimensions;
      }

      #endregion Protected Methods
   }
}