﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace AurumGoldLib.Render
{
   public class AnimatedSprite
   {
      private int frameCount;
      private Texture2D texture;
      private float timePerFrame;
      private int frame;
      private float totalElapsed;
      private bool paused;

      private Vector2 shadowOffset = new Vector2(-3f, 3f);

      public float Rotation { get; set; }

      public Vector2 Origin { get; set; }

      public Vector2 Scale { get; set; }

      public bool IsPaused
      {
         get { return paused; }
      }

      public AnimatedSprite(float scale, Texture2D texture, int frameCount, int framesPerSec)
         : this(new Vector2(scale), texture, frameCount, framesPerSec)
      {
      }

      public AnimatedSprite(Vector2 scale, Texture2D texture, int frameCount, int framesPerSec)
      {
         this.Origin = new Vector2(texture.Width / frameCount / 2f, texture.Height / 2f);
         this.Scale = scale;
         this.texture = texture;
         this.frameCount = frameCount;
         this.timePerFrame = 1.0f / framesPerSec;
         this.frame = 0;
         this.totalElapsed = 0;
         this.paused = false;
      }

      public void UpdateFrame(float elapsed)
      {
         if (paused)
            return;
         totalElapsed += elapsed;
         if (totalElapsed > timePerFrame)
         {
            frame++;
            frame = frame % frameCount;
            totalElapsed -= timePerFrame;
         }
      }

      public void Draw(SpriteBatch batch, Vector2 position, Color color, bool flip = false)
      {
         int FrameWidth = texture.Width / frameCount;
         Rectangle sourcerect = new Rectangle(FrameWidth * frame, 0,
             FrameWidth, texture.Height);
         var effect = flip ? SpriteEffects.FlipHorizontally : SpriteEffects.None;
         batch.Draw(texture, position, sourcerect, color, Rotation, Origin, Scale, effect, 0f);
      }

      // TODO: add transparent
      public void DrawShadow(SpriteBatch spriteBatch, Vector2 position, bool flip = false)
      {
         Draw(spriteBatch, position + shadowOffset, Color.Black * 0.6f, flip);
      }

      public void Reset()
      {
         frame = 0;
         totalElapsed = 0f;
      }

      public void Stop()
      {
         Pause();
         Reset();
      }

      public void Play()
      {
         paused = false;
      }

      public void Pause()
      {
         paused = true;
      }
   }
}