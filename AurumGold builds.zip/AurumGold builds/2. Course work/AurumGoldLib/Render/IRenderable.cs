﻿using Microsoft.Xna.Framework.Graphics;

namespace AurumGoldLib.Render
{
   internal interface IRenderable
   {
      void Draw(SpriteBatch spriteBatch);

      int DrawOrder { get; }
   }
}