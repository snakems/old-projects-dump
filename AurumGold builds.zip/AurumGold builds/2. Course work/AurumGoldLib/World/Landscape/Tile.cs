﻿using AurumGoldLib.Physics;
using AurumGoldLib.Render;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace AurumGoldLib.World.Landscape
{
   internal abstract class Tile : Entity, IPhysical, IRenderable
   {
      #region Fields

      protected Physical physical;

      #endregion Fields

      #region Properties

      public bool Passable { get; set; }

      public int DrawOrder { get; protected set; }

      #endregion Properties

      #region Constructors

      public Tile(Rectangle rect)
      {
         physical = new Physical(new AABB(rect), this);
         physical.Static = true;

         DrawOrder = 4;
      }

      #endregion Constructors

      #region Public Methods

      public Physical GetPhysical()
      {
         return physical;
      }

      public abstract void Draw(SpriteBatch spriteBatch);

      #endregion Public Methods
   }
}