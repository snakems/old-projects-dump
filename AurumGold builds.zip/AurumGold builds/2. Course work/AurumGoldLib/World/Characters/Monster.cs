﻿using AurumGoldLib.AI;
using AurumGoldLib.Render;
using Microsoft.Xna.Framework;

namespace AurumGoldLib.World.Characters
{
   internal class Monster : Mob
   {
      #region Fields

      protected AIController controller;
      protected float jumpVelocity = -400;

      #endregion Fields

      #region Properties

      public float Speed { get; set; }

      #endregion Properties

      #region Constructors

      public Monster()
         : base(Vector2.Zero, new Vector2(24, 27))
      {
         var runTexture = ContentHelper.GetTexture("Characters\\Wheelie_run_right");
         sprites.Add("run", new AnimatedSprite(1f, runTexture, 4, 9));

         HitPoints = 3;

         Speed = 400f;
         controller = new AIController(new IdleBehavior());

         currentSprite = sprites["run"];
      }

      #endregion Constructors

      #region Public Methods

      public void SetPatrol(float from, float to)
      {
         controller.Behavior = new PatrolBehaviour(this)
         {
            FromX = from,
            ToX = to,
         };
      }

      public void ResetPatrol()
      {
         controller.Behavior = new WanderBehavior()
         {
            MinWanderTime = 0.75f,
            MaxWanderTime = 2f,
            MinDelayTime = 0.25f,
            MaxDelayTime = 1f
         };
      }

      public override void Update(GameTime gameTime)
      {
         var elapsed = (float)gameTime.ElapsedGameTime.TotalSeconds;
         UpdateAI(elapsed);
         base.Update(gameTime);
      }

      public void UpdateAI(float elapsed)
      {
         if (controller == null || Dead || stunned)
            return;

         controller.Update(elapsed);
         physical.Acceleration += controller.MobInput.MovementVector * this.Speed;
         if (controller.MobInput.Jump)
            if (jumpVelocity != 0)
               physical.SetVelocityY(jumpVelocity);
         facingLeft = controller.MobInput.MovementVector.X < 0;
      }

      #endregion Public Methods
   }
}