﻿using AurumGoldLib.Render;
using Microsoft.Xna.Framework;

namespace AurumGoldLib.World.Props
{
   internal class BonusLife : Collectible
   {
      #region Constructors

      public BonusLife(Vector2 position)
         : base(position, new Vector2(16, 16))
      {
         sprite = new AnimatedSprite(16f / 50, ContentHelper.GetTexture("Misc\\Heart"), 1, 1);
      }

      #endregion Constructors

      #region Public Methods

      public override void Pickup(Player player)
      {
         if (player.GainHealth(1))
            SceneManager.Instance.CurrentScene.RemoveFromScene(this);
      }

      #endregion Public Methods
   }
}