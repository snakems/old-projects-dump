﻿using AurumGoldLib.Physics;
using Microsoft.Xna.Framework;

namespace AurumGoldLib.World.Props
{
   internal abstract class Collectible : Prop
   {
      #region Fields

      #endregion Fields

      #region Properties

      #endregion Properties

      #region Constructors

      public Collectible(Vector2 position, Vector2 size)
         : base(position, size)
      {
      }

      #endregion Constructors

      #region Public Methods

      protected override bool OnCollision(Physical first, Physical second)
      {
         if (second.Entity is Player)
         {
            Pickup((Player)second.Entity);
         }
         return false;
      }

      public abstract void Pickup(Player player);

      #endregion Public Methods
   }
}