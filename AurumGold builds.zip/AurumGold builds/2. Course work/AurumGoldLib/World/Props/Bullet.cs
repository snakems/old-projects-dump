﻿using AurumGoldLib.Physics;
using AurumGoldLib.Render;
using AurumGoldLib.World.Landscape;
using Microsoft.Xna.Framework;

namespace AurumGoldLib.World.Props
{
   internal class Bullet : Prop
   {
      #region Fields

      private static float BULLET_ALIVE_TIME = 1f;

      private bool alive;
      private float aliveTimer;

      #endregion Fields

      #region Properties

      public Entity Owner { get; private set; }

      #endregion Properties

      #region Constructor

      public Bullet(Entity owner, Vector2 position, Vector2 velocity)
         : base(position, new Vector2(20, 20))
      {
         Owner = owner;
         alive = true;

         physical.Static = false;
         physical.GravityApplied = false;
         physical.Velocity = velocity;

         facingLeft = velocity.X < 0;

         var texture = ContentHelper.GetTexture("Misc\\Smoke");
         sprite = new AnimatedSprite(physical.Size / 16f, texture, 8, 8);
      }

      #endregion Constructor

      #region Public Methods

      protected override bool OnCollision(Physical first, Physical second)
      {
         if (!alive) return false;

         if (second.Entity is Mob)
         {
            var mob = (Mob)second.Entity;
            var direction = second.Position - first.Position;
            direction.Y = -direction.Y; // TODO:
            direction.Normalize();
            mob.TakeDamage(1, direction);
            Die();
         }
         if (second.Entity is Tile)
         {
            var tile = (Tile)second.Entity;
            if (!tile.Passable)
               Die();
         }
         return false;
      }

      public override void Update(GameTime gameTime)
      {
         base.Update(gameTime);
         var elapsed = (float)gameTime.ElapsedGameTime.TotalSeconds;
         if (alive)
         {
            aliveTimer += elapsed;
            if (aliveTimer > BULLET_ALIVE_TIME)
            {
               Die();
            }
         }
      }

      private void Die()
      {
         alive = false;
         SceneManager.Instance.CurrentScene.RemoveFromScene(this);
      }

      #endregion Public Methods
   }
}