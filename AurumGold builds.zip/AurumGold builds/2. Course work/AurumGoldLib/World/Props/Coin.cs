﻿using AurumGoldLib.Render;
using Microsoft.Xna.Framework;

namespace AurumGoldLib.World.Props
{
   internal class Coin : Collectible
   {
      #region Properties

      public CoinType Type { get; private set; }

      #endregion Properties

      #region Constructors

      public Coin(CoinType type, Vector2 position)
         : base(position, new Vector2(16, 16))
      {
         Type = type;
         switch (type)
         {
            case CoinType.Golden:
               sprite = new AnimatedSprite(1f, ContentHelper.GetTexture("Misc\\Spinning_coin_gold"), 8, 16);
               break;
            case CoinType.Silver:
               sprite = new AnimatedSprite(1f, ContentHelper.GetTexture("Misc\\Spinning_coin_silver"), 8, 16);
               break;
         }
      }

      #endregion Constructors

      #region Public Methods

      public override void Pickup(Player player)
      {
         switch (Type)
         {
            case CoinType.Golden:
               player.Gold += 200;
               break;
            case CoinType.Silver:
               player.Gold += 100;
               break;
         }
         SceneManager.Instance.CurrentScene.RemoveFromScene(this);
      }

      #endregion Public Methods
   }
}