﻿using System.Collections.Generic;
using AurumGoldLib.Physics;
using AurumGoldLib.Render;
using C3.XNA;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace AurumGoldLib.World
{
   internal abstract class Mob : Entity, IPhysical, IRenderable, IShadowCaster
   {
      #region Fields

      protected Physical physical;

      protected Dictionary<string, AnimatedSprite> sprites
        = new Dictionary<string, AnimatedSprite>();

      protected AnimatedSprite currentSprite;
      protected bool facingLeft;

      protected bool stunned;

      #endregion Fields

      #region Properties

      public bool Dead { get; protected set; }

      public int HitPoints { get; protected set; }

      public int DrawOrder { get; protected set; }

      #endregion Properties

      #region Constructors

      public Mob(Vector2 position, Vector2 size)
      {
         physical = new Physical(this);
         physical.Position = position;
         physical.Size = size;

         physical.GravityApplied = true;
         physical.GroundFriction = 6f;
         physical.AirFriction = 4.2f;

         physical.Collided += new CollisionEventHandler(OnCollision);

         DrawOrder = 3;
      }

      #endregion Constructors

      #region Public Methods

      public Physical GetPhysical()
      {
         return physical;
      }

      /// <summary>
      /// Take some damage.
      /// </summary>
      /// <returns>True if damage was taken.</returns>
      public virtual bool TakeDamage(int amount, Vector2 direction)
      {
         if (stunned) return false;

         HitPoints -= amount;
         physical.Velocity += direction * 500f;
         stunned = true;
         SceneManager.Instance.CurrentScene.Timers.Create(0.5f, () => stunned = false);
         if (HitPoints < 0)
         {
            SceneManager.Instance.CurrentScene.RemoveFromScene(this);
            Dead = true;
         }
         return true;
      }

      /// <summary>
      /// Gain some hit points.
      /// </summary>
      /// <returns>True if health was gained.</returns>
      public virtual bool GainHealth(int amount)
      {
         HitPoints += amount;
         return true;
      }

      public override void Update(GameTime gameTime)
      {
         var elapsed = (float)gameTime.ElapsedGameTime.TotalSeconds;
         currentSprite.UpdateFrame(elapsed);
      }

      public virtual void Draw(SpriteBatch spriteBatch)
      {
         currentSprite.Draw(spriteBatch, physical.AABB.Center, Color.White, facingLeft);
      }

      public virtual void DrawShadow(SpriteBatch spriteBatch)
      {
         currentSprite.DrawShadow(spriteBatch, physical.AABB.Center, facingLeft);
      }

      #endregion Public Methods

      #region Protected Methods

      protected virtual bool OnCollision(Physical first, Physical second)
      {
         return second.Static;
      }

      protected void DrawBoundingRect(SpriteBatch spriteBatch, Color color)
      {
         var drawRect = physical.AABB.Rect;
         spriteBatch.DrawRectangle(drawRect, Color.DarkBlue);
      }

      protected void DrawBoundingRect(SpriteBatch spriteBatch)
      {
         DrawBoundingRect(spriteBatch, Color.DarkBlue);
      }

      #endregion Protected Methods
   }
}