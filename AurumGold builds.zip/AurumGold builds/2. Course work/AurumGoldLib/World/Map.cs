﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace AurumGoldLib.World
{
   internal class Map
   {
      #region Fields

      private Texture2D parallax;

      #endregion Fields

      #region Constructors

      public Map()
      {
         parallax = ContentHelper.GetTexture("Landscape\\parallax");
      }

      #endregion Constructors

      #region Public Methods

      public void DrawBackgroundLayer(SpriteBatch spriteBatch)
      {
         spriteBatch.Draw(parallax, Vector2.Zero, null, Color.White);
      }

      public void DrawMidgroundLayer(SpriteBatch spriteBatch)
      {
      }

      public void DrawForegroundLayer(SpriteBatch spriteBatch)
      {
      }

      #endregion Public Methods
   }
}