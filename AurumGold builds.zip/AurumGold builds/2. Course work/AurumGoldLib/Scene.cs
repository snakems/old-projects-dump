﻿using System;
using System.Collections.Generic;
using System.Linq;
using AurumGoldLib.Core;
using AurumGoldLib.GameScreenManagement;
using AurumGoldLib.Physics;
using AurumGoldLib.Render;
using AurumGoldLib.World;
using AurumGoldLib.World.Characters;
using AurumGoldLib.World.Landscape;
using AurumGoldLib.World.Props;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace AurumGoldLib
{
   internal class Scene
   {
      #region Fields

      private PhysicsEngine physicsEngine;

      private Map map = new Map();
      private List<Entity> entities = new List<Entity>();

      private List<Collectible> props = new List<Collectible>();
      private List<Monster> monsters = new List<Monster>();

      private List<Entity> entitesToAdd = new List<Entity>();
      private List<Entity> entitesToRemove = new List<Entity>();

      private Player player;

      private BasicEffect effect;

      #endregion Fields

      #region Properties

      public Camera Camera { get; private set; }

      public TimerCollection Timers { get; private set; }

      #endregion Properties

      #region Constructors

      public Scene()
      {
         physicsEngine = new PhysicsEngine(34 * 35, 15 * 35);
         physicsEngine.Gravity = new Vector2(0, 1400f);
         Timers = new TimerCollection();

         LoadLevel();
         player.Inventory.AddBonus(new Bonus(BonusType.DoubleJump));

         Camera = new Camera();
         Camera.Target = player;
         Camera.SnapToTarget();

         effect = new BasicEffect(RenderManager.Instance.GraphicsDevice);
         effect.World = Matrix.Identity;
         effect.Projection = Camera.ProjectionMatrix;
         effect.TextureEnabled = true;
         effect.VertexColorEnabled = true;
      }

      #endregion Constructors

      #region Public Methods

      public void AddToScene(Entity entity)
      {
         entitesToAdd.Add(entity);
      }

      public void RemoveFromScene(Entity entity)
      {
         entitesToRemove.Add(entity);
      }

      public void Update(GameTime gameTime)
      {
         var elapsed = (float)gameTime.ElapsedGameTime.TotalSeconds;

         Timers.Update(gameTime);

         UpdateAddedEntites();
         foreach (var entity in entities)
            entity.Update(gameTime);
         physicsEngine.Update(gameTime);
         UpdateRemovedEntities();
         //player.Update(gameTime);

         Camera.Update(elapsed);
         effect.View = Camera.ViewMatrix;

         if (player.HitPoints < 0)
            ScreenManager.Instance.AddScreen(new GameOverPopup());
      }

      public void Draw(SpriteBatch spriteBatch)
      {
         spriteBatch.Begin();
         map.DrawBackgroundLayer(spriteBatch);
         spriteBatch.End();

         spriteBatch.Begin(SpriteSortMode.Deferred, null, SamplerState.PointClamp, null, null, effect);
         var query = physicsEngine.QueryAABB(Camera.BoundsInMeters);

         foreach (var current in query.Select(p => p.Entity as IShadowCaster)
                                      .Where(p => p != null))
         {
            current.DrawShadow(spriteBatch);
         }
         foreach (var current in query.Select(p => p.Entity as IRenderable)
                                      .Where(p => p != null)
                                      .OrderBy(p => p.DrawOrder))
         {
            current.Draw(spriteBatch);
         }
         spriteBatch.End();

         spriteBatch.Begin();
         map.DrawMidgroundLayer(spriteBatch);
         map.DrawForegroundLayer(spriteBatch);
         spriteBatch.End();

         // Drawing HUD
         DrawHUD(spriteBatch);
      }

      #endregion Public Methods

      #region Private Methods

      private void UpdateAddedEntites()
      {
         foreach (var current in entitesToAdd)
         {
            if (!entities.Contains(current))
               entities.Add(current);
            if (current is IPhysical)
               physicsEngine.Add((IPhysical)current);
         }
         entitesToAdd.Clear();
      }

      private void UpdateRemovedEntities()
      {
         foreach (var current in entitesToRemove)
         {
            entities.Remove(current);
            if (current is IPhysical)
               physicsEngine.Remove((IPhysical)current);
         }
         entitesToRemove.Clear();
      }

      private void DrawHUD(SpriteBatch spriteBatch)
      {
         var heart = ContentHelper.GetTexture("Misc\\Heart");
         var font = ContentHelper.GetFont("GuiFont");
         spriteBatch.Begin();
         for (int i = 0; i < player.HitPoints; ++i)
         {
            spriteBatch.Draw(heart, new Rectangle(10 + i * heart.Width, 10, heart.Width, heart.Height), Color.White);
         }
         var text = String.Format("Total gold: {0}", player.Gold);
         spriteBatch.DrawString(font, text, new Vector2(10, heart.Height + 15), Color.White);
         spriteBatch.End();
      }

      private void LoadLevel()
      {
         var lines = System.IO.File.ReadAllLines(@"Content\Levels\Level1\Ground.txt");
         Vector2 playerPos = Vector2.Zero;
         for (int i = 0; i < lines.Length; ++i)
         {
            for (int j = 0; j < lines[i].Length; ++j)
            {
               var ch = lines[i][j];
               if (char.ToUpper(ch) == 'W')
               {
                  var block = new GroundTile(new Rectangle(j * 35, i * 35, 35, 35));
                  if (i != 0 && char.ToUpper(lines[i - 1][j]) != 'W') block.TopEmpty = true;
                  if (i != lines.Length - 1 && char.ToUpper(lines[i + 1][j]) != 'W') block.BottomEmpty = true;
                  if (j != 0 && char.ToUpper(lines[i][j - 1]) != 'W') block.LeftEmpty = true;
                  if (j != lines[i].Length - 1 && char.ToUpper(lines[i][j + 1]) != 'W') block.RightEmpty = true;
                  block.Passable = ch == 'w';
                  AddToScene(block);
                  continue;
               }
               if (ch == 'S')
               {
                  var spike = new Spike(new Rectangle(j * 35, i * 35 + 10, 35, 25));
                  AddToScene(spike);
               }
               if (ch == 'C')
               {
                  var coin = new Coin(CoinType.Golden, new Vector2(j * 35 + 17, i * 35 + 17));
                  AddToScene(coin);
               }
               if (ch == 'I')
               {
                  var bonus = new BonusShield(new Vector2(j * 35 + 17, i * 35 + 17));
                  AddToScene(bonus);
               }
               if (ch == 'F')
               {
                  var bonus = new BonusFireCloak(new Vector2(j * 35 + 17, i * 35 + 17));
                  AddToScene(bonus);
               }
               if (ch == 'L')
               {
                  var bonus = new BonusLife(new Vector2(j * 35 + 17, i * 35 + 17));
                  AddToScene(bonus);
               }
               if (ch == 'M')
               {
                  var monster = new Monster();
                  monster.GetPhysical().Position = new Vector2(j * 35 + 17, i * 35 + 17);
                  monster.ResetPatrol();
                  AddToScene(monster);
               }
               if (ch == 'P')
               {
                  playerPos = new Vector2(j * 35 + 17, i * 35 + 17);
               }
            }
         }
         player = new Player();
         player.GetPhysical().Position = playerPos;
         AddToScene(player);
         //physicsEngine.Add(player);
      }

      #endregion Private Methods
   }
}