﻿using System;
using Microsoft.Xna.Framework;

namespace AurumGoldLib.GameScreenManagement
{
   public class GameplayScreen : GameScreen
   {
      #region Constructors

      public GameplayScreen()
      {
      }

      #endregion Constructors

      #region Public Methods

      public override void LoadContent()
      {
         base.LoadContent();
         SceneManager.Instance.LoadScene();
         SceneManager.Instance.Update(new GameTime(TimeSpan.FromSeconds(0), TimeSpan.FromSeconds(0)));
      }

      public override void HandleInput()
      {
         if (Input.InputManager.IsKeyTriggered(Microsoft.Xna.Framework.Input.Keys.Escape))
         {
            ExitScreen();
            ScreenManager.Game.Exit();
         }
      }

      public override void Update(GameTime gameTime, bool otherScreenHasFocus, bool coveredByOtherScreen)
      {
         base.Update(gameTime, otherScreenHasFocus, coveredByOtherScreen);
         if (IsActive)
         {
            SceneManager.Instance.Update(gameTime);
         }
      }

      public override void Draw(GameTime gameTime)
      {
         base.Draw(gameTime);
         var spriteBatch = ScreenManager.SpriteBatch;
         SceneManager.Instance.Draw(spriteBatch);
      }

      #endregion Public Methods
   }
}