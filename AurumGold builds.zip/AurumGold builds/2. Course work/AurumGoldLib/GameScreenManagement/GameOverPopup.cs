﻿using System;
using AurumGoldLib.Input;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace AurumGoldLib.GameScreenManagement
{
   public class GameOverPopup : GameScreen
   {
      #region Fields

      private readonly string upperText =
         @"You're dead! Press Okay to exit game.";

      private Texture2D fadeScreen;
      private Texture2D background;
      private SpriteFont font;

      private Rectangle fadeDestination;
      private Vector2 backgroundPosition;
      private Vector2 upperTextPosition;

      #endregion Fields

      #region Constructors

      public GameOverPopup()
      {
         IsPopup = true;

         TransitionOnTime = TimeSpan.FromSeconds(0.2);
         TransitionOffTime = TimeSpan.FromSeconds(0.2);
      }

      #endregion Constructors

      #region Public Methods

      public override void LoadContent()
      {
         base.LoadContent();
         fadeScreen = ContentHelper.GetTexture("Popup\\FadeScreen");
         background = ContentHelper.GetTexture("Popup\\Background");
         font = ContentHelper.GetFont("GuiFont");

         Viewport viewport = ScreenManager.GraphicsDevice.Viewport;
         fadeDestination = new Rectangle(viewport.X, viewport.Y, viewport.Width, viewport.Height);
         backgroundPosition = new Vector2((viewport.Width - background.Width) / 2, (viewport.Height - background.Height) / 2);

         upperTextPosition.X = backgroundPosition.X + (int)((background.Width - font.MeasureString(upperText).X) / 2);
         upperTextPosition.Y = backgroundPosition.Y + 45;
      }

      public override void HandleInput()
      {
         if (InputManager.IsActionTriggered(InputManager.Action.Ok))
         {
            ExitScreen();
            ScreenManager.Game.Exit();
         }
      }

      public override void Update(GameTime gameTime, bool otherScreenHasFocus, bool coveredByOtherScreen)
      {
         base.Update(gameTime, otherScreenHasFocus, coveredByOtherScreen);
      }

      public override void Draw(GameTime gameTime)
      {
         base.Draw(gameTime);
         var spriteBatch = ScreenManager.SpriteBatch;

         spriteBatch.Begin();

         //spriteBatch.Draw(fadeScreen, fadeDestination, Color.White);
         spriteBatch.Draw(background, backgroundPosition, Color.White);
         spriteBatch.DrawString(font, upperText, upperTextPosition, Color.White);

         spriteBatch.End();
      }

      #endregion Public Methods
   }
}