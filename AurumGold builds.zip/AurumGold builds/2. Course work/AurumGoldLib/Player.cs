﻿using System;
using AurumGoldLib.Extensions;
using AurumGoldLib.Input;
using AurumGoldLib.Physics;
using AurumGoldLib.Render;
using AurumGoldLib.World;
using AurumGoldLib.World.Characters;
using AurumGoldLib.World.Landscape;
using AurumGoldLib.World.Props;
using C3.XNA;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace AurumGoldLib
{
   internal class Player : Mob
   {
      #region Constants

      private static float PLAYER_INPUT_SCALE_GROUND = 1000f;
      private static float PLAYER_INPUT_SCALE_AIR = 750f;

      private static float MAX_JUMP_TIME = 0.61f;
      private static float JUMP_VELOCITY = -500f;
      private static float JUMP_CONTROL_POWER = 0.85f;
      private static float OFF_LEDGE_JUMP_TIME = 0.125f;

      private static float DEFAULT_STUNNED_TIME = 2f;

      private static float SHOOT_COOLDOWN = 0.3f;

      #endregion Constants

      #region Fields

      private bool nictating;
      private float nictateRate = 1.0f / 10;

      private MobInput previousInput;

      private bool waitingForJumpRelease;
      private bool waitingForAttackRelease;

      private bool hasJumped;
      private bool hasDoubleJumped;

      private float jumpTime;

      private bool canShoot;

      #endregion Fields

      #region Properties

      public Inventory Inventory { get; private set; }

      public int Gold { get; set; }

      #endregion Properties

      #region Constructor

      public Player()
         : base(Vector2.Zero, new Vector2(30, 45))
      {
         this.Inventory = new Inventory();
         this.HitPoints = 3;

         this.canShoot = true;

         var runTexture = ContentHelper.GetTexture("Player\\run_right");
         sprites.Add("run", new AnimatedSprite(0.5f, runTexture, 4, 10));
         var blinkTexture = ContentHelper.GetTexture("Player\\idle_right");
         sprites.Add("idle", new AnimatedSprite(0.5f, blinkTexture, 2, 2));
         var jumpTexture = ContentHelper.GetTexture("Player\\jump_right");
         sprites.Add("jump", new AnimatedSprite(0.5f, jumpTexture, 1, 1));

         this.currentSprite = sprites["idle"];
      }

      #endregion Constructor

      #region Public Methods

      public override void Update(GameTime gameTime)
      {
         var elapsed = (float)gameTime.ElapsedGameTime.TotalSeconds;

         Inventory.Update(gameTime);

         var previousSprite = currentSprite;
         currentSprite = sprites["idle"];

         var playerInput = InputManager.GatherPlayerInput();

         if (playerInput.MovementVector != Vector2.Zero)
         {
            currentSprite = sprites["run"];
            facingLeft = playerInput.MovementVector.X < 0;
         }

         if (playerInput.Attack && !waitingForAttackRelease)
         {
            if (!previousInput.Attack && !waitingForAttackRelease)
               waitingForAttackRelease = true;
            PerformAttack();
         }

         if (waitingForAttackRelease)
            waitingForAttackRelease = playerInput.Attack;

         if (physical.OnGround)
            physical.Acceleration += playerInput.MovementVector * PLAYER_INPUT_SCALE_GROUND;
         else
            physical.Acceleration += playerInput.MovementVector * PLAYER_INPUT_SCALE_AIR;

         if (waitingForJumpRelease)
            waitingForJumpRelease = playerInput.Jump;
         if (physical.OnGround)
         {
            hasJumped = false;
            hasDoubleJumped = false;
         }
         if (!waitingForJumpRelease && playerInput.Jump && !physical.AtCeiling)
         {
            if ((CanJump() || CanDoubleJump()) && !previousInput.Jump || jumpTime > 0.0f)
            {
               if (jumpTime == 0.0f)
               {
                  if (hasJumped || !CanJump())
                     hasDoubleJumped = true;
                  hasJumped = true;
               }
               jumpTime += elapsed;
            }
            if (jumpTime > 0.0 && jumpTime <= Player.MAX_JUMP_TIME)
            {
               var v = JUMP_VELOCITY * (1f - (float)Math.Pow(jumpTime / MAX_JUMP_TIME, JUMP_CONTROL_POWER));
               physical.SetVelocityY(v);
            }
            else
            {
               jumpTime = 0.0f;
            }
         }
         else
         {
            jumpTime = 0.0f;
         }
         previousInput = playerInput;

         if (!physical.OnGround) currentSprite = sprites["jump"];
         if (currentSprite != previousSprite)
            currentSprite.Reset();

         currentSprite.UpdateFrame(elapsed);
      }

      public override void Draw(SpriteBatch spriteBatch)
      {
         //DrawBoundingRect(spriteBatch);

         var drawRect = physical.AABB.Rect;
         var color = nictating ? new Color(128, 128, 128, 128) : Color.White;
         currentSprite.Draw(spriteBatch, physical.AABB.Center, color, facingLeft);

         if (Inventory.Contains(BonusType.Shield))
         {
            var v = new Vector2(drawRect.Center.X, drawRect.Center.Y);
            spriteBatch.DrawCircle(v, (drawRect.Width + drawRect.Height) / 4, 40, Color.Green);
         }
         if (Inventory.Contains(BonusType.FireCloak))
         {
            var v = new Vector2(drawRect.Center.X, drawRect.Center.Y);
            spriteBatch.DrawCircle(v, (drawRect.Width + drawRect.Height) / 3, 40, Color.OrangeRed);
         }
      }

      //TODO: insert some checks here
      public override bool TakeDamage(int amount, Vector2 direction)
      {
         if (!Inventory.Contains(BonusType.Shield) && !stunned)
         {
            HitPoints -= amount;
            return true;
         }
         return false;
      }

      #endregion Public Methods

      #region Protected Methods

      protected override bool OnCollision(Physical first, Physical second)
      {
         var target = second.Entity;
         if (target is Spike)
         {
            HitSpike((Spike)target);
         }
         if (target is Monster)
         {
            HitMonster((Monster)target);
            return false;
         }
         return true;
      }

      #endregion Protected Methods

      #region Private Methods

      private void PerformAttack()
      {
         if (CanShoot())
         {
            canShoot = false;
            var velocity = new Vector2(400f, 0f);
            var mul = (facingLeft ? -1 : 1);
            var position = physical.Position + (physical.AABB.HalfWidth + new Vector2(8, 0)) * mul;
            var bullet = new Bullet(this, position, velocity * mul);
            SceneManager.Instance.CurrentScene.AddToScene(bullet);
            SceneManager.Instance.CurrentScene.Timers.Create(SHOOT_COOLDOWN, () => canShoot = true);
         }
      }

      private bool CanShoot()
      {
         return canShoot; //TODO: gun in inventory
      }

      private bool CanJump()
      {
         return physical.OffGroundTime < Player.OFF_LEDGE_JUMP_TIME;
      }

      private bool CanDoubleJump()
      {
         return Inventory.Contains(BonusType.DoubleJump) && !hasDoubleJumped;
      }

      private void HitSpike(Spike spike)
      {
         if (HitDangerousObstacle())
            spike.SetBlooded();
      }

      private void HitMonster(Monster monster)
      {
         if (Inventory.Contains(BonusType.FireCloak))
         {
            var direction = monster.GetPhysical().Position - physical.Position;
            direction.Y = 0;
            direction.Normalize();
            monster.TakeDamage(1, direction);
         }
         else if (HitDangerousObstacle())
         {
            // First hit, player start nictating
         }
      }

      /// <summary>
      /// Returns true if hit was occured.
      /// </summary>
      private bool HitDangerousObstacle()
      {
         if (TakeDamage(1, Vector2.Zero))
         {
            SetInvulnerable(Player.DEFAULT_STUNNED_TIME);
            return true;
         }
         return false;
      }

      private void SetInvulnerable(float time)
      {
         nictating = true;
         stunned = true;
         SceneManager.Instance.CurrentScene.Timers.Create(nictateRate, () => nictating = !nictating, (int)(time / nictateRate));
         SceneManager.Instance.CurrentScene.Timers.Create(time, () => stunned = nictating = false);
      }

      #endregion Private Methods
   }
}