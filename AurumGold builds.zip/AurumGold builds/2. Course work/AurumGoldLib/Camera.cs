﻿// Type: DLCLib.Camera
// Assembly: DLCLib, Version=1.1.4439.32928, Culture=neutral, PublicKeyToken=null
// Assembly location: D:\Games\DLC Quest\DLCLib.dll

using AurumGoldLib.Physics;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace AurumGoldLib
{
   internal class Camera
   {
      private static float pixelsPerMeter = 1.5f;
      private static float metersPerPixel = 1f / Camera.pixelsPerMeter;
      protected static float SPEED = 4.5f;
      private Vector2 screenDimensions = new Vector2(1280f, 720f);
      private Viewport vp = new Viewport(0, 0, 1280, 720);
      private Vector2 position;
      private Vector2 desiredPosition;
      private Vector2 minPosition;
      private Vector2 maxPosition;
      private Vector2 halfScreenInMeters;
      private IPhysical target;
      private Vector2 lastTargetPosition;

      public IPhysical Target
      {
         get { return target; }
         set
         {
            target = value;
            lastTargetPosition = target.GetPhysical().Position;
         }
      }

      public Vector2 Offset { get; set; }

      public Matrix ViewMatrix { get; private set; }

      public Matrix ProjectionMatrix { get; private set; }

      public AABB BoundsInMeters { get; private set; }

      public Camera()
      {
         Matrix matrix = Matrix.CreateTranslation(-0.5f, -0.5f, 0.0f) * Camera.metersPerPixel;
         halfScreenInMeters = screenDimensions * Camera.metersPerPixel * 0.5f;
         ProjectionMatrix = matrix * Matrix.CreateOrthographicOffCenter(-halfScreenInMeters.X, halfScreenInMeters.X, halfScreenInMeters.Y, -halfScreenInMeters.Y, 0.0f, -1f);
         BoundsInMeters = new AABB();
         BoundsInMeters.Width = 1280f * Camera.metersPerPixel;
         BoundsInMeters.Height = 720f * Camera.metersPerPixel;
      }

      public void Update(float elapsed)
      {
         if (Target == null) return;

         Vector2 val1 = Target.GetPhysical().Position;
         position += val1 - lastTargetPosition;
         desiredPosition = val1 + Offset;
         Vector2 val2 = desiredPosition - position;
         float num = val2.Length();
         val2.Normalize();
         if (num <= Camera.SPEED * elapsed)
            position = desiredPosition;
         else
            position += val2 * Camera.SPEED * elapsed;
         ViewMatrix = Matrix.CreateTranslation(-position.X, -position.Y, 0.0f);
         BoundsInMeters.Center = position;
         lastTargetPosition = val1;
      }

      public Vector2 WorldToScreen(Vector2 vector)
      {
         Vector3 vector3 = vp.Project(new Vector3(vector, 0.0f), ProjectionMatrix, ViewMatrix, Matrix.Identity);
         return new Vector2(vector3.X, vector3.Y);
      }

      public Vector2 ScreenToWorld(Vector2 vector)
      {
         Vector3 vector3 = vp.Unproject(new Vector3(vector, 0.0f), ProjectionMatrix, ViewMatrix, Matrix.Identity);
         return new Vector2(vector3.X, vector3.Y);
      }

      internal void SnapToTarget()
      {
         if (Target == null) return;

         position = Target.GetPhysical().Position + Offset;
      }
   }
}