﻿using AurumGoldLib.Input;
using AurumGoldLib.World;

namespace AurumGoldLib.AI
{
   internal class PatrolBehaviour : MobBehavior
   {
      protected Mob mob;

      protected MobInput currentState;

      public float FromX { get; set; }

      public float ToX { get; set; }

      public PatrolBehaviour(Mob mob)
      {
         this.mob = mob;
         this.currentState = MobInput.MoveRight;
      }

      public override MobInput Think(float elapsed)
      {
         if (FromX >= ToX)
            return MobInput.Empty;

         var position = mob.GetPhysical().Position;

         if (position.X < FromX)
            return currentState = MobInput.MoveRight;
         if (position.X > ToX)
            return currentState = MobInput.MoveLeft;

         return currentState;
      }
   }
}