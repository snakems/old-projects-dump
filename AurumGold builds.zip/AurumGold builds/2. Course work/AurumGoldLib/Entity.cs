﻿using Microsoft.Xna.Framework;

namespace AurumGoldLib
{
   public abstract class Entity
   {
      #region Public Methods

      public virtual void Update(GameTime gameTime) { }

      #endregion Public Methods
   }
}