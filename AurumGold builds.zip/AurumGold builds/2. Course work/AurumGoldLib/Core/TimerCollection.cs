﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;

namespace AurumGoldLib.Core
{
   internal class TimerCollection
   {
      #region Fields

      private List<Timer> timers = new List<Timer>();

      #endregion Fields

      #region Public Methods

      public void Create(float tickLength, Action tick, int repeats = 0)
      {
         timers.Add(new Timer(tickLength, tick, repeats));
      }

      public void Reset()
      {
         timers.Clear();
      }

      public void Update(GameTime gameTime)
      {
         var elapsed = (float)gameTime.ElapsedGameTime.TotalSeconds;

         foreach (var timer in timers)
            timer.Update(elapsed);
         timers.RemoveAll(t => t.Finished);
      }

      #endregion Public Methods
   }
}