﻿using System;
using System.Collections.Generic;
using AurumGoldLib.Physics;
using Microsoft.Xna.Framework;

namespace AurumGoldLib.Core
{
   public class QuadTreeNode<T>
   {
      public delegate void ResizeDelegate(AABB newSize);

      #region Fields

      public QuadTreeItem<T>.MoveHandler MoveHandler;
      public QuadTreeItem<T>.DestroyHandler DestroyHandler;

      protected List<QuadTreeItem<T>> items;
      protected int maxNumItems;
      protected QuadTreeNode<T> topLeftNode;
      protected QuadTreeNode<T> topRightNode;
      protected QuadTreeNode<T> bottomLeftNode;
      protected QuadTreeNode<T> bottomRightNode;
      protected QuadTreeNode<T> parentNode;
      protected QuadTreeNode<T>.ResizeDelegate resizeDelegate;

      #endregion Fields

      #region Properties

      public bool IsSubdivided { get; protected set; }

      public AABB AABB { get; set; }

      #endregion Properties

      #region Constructors

      public QuadTreeNode(QuadTreeNode<T> parent, AABB aabb, int maxItems, bool warmStart, int maxDepth)
         : this(parent, aabb, maxItems)
      {
         if (warmStart && maxDepth > 0)
         {
            Subdivide(warmStart, maxDepth - 1);
         }
      }

      #endregion Constructors

      #region Public Methods

      public QuadTreeNode(QuadTreeNode<T> parent, AABB aabb, int maxItems)
      {
         parentNode = parent;
         AABB = aabb;
         items = new List<QuadTreeItem<T>>();
         maxNumItems = maxItems;
         MoveHandler = new QuadTreeItem<T>.MoveHandler(ItemMove);
         DestroyHandler = new QuadTreeItem<T>.DestroyHandler(ItemDestroy);
      }

      public static QuadTreeNode<T> ConstructRootNode(AABB aabb, int maxItems, QuadTreeNode<T>.ResizeDelegate resizeDelegate, bool warmStart, int maxDepth)
      {
         return new QuadTreeNode<T>(null, aabb, maxItems, warmStart, maxDepth)
         {
            resizeDelegate = resizeDelegate
         };
      }

      public void Insert(QuadTreeItem<T> item)
      {
         if (!InsertIntoChild(item))
         {
            item.Move += MoveHandler;
            item.Destroy += DestroyHandler;
            items.Add(item);
            if (!IsSubdivided && items.Count > maxNumItems)
            {
               Subdivide(false, 0);
            }
         }
      }

      private void Subdivide(bool warmStart, int maxDepth)
      {
         IsSubdivided = true;
         Vector2 vector = (AABB.HalfHeight + AABB.HalfWidth) / 2f;
         topLeftNode = new QuadTreeNode<T>(this, new AABB(new Vector2(AABB.Center.X - vector.X, AABB.Center.Y - vector.Y), AABB.HalfWidth.X, AABB.HalfHeight.Y), maxNumItems, warmStart, maxDepth);
         topRightNode = new QuadTreeNode<T>(this, new AABB(new Vector2(AABB.Center.X + vector.X, AABB.Center.Y - vector.Y), AABB.HalfWidth.X, AABB.HalfHeight.Y), maxNumItems, warmStart, maxDepth);
         bottomLeftNode = new QuadTreeNode<T>(this, new AABB(new Vector2(AABB.Center.X - vector.X, AABB.Center.Y + vector.Y), AABB.HalfWidth.X, AABB.HalfHeight.Y), maxNumItems, warmStart, maxDepth);
         bottomRightNode = new QuadTreeNode<T>(this, new AABB(new Vector2(AABB.Center.X + vector.X, AABB.Center.Y + vector.Y), AABB.HalfWidth.X, AABB.HalfHeight.Y), maxNumItems, warmStart, maxDepth);
         for (int i = items.Count - 1; i >= 0; i--)
         {
            PushItemDown(i);
         }
      }

      public void Destroy()
      {
         if (IsSubdivided)
         {
            topLeftNode.Destroy();
            topRightNode.Destroy();
            bottomLeftNode.Destroy();
            bottomRightNode.Destroy();
            topLeftNode = null;
            topRightNode = null;
            bottomLeftNode = null;
            bottomRightNode = null;
         }
         for (int i = items.Count - 1; i >= 0; i--)
         {
            RemoveItem(i);
         }
      }

      public void Query(AABB queryAABB, ref List<QuadTreeItem<T>> queryList)
      {
         if (AABB.Intersects(queryAABB))
         {
            foreach (QuadTreeItem<T> current in items)
            {
               if (current.AABB.Intersects(queryAABB))
               {
                  queryList.Add(current);
               }
            }
            if (IsSubdivided)
            {
               topLeftNode.Query(queryAABB, ref queryList);
               topRightNode.Query(queryAABB, ref queryList);
               bottomLeftNode.Query(queryAABB, ref queryList);
               bottomRightNode.Query(queryAABB, ref queryList);
            }
         }
      }

      public void GetAllItems(ref List<QuadTreeItem<T>> queryList)
      {
         queryList.AddRange(items);
         if (IsSubdivided)
         {
            topLeftNode.GetAllItems(ref queryList);
            topRightNode.GetAllItems(ref queryList);
            bottomLeftNode.GetAllItems(ref queryList);
            bottomRightNode.GetAllItems(ref queryList);
         }
      }

      public void ItemMove(QuadTreeItem<T> item)
      {
         int num = items.IndexOf(item);
         if (num >= 0)
         {
            if (!PushItemDown(num))
            {
               if (parentNode != null)
               {
                  PushItemUp(num);
                  return;
               }
               if (!AABB.Contains(item.AABB))
               {
                  float num2 = Math.Max(AABB.Center.X + AABB.HalfWidth.X, item.AABB.Center.X + item.AABB.HalfWidth.X);
                  float num3 = Math.Min(AABB.Center.X - AABB.HalfWidth.X, item.AABB.Center.X - item.AABB.HalfWidth.X);
                  float width = (num2 - num3) * 2f;
                  float num4 = Math.Max(AABB.Center.Y + AABB.HalfHeight.Y, item.AABB.Center.Y + item.AABB.HalfHeight.Y);
                  float num5 = Math.Min(AABB.Center.Y - AABB.HalfHeight.Y, item.AABB.Center.Y - item.AABB.HalfHeight.Y);
                  float height = (num4 - num5) * 2f;
                  resizeDelegate(new AABB(AABB.Center, width, height));
                  return;
               }
            }
            return;
         }
         throw new Exception("This node does not contain item - it should not receive this event!");
      }

      public void ItemDestroy(QuadTreeItem<T> item)
      {
         RemoveItem(item);
      }

      #endregion Public Methods

      #region Private Methods

      private bool PushItemDown(int i)
      {
         if (InsertIntoChild(items[i]))
         {
            RemoveItem(i);
            return true;
         }
         return false;
      }

      private void PushItemUp(int index)
      {
         QuadTreeItem<T> item = items[index];
         RemoveItem(index);
         parentNode.Insert(item);
      }

      private void RemoveItem(int i)
      {
         if (i < items.Count)
         {
            items[i].Move -= MoveHandler;
            items[i].Destroy -= DestroyHandler;
            items.RemoveAt(i);
         }
      }

      private void RemoveItem(QuadTreeItem<T> item)
      {
         int num = items.IndexOf(item);
         if (num >= 0)
         {
            items[num].Move -= MoveHandler;
            items[num].Destroy -= DestroyHandler;
            items.RemoveAt(num);
         }
      }

      private bool InsertIntoChild(QuadTreeItem<T> item)
      {
         if (!IsSubdivided)
         {
            return false;
         }
         if (topLeftNode.AABB.Contains(item.AABB))
         {
            topLeftNode.Insert(item);
         }
         else
         {
            if (topRightNode.AABB.Contains(item.AABB))
            {
               topRightNode.Insert(item);
            }
            else
            {
               if (bottomLeftNode.AABB.Contains(item.AABB))
               {
                  bottomLeftNode.Insert(item);
               }
               else
               {
                  if (!bottomRightNode.AABB.Contains(item.AABB))
                  {
                     return false;
                  }
                  bottomRightNode.Insert(item);
               }
            }
         }
         return true;
      }

      #endregion Private Methods
   }
}