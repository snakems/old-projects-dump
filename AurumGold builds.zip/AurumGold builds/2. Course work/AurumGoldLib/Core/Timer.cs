﻿using System;

namespace AurumGoldLib.Core
{
   internal class Timer
   {
      #region Fields

      private float tickLength;
      private int repeats;
      private Action tick;

      private float totalElapsed;
      private int ticks;

      #endregion Fields

      #region Properties

      public bool Finished { get; private set; }

      #endregion Properties

      #region Constructors

      /// <summary>
      /// Create new timer. Pass -1 to repeats to create infinite ticker.
      /// </summary>
      public Timer(float tickLength, Action tick, int repeats = 0)
      {
         this.tickLength = tickLength;
         this.repeats = repeats;
         this.tick = tick;
      }

      #endregion Constructors

      #region Public Methods

      public void Update(float elapsed)
      {
         if (Finished) return;

         totalElapsed += elapsed;
         if (totalElapsed >= tickLength)
         {
            if (tick != null) tick();
            totalElapsed -= tickLength;
            ++ticks;
         }
         if (repeats == -1) return;
         if (ticks > repeats) Finished = true;
      }

      #endregion Public Methods
   }
}