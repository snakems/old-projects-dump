﻿using AurumGoldLib.Physics;
using Microsoft.Xna.Framework;

namespace AurumGoldLib.Core
{
   public class QuadTreeItem<T>
   {
      public delegate void MoveHandler(QuadTreeItem<T> item);

      public delegate void DestroyHandler(QuadTreeItem<T> item);

      protected AABB aabb;
      protected T entity;

      public event QuadTreeItem<T>.MoveHandler Move;

      public event QuadTreeItem<T>.DestroyHandler Destroy;

      public T Entity { get { return entity; } }

      public AABB AABB { get { return aabb; } }

      public Vector2 Position
      {
         get { return aabb.Center; }
         set
         {
            aabb.Center = value;
            OnMove();
         }
      }

      public Vector2 Size
      {
         get { return new Vector2(aabb.Width, aabb.Height); }
         set
         {
            aabb.Width = value.X;
            aabb.Height = value.Y;
            OnMove();
         }
      }

      public QuadTreeItem(AABB aabb, T entity)
      {
         this.aabb = aabb;
         this.entity = entity;
      }

      public void Delete()
      {
         OnDestroy();
      }

      protected void OnMove()
      {
         if (Move != null)
         {
            Move(this);
         }
      }

      protected void OnDestroy()
      {
         if (Destroy != null)
         {
            Destroy(this);
         }
      }
   }
}