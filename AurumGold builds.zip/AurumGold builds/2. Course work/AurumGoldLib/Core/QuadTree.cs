﻿using System;
using System.Collections.Generic;
using AurumGoldLib.Physics;

namespace AurumGoldLib.Core
{
   public class QuadTree<T>
   {
      #region Fields

      private QuadTreeNode<T> head;
      private int maxItemsPerNode;
      private List<QuadTreeItem<T>> tempQueryList;

      #endregion Fields

      #region Properties

      public QuadTreeNode<T> Head { get { return head; } }

      #endregion Properties

      #region Constructors

      public QuadTree(AABB maxSize, int maxItemsPerNode, bool warmStart, int maxDepth)
      {
         this.maxItemsPerNode = maxItemsPerNode;
         head = QuadTreeNode<T>.ConstructRootNode(maxSize, maxItemsPerNode, new QuadTreeNode<T>.ResizeDelegate(Resize), warmStart, maxDepth);
         tempQueryList = new List<QuadTreeItem<T>>();
      }

      #endregion Constructors

      #region Public Methods

      public void Insert(QuadTreeItem<T> item)
      {
         if (!head.AABB.Contains(item.AABB))
         {
            float num1 = Math.Max(head.AABB.Center.X + head.AABB.HalfWidth.X, item.AABB.Center.X + item.AABB.HalfWidth.X);
            float num2 = Math.Min(head.AABB.Center.X - head.AABB.HalfWidth.X, item.AABB.Center.X - item.AABB.HalfWidth.X);
            float width = (num1 - num2) * 2f;
            float num3 = Math.Max(head.AABB.Center.Y + head.AABB.HalfHeight.Y, item.AABB.Center.Y + item.AABB.HalfHeight.Y);
            float num4 = Math.Min(head.AABB.Center.Y - head.AABB.HalfHeight.Y, item.AABB.Center.Y - item.AABB.HalfHeight.Y);
            float height = (num3 - num4) * 2f;
            Resize(new AABB(head.AABB.Center, width, height));
         }
         head.Insert(item);
      }

      public void Resize(AABB newSize)
      {
         tempQueryList.Clear();
         head.GetAllItems(ref tempQueryList);
         head.Destroy();
         head = null;
         head = QuadTreeNode<T>.ConstructRootNode(newSize, maxItemsPerNode, new QuadTreeNode<T>.ResizeDelegate(Resize), false, 0);
         foreach (QuadTreeItem<T> current in tempQueryList)
         {
            head.Insert(current);
         }
      }

      public void Query(AABB aabb, out List<QuadTreeItem<T>> queryList)
      {
         queryList = new List<QuadTreeItem<T>>();
         if (queryList != null)
         {
            head.Query(aabb, ref queryList);
         }
      }

      public void GetAllItems(out List<QuadTreeItem<T>> queryList)
      {
         queryList = new List<QuadTreeItem<T>>();
         if (queryList != null)
         {
            head.GetAllItems(ref queryList);
         }
      }

      #endregion Public Methods
   }
}