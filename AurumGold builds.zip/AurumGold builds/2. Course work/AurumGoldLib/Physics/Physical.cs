﻿using AurumGoldLib.Core;
using Microsoft.Xna.Framework;

namespace AurumGoldLib.Physics
{
   internal class Physical : QuadTreeItem<Entity>
   {
      #region Properties

      public bool Static { get; set; }

      public event CollisionEventHandler Collided;

      #region MovementProperties

      public bool GravityApplied { get; set; }

      public float GroundFriction { get; set; }

      public float AirFriction { get; set; }

      public bool OnGround { get; internal set; }

      public bool AtCeiling { get; internal set; }

      public Vector2 Acceleration { get; set; }

      public Vector2 Velocity { get; set; }

      public float OffGroundTime { get; internal set; }

      #endregion MovementProperties

      #endregion Properties

      #region Constructors

      public Physical(Entity entity)
         : base(new AABB(), entity)
      {
      }

      public Physical(AABB aabb, Entity entity)
         : base(aabb, entity)
      {
      }

      #endregion Constructors

      #region Public Methods

      public bool OnCollision(Physical other)
      {
         return Collided == null || Collided(this, other);
      }

      public void SetVelocityX(float x)
      {
         Velocity = new Vector2(x, Velocity.Y);
      }

      public void SetVelocityY(float y)
      {
         Velocity = new Vector2(Velocity.X, y);
      }

      public void ResetDynamics()
      {
         Velocity = Vector2.Zero;
         Acceleration = Vector2.Zero;
      }

      #endregion Public Methods
   }
}