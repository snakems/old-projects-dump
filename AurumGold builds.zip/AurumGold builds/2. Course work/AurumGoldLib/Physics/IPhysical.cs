﻿namespace AurumGoldLib.Physics
{
   internal interface IPhysical
   {
      Physical GetPhysical();
   }
}