﻿namespace AurumGoldLib.Physics
{
   internal delegate bool CollisionEventHandler(Physical first, Physical second);
}