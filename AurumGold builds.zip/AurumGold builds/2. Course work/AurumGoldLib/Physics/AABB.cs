﻿using System;
using AurumGoldLib.Extensions;
using Microsoft.Xna.Framework;

namespace AurumGoldLib.Physics
{
   public class AABB
   {
      private float width;
      private float height;
      private Vector2 topLeft;
      private Vector2 bottomRight;
      private Vector2 bottomCenter;
      private Vector2 topCenter;
      private Vector2 center;

      public Vector2 WidthVector { get; private set; }

      public Vector2 HeightVector { get; private set; }

      public float Width
      {
         get { return width; }
         set
         {
            width = value;
            HalfWidth = new Vector2(Width / 2f, 0f);
            WidthVector = new Vector2(value, 0f);
            Center = center;
         }
      }

      public float Height
      {
         get { return height; }
         set
         {
            height = value;
            HalfHeight = new Vector2(0f, Height / 2f);
            HeightVector = new Vector2(0f, value);
            Center = center;
         }
      }

      public Vector2 HalfWidth { get; private set; }

      public Vector2 HalfHeight { get; private set; }

      public Vector2 TopLeft { get { return topLeft; } }

      public Vector2 BottomRight { get { return bottomRight; } }

      public Vector2 Center
      {
         get { return center; }
         set
         {
            center = value;
            bottomCenter = center + HalfHeight;
            topCenter = center - HalfHeight;
            topLeft = center - HalfHeight - HalfWidth;
            bottomRight = center + HalfHeight + HalfWidth;
         }
      }

      public Vector2 BottomCenter { get { return bottomCenter; } }

      public Vector2 TopCenter { get { return topCenter; } }

      public Rectangle Rect
      {
         get { return new Rectangle((int)(center.X - width / 2), (int)(center.Y - height / 2), (int)width, (int)height); }
      }

      public AABB()
      {
      }

      public AABB(Vector2 center, float width, float height)
      {
         Center = center;
         Width = width;
         Height = height;
      }

      public AABB(Rectangle rect)
      {
         Center = new Vector2(rect.Center.X, rect.Center.Y);
         Width = rect.Width;
         Height = rect.Height;
      }

      public bool Contains(AABB otherAABB)
      {
         return topLeft.X <= otherAABB.topLeft.X && topLeft.Y <= otherAABB.topLeft.Y && bottomRight.X >= otherAABB.bottomRight.X && bottomRight.Y >= otherAABB.bottomRight.Y;
      }

      public bool Intersects(AABB otherAABB)
      {
         return topLeft.X < otherAABB.topLeft.X + otherAABB.width && otherAABB.topLeft.X < topLeft.X + width && topLeft.Y < otherAABB.topLeft.Y + otherAABB.height && otherAABB.topLeft.Y < topLeft.Y + height;
      }

      public bool Collides(AABB otherAABB)
      {
         Vector2 vector;
         return Collides(otherAABB, out vector);
      }

      public bool Collides(AABB otherAABB, out Vector2 resolutionVector)
      {
         Vector2 value = HeightVector.Project(Vector2.UnitY);
         Vector2 vector = WidthVector.Project(Vector2.UnitX);
         Vector2 value2 = otherAABB.HeightVector.Project(Vector2.UnitY);
         Vector2 vector2 = otherAABB.WidthVector.Project(Vector2.UnitX);
         Vector2 vector3 = (Center - otherAABB.Center).Project(Vector2.UnitY);
         Vector2 vector4 = (Center - otherAABB.Center).Project(Vector2.UnitX);
         bool flag = true;
         bool flag2 = true;
         Vector2 vector5 = value2 + otherAABB.TopLeft;
         Vector2 vector6 = value + TopLeft;
         if (otherAABB.TopLeft.Y >= vector6.Y || vector5.Y <= TopLeft.Y)
         {
            flag = false;
         }
         if (otherAABB.TopLeft.X >= vector.X + TopLeft.X || vector2.X + otherAABB.TopLeft.X <= TopLeft.X)
         {
            flag2 = false;
         }
         bool flag3 = flag && flag2;
         resolutionVector = Vector2.Zero;
         if (flag3)
         {
            float num = Math.Abs(value.Y) + Math.Abs(value2.Y) - (Math.Abs(vector3.Y) + HalfHeight.Y + otherAABB.HalfHeight.Y);
            float num2 = Math.Abs(vector.X) + Math.Abs(vector2.X) - (Math.Abs(vector4.X) + HalfWidth.X + otherAABB.HalfWidth.X);
            if (Center.Y < otherAABB.Center.Y)
            {
               num *= -1f;
            }
            if (Center.X < otherAABB.Center.X)
            {
               num2 *= -1f;
            }
            resolutionVector = new Vector2(num2, num);
         }
         return flag3;
      }
   }
}