using AurumGoldLib;
using AurumGoldLib.GameScreenManagement;
using AurumGoldLib.Input;
using AurumGoldLib.Render;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace AurumGoldGame
{
   /// <summary>
   /// This is the main type for your game
   /// </summary>
   public class AurumGoldGame : Microsoft.Xna.Framework.Game
   {
      private GraphicsDeviceManager graphics;
      private SpriteBatch spriteBatch;

      private ScreenManager screenManager;

      public AurumGoldGame()
      {
         graphics = new GraphicsDeviceManager(this);
         Content.RootDirectory = "Content";

         screenManager = new ScreenManager(this);
         Components.Add(screenManager);
      }

      /// <summary>
      /// Allows the game to perform any initialization it needs to before starting to run.
      /// This is where it can query for any required services and load any non-graphic
      /// related content.  Calling base.Initialize will enumerate through any components
      /// and initialize them as well.
      /// </summary>
      protected override void Initialize()
      {
         InputManager.Initialize();
         SetupGraphics();

         base.Initialize();
      }

      protected void SetupGraphics()
      {
         graphics.SynchronizeWithVerticalRetrace = true;
         graphics.PreferredBackBufferWidth = 1280;
         graphics.PreferredBackBufferHeight = 720;
         graphics.IsFullScreen = false;
         IsMouseVisible = true;
         graphics.PreferredDepthStencilFormat = DepthFormat.Depth24Stencil8;
         graphics.ApplyChanges();
         RenderManager.Instance.GraphicsDevice = graphics.GraphicsDevice;
         RenderManager.Instance.GraphicsDeviceManager = graphics;
         graphics.GraphicsDevice.Clear(Color.Black);
      }

      /// <summary>
      /// LoadContent will be called once per game and is the place to load
      /// all of your content.
      /// </summary>
      protected override void LoadContent()
      {
         // Create a new SpriteBatch, which can be used to draw textures.
         spriteBatch = new SpriteBatch(GraphicsDevice);
         DebugDraw.Initialize(Content, spriteBatch);
         ContentHelper.Init(Content);

         screenManager.AddScreen(new GameplayScreen());
      }

      /// <summary>
      /// UnloadContent will be called once per game and is the place to unload
      /// all content.
      /// </summary>
      protected override void UnloadContent()
      {
      }

      /// <summary>
      /// Allows the game to run logic such as updating the scene,
      /// checking for collisions, gathering input, and playing audio.
      /// </summary>
      /// <param name="gameTime">Provides a snapshot of timing values.</param>
      protected override void Update(GameTime gameTime)
      {
         // Allows the game to exit
         if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed)
            this.Exit();

         InputManager.Update();

         base.Update(gameTime);
      }

      /// <summary>
      /// This is called when the game should draw itself.
      /// </summary>
      /// <param name="gameTime">Provides a snapshot of timing values.</param>
      protected override void Draw(GameTime gameTime)
      {
         graphics.GraphicsDevice.SetRenderTarget(RenderManager.Instance.BackBufferRT);
         GraphicsDevice.Clear(Color.Black);
         base.Draw(gameTime);
         graphics.GraphicsDevice.SetRenderTarget(null);
         GraphicsDevice.Clear(Color.Black);
         spriteBatch.Begin();
         spriteBatch.Draw(RenderManager.Instance.BackBufferRT, RenderManager.Instance.BackBufferRTRectangle, Color.White);
         spriteBatch.End();
      }
   }
}